package com.AdX.tag;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import java.util.Iterator;
import java.util.Set;

public class AdXAppTracker
  extends BroadcastReceiver
{
  final String AdX_PREFERENCE = "AdXPrefrences";
  final String REFERRAL_URL = "InstallReferral";
  
  private void pass_on_broadcast(Context paramContext, Intent paramIntent)
  {
    Object localObject1 = "";
    try
    {
      Object localObject2 = paramContext.getPackageManager();
      if (localObject2 != null)
      {
        Object localObject3 = new ComponentName(paramContext, AdXAppTracker.class);
        localObject3 = ((PackageManager)localObject2).getReceiverInfo((ComponentName)localObject3, 128);
        if ((localObject3 != null) && (((ActivityInfo)localObject3).metaData != null))
        {
          localObject2 = ((ActivityInfo)localObject3).metaData.keySet();
          if (localObject2 != null)
          {
            Iterator localIterator = ((Set)localObject2).iterator();
            for (;;)
            {
              if (!localIterator.hasNext()) {
                return;
              }
              localObject2 = (String)localIterator.next();
              try
              {
                localObject2 = ((ActivityInfo)localObject3).metaData.getString((String)localObject2);
                localObject1 = localObject2;
                ((BroadcastReceiver)Class.forName((String)localObject2).newInstance()).onReceive(paramContext, paramIntent);
                localObject1 = localObject2;
                new StringBuilder("Successfully forwarded install notification to ").append((String)localObject2).toString();
                localObject1 = localObject2;
              }
              catch (Exception localException)
              {
                new StringBuilder("Could not forward Market's INSTALL_REFERRER intent to ").append((String)localObject1).toString();
              }
            }
          }
        }
      }
      return;
    }
    catch (Exception paramContext) {}
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    try
    {
      String str = paramIntent.toURI();
      if ((str != null) && (str.length() > 0))
      {
        int i = str.indexOf("referrer=");
        if (i > -1)
        {
          str = str.substring(i, str.length() - 4);
          SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("AdXPrefrences", 0).edit();
          localEditor.putString("InstallReferral", str);
          localEditor.commit();
        }
      }
      AdXConnect.doBroadcastConnectInstance(paramContext);
      pass_on_broadcast(paramContext, paramIntent);
      return;
    }
    catch (Exception paramContext) {}
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/AdX/tag/AdXAppTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */