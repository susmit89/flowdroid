package com.AdX.tag;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;
import java.io.ByteArrayInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public final class AdXConnect
{
  public static final String ATTRIBUTION_ID_COLUMN_NAME = "aid";
  public static final Uri ATTRIBUTION_ID_CONTENT_URI;
  private static AdXConnect AdXConnectEventInstance;
  private static AdXConnect AdXConnectInstance = null;
  private static AdXURLConnection AdXURLConnection;
  private static String AdX_PREFERENCE;
  public static boolean DEBUG = true;
  public static int LOGLEVEL;
  private static String MODREFERRAL;
  private static String RECEIVER_DONE;
  private static String REFERRAL_URL;
  private static String UPDATE;
  public static boolean WARN;
  private static String referralURL;
  private String AdXClickURL = "";
  private String SEND_TAG = "SendTag";
  private String androidID = "";
  private String appID = "";
  private String appVersion = "";
  private String clientID = "";
  private ConnectEventTask connectEventTask = null;
  private ConnectTask connectTask = null;
  private final Context context;
  private String deviceCountryCode = "";
  private String deviceID = "";
  private String deviceLanguage = "";
  private String deviceName = "";
  private String deviceOSVersion = "";
  private String deviceScreenDensity = "";
  private String deviceScreenLayoutSize = "";
  private String deviceType = "";
  private String fbattribution = "";
  private String libraryVersion = "";
  private String tagVersion = "2.4.0";
  
  static
  {
    AdXConnectEventInstance = null;
    AdXURLConnection = null;
    ATTRIBUTION_ID_CONTENT_URI = Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider");
    referralURL = "";
    AdX_PREFERENCE = "AdXPrefrences";
    MODREFERRAL = "AdXReferral";
    RECEIVER_DONE = "ReceiverDone";
    UPDATE = "AdXUpdate";
    REFERRAL_URL = "InstallReferral";
    LOGLEVEL = 1;
    WARN = true;
  }
  
  private AdXConnect(Context paramContext, int paramInt)
  {
    this.context = paramContext;
    paramContext = this.context.getSharedPreferences(AdX_PREFERENCE, 0).getString(this.SEND_TAG, null);
    if ((paramContext != null) && (paramContext.equals("stop")))
    {
      if (DEBUG) {
        Log.i("AdXAppTracker", "SendTag is set to stop ");
      }
      return;
    }
    this.connectTask = new ConnectTask(null);
    this.connectTask.execute(new Integer[] { Integer.valueOf(paramInt) });
  }
  
  private AdXConnect(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    this.context = paramContext;
    if (DEBUG) {
      Log.i("AdXAppTracker", "In Constructor ");
    }
    this.connectEventTask = new ConnectEventTask(null);
    this.connectEventTask.execute(new String[] { paramString1, paramString2, paramString3 });
  }
  
  private Document buildDocument(String paramString)
  {
    Object localObject = null;
    try
    {
      DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
      paramString = new ByteArrayInputStream(paramString.getBytes("UTF-8"));
      paramString = localDocumentBuilderFactory.newDocumentBuilder().parse(paramString);
      return paramString;
    }
    catch (Exception localException)
    {
      do
      {
        paramString = (String)localObject;
      } while (!WARN);
      Log.e("AdXAppTracker", "buildDocument exception: " + localException.toString());
    }
    return null;
  }
  
  public static void doBroadcastConnectInstance(Context paramContext)
  {
    if (AdXURLConnection == null) {
      AdXURLConnection = new AdXURLConnection();
    }
    if (AdXConnectInstance == null) {
      AdXConnectInstance = new AdXConnect(paramContext, 0);
    }
    if (DEBUG) {
      Log.i("AdXAppTracker", "Broadcast Receiver - sending to AdX.");
    }
    paramContext = paramContext.getSharedPreferences(AdX_PREFERENCE, 0).edit();
    paramContext.putString(RECEIVER_DONE, "done");
    paramContext.commit();
  }
  
  public static AdXConnect getAdXConnectEventInstance(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    boolean bool2 = true;
    if (LOGLEVEL > 1)
    {
      bool1 = true;
      WARN = bool1;
      if (LOGLEVEL <= 0) {
        break label83;
      }
    }
    label83:
    for (boolean bool1 = bool2;; bool1 = false)
    {
      DEBUG = bool1;
      if (AdXURLConnection == null) {
        AdXURLConnection = new AdXURLConnection();
      }
      if (AdXConnectEventInstance != null) {
        AdXConnectEventInstance = null;
      }
      AdXConnectEventInstance = new AdXConnect(paramContext, paramString1, paramString2, paramString3);
      return AdXConnectEventInstance;
      bool1 = false;
      break;
    }
  }
  
  public static AdXConnect getAdXConnectInstance(Context paramContext, boolean paramBoolean, int paramInt)
  {
    LOGLEVEL = paramInt;
    boolean bool;
    label28:
    Object localObject;
    SharedPreferences.Editor localEditor;
    final int i;
    if (LOGLEVEL > 1)
    {
      bool = true;
      WARN = bool;
      if (LOGLEVEL <= 0) {
        break label214;
      }
      bool = true;
      DEBUG = bool;
      localObject = paramContext.getSharedPreferences(AdX_PREFERENCE, 0);
      localEditor = ((SharedPreferences)localObject).edit();
      paramInt = ((SharedPreferences)localObject).getInt(UPDATE, -1);
      i = paramInt;
      if (paramInt < 0)
      {
        if (!paramBoolean) {
          break label220;
        }
        localEditor.putInt(UPDATE, 1);
      }
    }
    for (paramInt = 1;; paramInt = 0)
    {
      i = paramInt;
      if (DEBUG)
      {
        Log.i("AdXAppTracker", "Update flag set to " + paramInt);
        i = paramInt;
      }
      localObject = ((SharedPreferences)localObject).getString(RECEIVER_DONE, null);
      if ((i != 1) && ((localObject == null) || (!((String)localObject).equals("done")))) {
        break label237;
      }
      if (DEBUG) {
        Log.i("AdXAppTracker", "Sending to AdX");
      }
      if (AdXURLConnection == null) {
        AdXURLConnection = new AdXURLConnection();
      }
      if (AdXConnectInstance == null) {
        AdXConnectInstance = new AdXConnect(paramContext, i);
      }
      return AdXConnectInstance;
      bool = false;
      break;
      label214:
      bool = false;
      break label28;
      label220:
      localEditor.putInt(UPDATE, 0);
    }
    label237:
    if (DEBUG) {
      Log.i("AdXAppTracker", "Re Referral yet - deferring..");
    }
    localEditor.putString(RECEIVER_DONE, "done");
    localEditor.commit();
    new Handler().postDelayed(new Runnable()
    {
      public void run()
      {
        if (AdXConnect.DEBUG) {
          Log.i("AdXAppTracker", "12 seconds is up sending to AdX");
        }
        if (AdXConnect.AdXURLConnection == null) {
          AdXConnect.AdXURLConnection = new AdXURLConnection();
        }
        if (AdXConnect.AdXConnectInstance == null) {
          AdXConnect.AdXConnectInstance = new AdXConnect(AdXConnect.this, i, null);
        }
      }
    }, 12000L);
    return null;
  }
  
  public static String getAdXReferral(Context paramContext, int paramInt)
  {
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences(AdX_PREFERENCE, 0);
    paramContext = localSharedPreferences.getString(MODREFERRAL, null);
    int i = 0;
    for (;;)
    {
      if ((i >= paramInt) || ((paramContext != null) && (!paramContext.equals("")))) {
        return paramContext;
      }
      int k = i;
      Object localObject = paramContext;
      try
      {
        Thread.sleep(1000L);
        int j = i + 1;
        k = j;
        localObject = paramContext;
        String str = localSharedPreferences.getString(MODREFERRAL, null);
        i = j;
        paramContext = str;
        k = j;
        localObject = str;
        if (DEBUG)
        {
          k = j;
          localObject = str;
          Log.i("AdXAppTracker", "Count " + j + " " + str);
          i = j;
          paramContext = str;
        }
      }
      catch (Exception paramContext)
      {
        i = k;
        paramContext = (Context)localObject;
      }
    }
  }
  
  /* Error */
  private void getApplicationData()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 154	com/AdX/tag/AdXConnect:context	Landroid/content/Context;
    //   4: invokevirtual 371	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   7: astore_2
    //   8: aload_0
    //   9: aload_0
    //   10: getfield 154	com/AdX/tag/AdXConnect:context	Landroid/content/Context;
    //   13: invokevirtual 375	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   16: ldc_w 377
    //   19: invokestatic 382	android/provider/Settings$Secure:getString	(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   22: putfield 128	com/AdX/tag/AdXConnect:androidID	Ljava/lang/String;
    //   25: aload_2
    //   26: aload_0
    //   27: getfield 154	com/AdX/tag/AdXConnect:context	Landroid/content/Context;
    //   30: invokevirtual 385	android/content/Context:getPackageName	()Ljava/lang/String;
    //   33: sipush 128
    //   36: invokevirtual 391	android/content/pm/PackageManager:getApplicationInfo	(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   39: astore_3
    //   40: aload_3
    //   41: ifnull +1004 -> 1045
    //   44: aload_3
    //   45: getfield 397	android/content/pm/ApplicationInfo:metaData	Landroid/os/Bundle;
    //   48: ifnull +997 -> 1045
    //   51: aload_3
    //   52: getfield 397	android/content/pm/ApplicationInfo:metaData	Landroid/os/Bundle;
    //   55: ldc_w 399
    //   58: invokevirtual 404	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   61: astore 4
    //   63: aload 4
    //   65: ifnull +620 -> 685
    //   68: aload 4
    //   70: ldc 77
    //   72: invokevirtual 174	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   75: ifne +610 -> 685
    //   78: aload_0
    //   79: aload 4
    //   81: invokevirtual 407	java/lang/String:trim	()Ljava/lang/String;
    //   84: putfield 130	com/AdX/tag/AdXConnect:appID	Ljava/lang/String;
    //   87: aload_3
    //   88: getfield 397	android/content/pm/ApplicationInfo:metaData	Landroid/os/Bundle;
    //   91: ldc_w 409
    //   94: invokevirtual 404	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   97: astore 4
    //   99: aload 4
    //   101: ifnull +617 -> 718
    //   104: aload 4
    //   106: ldc 77
    //   108: invokevirtual 174	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   111: ifne +607 -> 718
    //   114: aload_0
    //   115: aload 4
    //   117: invokevirtual 407	java/lang/String:trim	()Ljava/lang/String;
    //   120: putfield 132	com/AdX/tag/AdXConnect:clientID	Ljava/lang/String;
    //   123: aload_0
    //   124: aload_2
    //   125: aload_0
    //   126: getfield 154	com/AdX/tag/AdXConnect:context	Landroid/content/Context;
    //   129: invokevirtual 385	android/content/Context:getPackageName	()Ljava/lang/String;
    //   132: iconst_0
    //   133: invokevirtual 413	android/content/pm/PackageManager:getPackageInfo	(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   136: getfield 418	android/content/pm/PackageInfo:versionName	Ljava/lang/String;
    //   139: putfield 134	com/AdX/tag/AdXConnect:appVersion	Ljava/lang/String;
    //   142: aload_0
    //   143: ldc_w 420
    //   146: putfield 120	com/AdX/tag/AdXConnect:deviceType	Ljava/lang/String;
    //   149: aload_0
    //   150: getstatic 425	android/os/Build:MODEL	Ljava/lang/String;
    //   153: putfield 118	com/AdX/tag/AdXConnect:deviceName	Ljava/lang/String;
    //   156: aload_0
    //   157: getstatic 430	android/os/Build$VERSION:RELEASE	Ljava/lang/String;
    //   160: putfield 122	com/AdX/tag/AdXConnect:deviceOSVersion	Ljava/lang/String;
    //   163: aload_0
    //   164: invokestatic 436	java/util/Locale:getDefault	()Ljava/util/Locale;
    //   167: invokevirtual 439	java/util/Locale:getCountry	()Ljava/lang/String;
    //   170: putfield 124	com/AdX/tag/AdXConnect:deviceCountryCode	Ljava/lang/String;
    //   173: aload_0
    //   174: invokestatic 436	java/util/Locale:getDefault	()Ljava/util/Locale;
    //   177: invokevirtual 442	java/util/Locale:getLanguage	()Ljava/lang/String;
    //   180: putfield 126	com/AdX/tag/AdXConnect:deviceLanguage	Ljava/lang/String;
    //   183: aload_0
    //   184: aload_0
    //   185: getfield 144	com/AdX/tag/AdXConnect:tagVersion	Ljava/lang/String;
    //   188: putfield 136	com/AdX/tag/AdXConnect:libraryVersion	Ljava/lang/String;
    //   191: aload_0
    //   192: getfield 154	com/AdX/tag/AdXConnect:context	Landroid/content/Context;
    //   195: getstatic 83	com/AdX/tag/AdXConnect:AdX_PREFERENCE	Ljava/lang/String;
    //   198: iconst_0
    //   199: invokevirtual 160	android/content/Context:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   202: astore_2
    //   203: aload_3
    //   204: getfield 397	android/content/pm/ApplicationInfo:metaData	Landroid/os/Bundle;
    //   207: ldc_w 444
    //   210: invokevirtual 404	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   213: astore_3
    //   214: aload_3
    //   215: ifnull +519 -> 734
    //   218: aload_3
    //   219: ldc 77
    //   221: invokevirtual 174	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   224: ifne +510 -> 734
    //   227: aload_0
    //   228: aload_3
    //   229: putfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   232: new 446	android/util/DisplayMetrics
    //   235: dup
    //   236: invokespecial 447	android/util/DisplayMetrics:<init>	()V
    //   239: astore_3
    //   240: aload_0
    //   241: getfield 154	com/AdX/tag/AdXConnect:context	Landroid/content/Context;
    //   244: ldc_w 449
    //   247: invokevirtual 453	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   250: checkcast 455	android/view/WindowManager
    //   253: invokeinterface 459 1 0
    //   258: aload_3
    //   259: invokevirtual 465	android/view/Display:getMetrics	(Landroid/util/DisplayMetrics;)V
    //   262: aload_2
    //   263: getstatic 99	com/AdX/tag/AdXConnect:REFERRAL_URL	Ljava/lang/String;
    //   266: aconst_null
    //   267: invokeinterface 166 3 0
    //   272: astore_2
    //   273: aload_2
    //   274: ifnull +16 -> 290
    //   277: aload_2
    //   278: ldc 77
    //   280: invokevirtual 174	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   283: ifne +7 -> 290
    //   286: aload_2
    //   287: putstatic 79	com/AdX/tag/AdXConnect:referralURL	Ljava/lang/String;
    //   290: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   293: ifeq +12 -> 305
    //   296: ldc -80
    //   298: ldc_w 467
    //   301: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   304: pop
    //   305: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   308: ifeq +35 -> 343
    //   311: ldc -80
    //   313: new 279	java/lang/StringBuilder
    //   316: dup
    //   317: ldc_w 469
    //   320: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   323: aload_0
    //   324: getfield 130	com/AdX/tag/AdXConnect:appID	Ljava/lang/String;
    //   327: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   330: ldc_w 471
    //   333: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   336: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   339: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   342: pop
    //   343: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   346: ifeq +35 -> 381
    //   349: ldc -80
    //   351: new 279	java/lang/StringBuilder
    //   354: dup
    //   355: ldc_w 473
    //   358: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   361: aload_0
    //   362: getfield 118	com/AdX/tag/AdXConnect:deviceName	Ljava/lang/String;
    //   365: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   368: ldc_w 471
    //   371: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   374: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   377: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   380: pop
    //   381: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   384: ifeq +35 -> 419
    //   387: ldc -80
    //   389: new 279	java/lang/StringBuilder
    //   392: dup
    //   393: ldc_w 475
    //   396: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   399: aload_0
    //   400: getfield 120	com/AdX/tag/AdXConnect:deviceType	Ljava/lang/String;
    //   403: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   406: ldc_w 471
    //   409: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   412: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   415: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   418: pop
    //   419: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   422: ifeq +35 -> 457
    //   425: ldc -80
    //   427: new 279	java/lang/StringBuilder
    //   430: dup
    //   431: ldc_w 477
    //   434: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   437: aload_0
    //   438: getfield 136	com/AdX/tag/AdXConnect:libraryVersion	Ljava/lang/String;
    //   441: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: ldc_w 471
    //   447: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   450: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   453: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   456: pop
    //   457: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   460: ifeq +35 -> 495
    //   463: ldc -80
    //   465: new 279	java/lang/StringBuilder
    //   468: dup
    //   469: ldc_w 479
    //   472: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   475: aload_0
    //   476: getfield 122	com/AdX/tag/AdXConnect:deviceOSVersion	Ljava/lang/String;
    //   479: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   482: ldc_w 471
    //   485: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   488: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   491: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   494: pop
    //   495: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   498: ifeq +35 -> 533
    //   501: ldc -80
    //   503: new 279	java/lang/StringBuilder
    //   506: dup
    //   507: ldc_w 481
    //   510: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   513: aload_0
    //   514: getfield 124	com/AdX/tag/AdXConnect:deviceCountryCode	Ljava/lang/String;
    //   517: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   520: ldc_w 471
    //   523: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   526: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   529: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   532: pop
    //   533: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   536: ifeq +35 -> 571
    //   539: ldc -80
    //   541: new 279	java/lang/StringBuilder
    //   544: dup
    //   545: ldc_w 483
    //   548: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   551: aload_0
    //   552: getfield 126	com/AdX/tag/AdXConnect:deviceLanguage	Ljava/lang/String;
    //   555: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   558: ldc_w 471
    //   561: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   564: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   567: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   570: pop
    //   571: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   574: ifeq +35 -> 609
    //   577: ldc -80
    //   579: new 279	java/lang/StringBuilder
    //   582: dup
    //   583: ldc_w 485
    //   586: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   589: aload_0
    //   590: getfield 138	com/AdX/tag/AdXConnect:deviceScreenDensity	Ljava/lang/String;
    //   593: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   596: ldc_w 471
    //   599: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   602: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   605: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   608: pop
    //   609: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   612: ifeq +35 -> 647
    //   615: ldc -80
    //   617: new 279	java/lang/StringBuilder
    //   620: dup
    //   621: ldc_w 487
    //   624: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   627: aload_0
    //   628: getfield 140	com/AdX/tag/AdXConnect:deviceScreenLayoutSize	Ljava/lang/String;
    //   631: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   634: ldc_w 471
    //   637: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   640: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   643: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   646: pop
    //   647: getstatic 105	com/AdX/tag/AdXConnect:DEBUG	Z
    //   650: ifeq +410 -> 1060
    //   653: ldc -80
    //   655: new 279	java/lang/StringBuilder
    //   658: dup
    //   659: ldc_w 489
    //   662: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   665: getstatic 79	com/AdX/tag/AdXConnect:referralURL	Ljava/lang/String;
    //   668: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   671: ldc_w 471
    //   674: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   677: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   680: invokestatic 184	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   683: pop
    //   684: return
    //   685: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   688: ifeq +372 -> 1060
    //   691: ldc -80
    //   693: ldc_w 491
    //   696: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   699: pop
    //   700: return
    //   701: astore_2
    //   702: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   705: ifeq +355 -> 1060
    //   708: ldc -80
    //   710: ldc_w 493
    //   713: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   716: pop
    //   717: return
    //   718: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   721: ifeq +339 -> 1060
    //   724: ldc -80
    //   726: ldc_w 495
    //   729: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   732: pop
    //   733: return
    //   734: aload_0
    //   735: aconst_null
    //   736: putfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   739: iconst_0
    //   740: istore_1
    //   741: aload_0
    //   742: getfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   745: ifnonnull +119 -> 864
    //   748: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   751: ifeq +310 -> 1061
    //   754: ldc -80
    //   756: ldc_w 497
    //   759: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   762: pop
    //   763: goto +298 -> 1061
    //   766: iload_1
    //   767: ifeq -535 -> 232
    //   770: new 499	java/lang/StringBuffer
    //   773: dup
    //   774: invokespecial 500	java/lang/StringBuffer:<init>	()V
    //   777: astore_3
    //   778: aload_3
    //   779: aload_0
    //   780: getfield 128	com/AdX/tag/AdXConnect:androidID	Ljava/lang/String;
    //   783: invokevirtual 503	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   786: pop
    //   787: aload_2
    //   788: ldc_w 505
    //   791: aconst_null
    //   792: invokeinterface 166 3 0
    //   797: astore 4
    //   799: aload 4
    //   801: ifnull +270 -> 1071
    //   804: aload 4
    //   806: ldc 77
    //   808: invokevirtual 174	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   811: ifne +260 -> 1071
    //   814: aload_0
    //   815: aload 4
    //   817: putfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   820: goto -588 -> 232
    //   823: astore_3
    //   824: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   827: ifeq +29 -> 856
    //   830: ldc -80
    //   832: new 279	java/lang/StringBuilder
    //   835: dup
    //   836: ldc_w 507
    //   839: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   842: aload_3
    //   843: invokevirtual 287	java/lang/Exception:toString	()Ljava/lang/String;
    //   846: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   849: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   852: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   855: pop
    //   856: aload_0
    //   857: aconst_null
    //   858: putfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   861: goto -629 -> 232
    //   864: aload_0
    //   865: getfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   868: invokevirtual 511	java/lang/String:length	()I
    //   871: ifeq +29 -> 900
    //   874: aload_0
    //   875: getfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   878: ldc_w 513
    //   881: invokevirtual 174	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   884: ifne +16 -> 900
    //   887: aload_0
    //   888: getfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   891: ldc_w 515
    //   894: invokevirtual 174	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   897: ifeq +21 -> 918
    //   900: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   903: ifeq +163 -> 1066
    //   906: ldc -80
    //   908: ldc_w 517
    //   911: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   914: pop
    //   915: goto +151 -> 1066
    //   918: aload_0
    //   919: aload_0
    //   920: getfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   923: invokevirtual 520	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   926: putfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   929: goto -163 -> 766
    //   932: iload_1
    //   933: bipush 20
    //   935: if_icmplt +45 -> 980
    //   938: aload_0
    //   939: aload_3
    //   940: invokevirtual 521	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   943: invokevirtual 520	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   946: putfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   949: aload_2
    //   950: invokeinterface 306 1 0
    //   955: astore_3
    //   956: aload_3
    //   957: ldc_w 505
    //   960: aload_0
    //   961: getfield 116	com/AdX/tag/AdXConnect:deviceID	Ljava/lang/String;
    //   964: invokeinterface 314 3 0
    //   969: pop
    //   970: aload_3
    //   971: invokeinterface 318 1 0
    //   976: pop
    //   977: goto -745 -> 232
    //   980: aload_3
    //   981: ldc_w 523
    //   984: invokestatic 529	java/lang/Math:random	()D
    //   987: ldc2_w 530
    //   990: dmul
    //   991: d2i
    //   992: bipush 30
    //   994: irem
    //   995: invokevirtual 535	java/lang/String:charAt	(I)C
    //   998: invokevirtual 538	java/lang/StringBuffer:append	(C)Ljava/lang/StringBuffer;
    //   1001: pop
    //   1002: iload_1
    //   1003: iconst_1
    //   1004: iadd
    //   1005: istore_1
    //   1006: goto -74 -> 932
    //   1009: astore_3
    //   1010: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   1013: ifeq -751 -> 262
    //   1016: ldc -80
    //   1018: new 279	java/lang/StringBuilder
    //   1021: dup
    //   1022: ldc_w 540
    //   1025: invokespecial 284	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   1028: aload_3
    //   1029: invokevirtual 287	java/lang/Exception:toString	()Ljava/lang/String;
    //   1032: invokevirtual 291	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1035: invokevirtual 292	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1038: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   1041: pop
    //   1042: goto -780 -> 262
    //   1045: getstatic 103	com/AdX/tag/AdXConnect:WARN	Z
    //   1048: ifeq +12 -> 1060
    //   1051: ldc -80
    //   1053: ldc_w 493
    //   1056: invokestatic 295	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   1059: pop
    //   1060: return
    //   1061: iconst_1
    //   1062: istore_1
    //   1063: goto -297 -> 766
    //   1066: iconst_1
    //   1067: istore_1
    //   1068: goto -302 -> 766
    //   1071: iconst_0
    //   1072: istore_1
    //   1073: goto -141 -> 932
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1076	0	this	AdXConnect
    //   740	333	1	i	int
    //   7	280	2	localObject1	Object
    //   701	249	2	localNameNotFoundException	android.content.pm.PackageManager.NameNotFoundException
    //   39	740	3	localObject2	Object
    //   823	117	3	localException1	Exception
    //   955	26	3	localEditor	SharedPreferences.Editor
    //   1009	20	3	localException2	Exception
    //   61	755	4	str	String
    // Exception table:
    //   from	to	target	type
    //   8	40	701	android/content/pm/PackageManager$NameNotFoundException
    //   44	63	701	android/content/pm/PackageManager$NameNotFoundException
    //   68	99	701	android/content/pm/PackageManager$NameNotFoundException
    //   104	214	701	android/content/pm/PackageManager$NameNotFoundException
    //   218	232	701	android/content/pm/PackageManager$NameNotFoundException
    //   232	262	701	android/content/pm/PackageManager$NameNotFoundException
    //   262	273	701	android/content/pm/PackageManager$NameNotFoundException
    //   277	290	701	android/content/pm/PackageManager$NameNotFoundException
    //   290	305	701	android/content/pm/PackageManager$NameNotFoundException
    //   305	343	701	android/content/pm/PackageManager$NameNotFoundException
    //   343	381	701	android/content/pm/PackageManager$NameNotFoundException
    //   381	419	701	android/content/pm/PackageManager$NameNotFoundException
    //   419	457	701	android/content/pm/PackageManager$NameNotFoundException
    //   457	495	701	android/content/pm/PackageManager$NameNotFoundException
    //   495	533	701	android/content/pm/PackageManager$NameNotFoundException
    //   533	571	701	android/content/pm/PackageManager$NameNotFoundException
    //   571	609	701	android/content/pm/PackageManager$NameNotFoundException
    //   609	647	701	android/content/pm/PackageManager$NameNotFoundException
    //   647	684	701	android/content/pm/PackageManager$NameNotFoundException
    //   685	700	701	android/content/pm/PackageManager$NameNotFoundException
    //   718	733	701	android/content/pm/PackageManager$NameNotFoundException
    //   734	739	701	android/content/pm/PackageManager$NameNotFoundException
    //   741	763	701	android/content/pm/PackageManager$NameNotFoundException
    //   770	799	701	android/content/pm/PackageManager$NameNotFoundException
    //   804	820	701	android/content/pm/PackageManager$NameNotFoundException
    //   824	856	701	android/content/pm/PackageManager$NameNotFoundException
    //   856	861	701	android/content/pm/PackageManager$NameNotFoundException
    //   864	900	701	android/content/pm/PackageManager$NameNotFoundException
    //   900	915	701	android/content/pm/PackageManager$NameNotFoundException
    //   918	929	701	android/content/pm/PackageManager$NameNotFoundException
    //   938	977	701	android/content/pm/PackageManager$NameNotFoundException
    //   980	1002	701	android/content/pm/PackageManager$NameNotFoundException
    //   1010	1042	701	android/content/pm/PackageManager$NameNotFoundException
    //   1045	1060	701	android/content/pm/PackageManager$NameNotFoundException
    //   734	739	823	java/lang/Exception
    //   741	763	823	java/lang/Exception
    //   770	799	823	java/lang/Exception
    //   804	820	823	java/lang/Exception
    //   864	900	823	java/lang/Exception
    //   900	915	823	java/lang/Exception
    //   918	929	823	java/lang/Exception
    //   938	977	823	java/lang/Exception
    //   980	1002	823	java/lang/Exception
    //   232	262	1009	java/lang/Exception
  }
  
  public static String getFacebookAttributionId(Context paramContext)
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = "aid";
    String str = "";
    try
    {
      Object localObject = paramContext.getContentResolver().query(ATTRIBUTION_ID_CONTENT_URI, arrayOfString, null, null, null);
      if ((localObject == null) || (!((Cursor)localObject).moveToFirst())) {
        break label168;
      }
      localObject = ((Cursor)localObject).getString(((Cursor)localObject).getColumnIndex("aid"));
      paramContext = (Context)localObject;
    }
    catch (Exception localException1)
    {
      for (;;)
      {
        if (DEBUG) {
          Log.i("AdXAppTracker", localException1.getMessage());
        }
        if (DEBUG) {
          Log.i("AdXAppTracker", "Retry");
        }
        try
        {
          paramContext = paramContext.getContentResolver().query(ATTRIBUTION_ID_CONTENT_URI, arrayOfString, null, null, null);
          if ((paramContext == null) || (!paramContext.moveToFirst())) {
            break;
          }
          paramContext = paramContext.getString(paramContext.getColumnIndex("aid"));
        }
        catch (Exception localException2)
        {
          paramContext = str;
        }
        if (DEBUG)
        {
          Log.i("AdXAppTracker", localException2.getMessage());
          paramContext = str;
        }
      }
    }
    return paramContext;
    label168:
    return null;
    return null;
  }
  
  private String getNodeTrimValue(NodeList paramNodeList)
  {
    Object localObject2 = null;
    Object localObject3 = (Element)paramNodeList.item(0);
    paramNodeList = "";
    Object localObject1 = localObject2;
    int j;
    int i;
    if (localObject3 != null)
    {
      localObject3 = ((Element)localObject3).getChildNodes();
      j = ((NodeList)localObject3).getLength();
      i = 0;
    }
    for (;;)
    {
      if (i >= j)
      {
        localObject1 = localObject2;
        if (paramNodeList != null)
        {
          localObject1 = localObject2;
          if (!paramNodeList.equals("")) {
            localObject1 = paramNodeList.trim();
          }
        }
        return (String)localObject1;
      }
      Node localNode = ((NodeList)localObject3).item(i);
      localObject1 = paramNodeList;
      if (localNode != null) {
        localObject1 = paramNodeList + localNode.getNodeValue();
      }
      i += 1;
      paramNodeList = (NodeList)localObject1;
    }
  }
  
  private boolean handleConnectResponse(String paramString)
  {
    paramString = buildDocument(paramString);
    if (paramString != null)
    {
      String str = getNodeTrimValue(paramString.getElementsByTagName("Referral"));
      if (str != null)
      {
        if (DEBUG) {
          Log.i("AdXAppTracker", "Successfully get returned referral " + str);
        }
        SharedPreferences.Editor localEditor = this.context.getSharedPreferences(AdX_PREFERENCE, 0).edit();
        localEditor.putString(MODREFERRAL, str);
        localEditor.commit();
      }
      paramString = getNodeTrimValue(paramString.getElementsByTagName("Success"));
      if ((paramString != null) && (paramString.equals("true")))
      {
        if (DEBUG) {
          Log.i("AdXAppTracker", "Successfully connected to AdX site.");
        }
        return true;
      }
      if ((paramString != null) && (paramString.equals("stop")))
      {
        if (DEBUG) {
          Log.i("AdXAppTracker", "Successfully connected to AdX site - stopping tags from now on.");
        }
        paramString = this.context.getSharedPreferences(AdX_PREFERENCE, 0).edit();
        paramString.putString(this.SEND_TAG, "stop");
        paramString.commit();
        return true;
      }
      if (WARN) {
        Log.e("AdXAppTracker", "AdX Connect call failed.");
      }
    }
    return false;
  }
  
  public void finalize()
  {
    AdXConnectInstance = null;
    AdXConnectEventInstance = null;
    if (DEBUG) {
      Log.i("AdX App Tracker", "Cleaning resources.");
    }
  }
  
  private class ConnectEventTask
    extends AsyncTask<String, Void, Boolean>
  {
    private ConnectEventTask() {}
    
    protected Boolean doInBackground(String... paramVarArgs)
    {
      boolean bool = false;
      AdXConnect.this.getApplicationData();
      if (AdXConnect.DEBUG) {
        Log.i("AdXAppTracker", "Got Application Data ");
      }
      String str = new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf("")).append("udid=").append(AdXConnect.this.deviceID).append("&").toString())).append("androidID=").append(AdXConnect.this.androidID).append("&").toString())).append("device_name=").append(AdXConnect.this.deviceName).append("&").toString())).append("device_type=").append(AdXConnect.this.deviceType).append("&").toString())).append("os_version=").append(AdXConnect.this.deviceOSVersion).append("&").toString())).append("country_code=").append(AdXConnect.this.deviceCountryCode).append("&").toString())).append("language=").append(AdXConnect.this.deviceLanguage).append("&").toString())).append("app_id=").append(AdXConnect.this.appID).append("&").toString())).append("event=").append(paramVarArgs[0]).append("&").toString())).append("data=").append(paramVarArgs[1]).append("&").toString() + "currency=" + paramVarArgs[2];
      paramVarArgs = str;
      if (!AdXConnect.this.AdXClickURL.equals("")) {
        paramVarArgs = str + "AdXClickURL=" + AdXConnect.this.AdXClickURL;
      }
      paramVarArgs = AdXURLConnection.connectToURL("http://ad-x.co.uk/API/androidevent.php?oursecret=" + AdXConnect.this.clientID + "&", paramVarArgs);
      if (paramVarArgs != null) {
        bool = AdXConnect.this.handleConnectResponse(paramVarArgs);
      }
      return Boolean.valueOf(bool);
    }
  }
  
  private class ConnectTask
    extends AsyncTask<Integer, Void, Boolean>
  {
    private ConnectTask() {}
    
    protected Boolean doInBackground(Integer... paramVarArgs)
    {
      boolean bool = false;
      AdXConnect.this.getApplicationData();
      AdXConnect.this.fbattribution = AdXConnect.getFacebookAttributionId(AdXConnect.this.context);
      Object localObject = new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf("")).append("udid=").append(AdXConnect.this.deviceID).append("&").toString())).append("androidID=").append(AdXConnect.this.androidID).append("&").toString())).append("device_name=").append(AdXConnect.this.deviceName).append("&").toString())).append("device_type=").append(AdXConnect.this.deviceType).append("&").toString())).append("os_version=").append(AdXConnect.this.deviceOSVersion).append("&").toString())).append("country_code=").append(AdXConnect.this.deviceCountryCode).append("&").toString())).append("language=").append(AdXConnect.this.deviceLanguage).append("&").toString())).append("app_id=").append(AdXConnect.this.appID).append("&").toString())).append("clientid=").append(AdXConnect.this.clientID).append("&").toString())).append("app_version=").append(AdXConnect.this.appVersion).append("&").toString())).append("tag_version=").append(AdXConnect.this.tagVersion).append("&").toString())).append("fbattribution=").append(AdXConnect.this.fbattribution).append("&").toString() + "update=" + paramVarArgs[0];
      paramVarArgs = (Integer[])localObject;
      if (AdXConnect.this.deviceScreenDensity.length() > 0)
      {
        paramVarArgs = (Integer[])localObject;
        if (AdXConnect.this.deviceScreenLayoutSize.length() > 0) {
          paramVarArgs = new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(localObject)).append("&").toString())).append("screen_density=").append(AdXConnect.this.deviceScreenDensity).append("&").toString() + "screen_layout_size=" + AdXConnect.this.deviceScreenLayoutSize;
        }
      }
      localObject = paramVarArgs;
      if (!AdXConnect.referralURL.equals("")) {
        localObject = paramVarArgs + "&" + AdXConnect.referralURL;
      }
      paramVarArgs = AdXURLConnection.connectToURL("http://ad-x.co.uk/atrk/andrdapp?", (String)localObject);
      if (paramVarArgs != null) {
        bool = AdXConnect.this.handleConnectResponse(paramVarArgs);
      }
      return Boolean.valueOf(bool);
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/AdX/tag/AdXConnect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */