package com.AdX.tag;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

public class AdXURLConnection
{
  public static String connectToURL(String paramString1, String paramString2)
  {
    try
    {
      paramString1 = new HttpGet((paramString1 + paramString2).replaceAll(" ", "%20"));
      paramString2 = new BasicHttpParams();
      HttpConnectionParams.setConnectionTimeout(paramString2, 15000);
      HttpConnectionParams.setSoTimeout(paramString2, 30000);
      paramString1 = EntityUtils.toString(new DefaultHttpClient(paramString2).execute(paramString1).getEntity());
      return paramString1;
    }
    catch (Exception paramString1) {}
    return null;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/AdX/tag/AdXURLConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */