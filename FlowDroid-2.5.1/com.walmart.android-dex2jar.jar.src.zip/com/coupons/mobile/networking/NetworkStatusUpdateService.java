package com.coupons.mobile.networking;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Binder;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.SparseArray;

public class NetworkStatusUpdateService
  extends Service
{
  private static boolean sConnected = true;
  private static int sHandle = 0;
  private static NetworkInfo sNetworkInfo = null;
  private static Long sSequence = new Long(0L);
  private static NetworkState sState = NetworkState.NORMAL;
  private final SparseArray<CallbackPackage> mCallbacks = new SparseArray();
  private final IBinder mLocalBinder = new LocalBinder();
  private NetworkBroadcastReceiver mReceiver;
  
  public IBinder onBind(Intent paramIntent)
  {
    if (NetworkLogging.isLoggable()) {
      NetworkLogging.logv("binding service implementation");
    }
    return this.mLocalBinder;
  }
  
  public void onCreate()
  {
    this.mReceiver = new NetworkBroadcastReceiver(null);
    IntentFilter localIntentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
    registerReceiver(this.mReceiver, localIntentFilter);
  }
  
  public void onDestroy()
  {
    this.mCallbacks.clear();
    unregisterReceiver(this.mReceiver);
    this.mReceiver = null;
  }
  
  public void onStart(Intent paramIntent, int paramInt) {}
  
  public int registerNetworkStatusUpdateCallback(Callback paramCallback, int paramInt, boolean paramBoolean)
    throws RemoteException
  {
    synchronized (this.mCallbacks)
    {
      sHandle += 1;
      Object localObject = new CallbackPackage(paramCallback, paramInt, null);
      this.mCallbacks.put(sHandle, localObject);
      if (NetworkLogging.isLoggable()) {
        NetworkLogging.logv("registering callback " + paramCallback.getClass().toString() + " : " + paramInt);
      }
      if (paramBoolean)
      {
        localObject = sSequence;
        sSequence = Long.valueOf(sSequence.longValue() + 1L);
        if (NetworkLogging.isLoggable()) {
          NetworkLogging.logv("broadcasting initial network status to " + paramCallback.getClass().toString() + " : " + paramInt);
        }
        paramCallback.onStatusChanged(sConnected, sState.ordinal(), sSequence.longValue(), paramInt);
      }
      paramInt = sHandle;
      return paramInt;
    }
  }
  
  public void unregisterNetworkStatusUpdateCallback(int paramInt)
    throws RemoteException
  {
    synchronized (this.mCallbacks)
    {
      CallbackPackage localCallbackPackage = (CallbackPackage)this.mCallbacks.get(paramInt);
      if (localCallbackPackage != null)
      {
        if (NetworkLogging.isLoggable()) {
          NetworkLogging.logv("unregistering callback " + localCallbackPackage.mCallback.getClass().toString() + " : " + localCallbackPackage.mCookie);
        }
        this.mCallbacks.remove(paramInt);
      }
      return;
    }
  }
  
  public static abstract interface Callback
  {
    public abstract void onStatusChanged(boolean paramBoolean, int paramInt1, long paramLong, int paramInt2);
  }
  
  private class CallbackPackage
  {
    private NetworkStatusUpdateService.Callback mCallback;
    private int mCookie;
    
    private CallbackPackage(NetworkStatusUpdateService.Callback paramCallback, int paramInt)
    {
      this.mCallback = paramCallback;
      this.mCookie = paramInt;
    }
  }
  
  public class LocalBinder
    extends Binder
  {
    public LocalBinder() {}
    
    public NetworkStatusUpdateService getService()
    {
      return NetworkStatusUpdateService.this;
    }
  }
  
  private final class NetworkBroadcastReceiver
    extends BroadcastReceiver
  {
    private NetworkBroadcastReceiver() {}
    
    public void onReceive(Context paramContext, Intent paramIntent)
    {
      boolean bool = false;
      if ((paramIntent == null) || (paramIntent.getAction() == null)) {}
      while (!paramIntent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) {
        return;
      }
      for (;;)
      {
        synchronized (NetworkStatusUpdateService.this.mCallbacks)
        {
          NetworkStatusUpdateService.access$402(Long.valueOf(NetworkStatusUpdateService.sSequence.longValue() + 1L));
          paramContext = ((ConnectivityManager)NetworkStatusUpdateService.this.getSystemService("connectivity")).getActiveNetworkInfo();
          if (paramContext != null) {
            bool = true;
          }
          NetworkStatusUpdateService.access$502(bool);
          if (paramContext != null)
          {
            if (NetworkLogging.isLoggable()) {
              NetworkLogging.logv("ActiveNetwork - isAvailable = " + paramContext.isAvailable() + "  isConnected = " + paramContext.isConnected() + " n/w type = " + paramContext.getTypeName());
            }
            NetworkStatusUpdateService.access$602((NetworkInfo)paramIntent.getParcelableExtra("networkInfo"));
            if (paramIntent.getBooleanExtra("isFailover", false))
            {
              paramContext = NetworkStatusUpdateService.NetworkState.FAILOVER;
              NetworkStatusUpdateService.access$702(paramContext);
              int i = 0;
              if (i >= NetworkStatusUpdateService.this.mCallbacks.size()) {
                break;
              }
              paramContext = (NetworkStatusUpdateService.CallbackPackage)NetworkStatusUpdateService.this.mCallbacks.valueAt(i);
              if (NetworkLogging.isLoggable()) {
                NetworkLogging.logv("broadcasting network change to " + paramContext.mCallback.getClass().toString() + " : " + paramContext.mCookie);
              }
              paramContext.mCallback.onStatusChanged(NetworkStatusUpdateService.sConnected, NetworkStatusUpdateService.sState.ordinal(), NetworkStatusUpdateService.sSequence.longValue(), paramContext.mCookie);
              i += 1;
              continue;
            }
          }
          else
          {
            if (!NetworkLogging.isLoggable()) {
              continue;
            }
            NetworkLogging.logv("ActiveNetwork - is NULL");
          }
        }
        paramContext = NetworkStatusUpdateService.NetworkState.NORMAL;
      }
    }
  }
  
  public static enum NetworkState
  {
    FAILOVER,  NORMAL;
    
    private NetworkState() {}
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/NetworkStatusUpdateService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */