package com.coupons.mobile.networking;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.AbstractHttpEntity;
import org.ksoap2.transport.ServiceConnection;

public class CIServiceConnection
  implements ServiceConnection
{
  protected static final String HEADER_KEY_APP_ID = "CI-Mobile-AppId";
  protected static final String HEADER_KEY_APP_VERSION = "CI-Mobile-AppVer";
  protected static final String HEADER_KEY_DEVICE_TYPE = "CI-Mobile-DeviceType";
  protected static final String HEADER_KEY_OS_NAME = "CI-Mobile-OSName";
  protected static final String HEADER_KEY_OS_VERSION = "CI-Mobile-OSVer";
  private CIHttpClient mClient = null;
  private int mInStreamLength = 0;
  private HttpPost mMessage = null;
  private HttpResponse mResponse = null;
  
  public CIServiceConnection(String paramString)
    throws IOException
  {
    this.mMessage = new HttpPost(paramString);
    this.mMessage.addHeader("Accept-Encoding", "gzip");
  }
  
  public CIServiceConnection(String paramString, AppInfo paramAppInfo)
    throws IOException
  {
    this(paramString);
    this.mMessage.addHeader("CI-Mobile-AppId", paramAppInfo.getAppId());
    this.mMessage.addHeader("CI-Mobile-AppVer", paramAppInfo.getAppVersion());
    this.mMessage.addHeader("CI-Mobile-OSName", paramAppInfo.getOSName());
    this.mMessage.addHeader("CI-Mobile-OSVer", paramAppInfo.getOSVersion());
    this.mMessage.addHeader("CI-Mobile-DeviceType", paramAppInfo.getDeviceType());
  }
  
  public void connect()
    throws IOException
  {
    this.mResponse = this.mClient.execute(this.mMessage);
    this.mInStreamLength = ((int)this.mResponse.getEntity().getContentLength());
    StatusLine localStatusLine = this.mResponse.getStatusLine();
    if (localStatusLine.getStatusCode() != 200) {
      throw new IOException("CIHttpClient status returned: " + localStatusLine.getStatusCode());
    }
  }
  
  public void disconnect()
  {
    this.mClient.close();
    this.mClient = null;
    this.mMessage = null;
    this.mResponse = null;
  }
  
  public InputStream getErrorStream()
  {
    return null;
  }
  
  public int getInputStreamLength()
    throws IOException
  {
    return this.mInStreamLength;
  }
  
  public void logHeaders()
  {
    Header[] arrayOfHeader = this.mMessage.getAllHeaders();
    NetworkLogging.logv("Headers:\n");
    int j = arrayOfHeader.length;
    int i = 0;
    while (i < j)
    {
      Header localHeader = arrayOfHeader[i];
      NetworkLogging.logv("Request header: (" + localHeader.getName() + ":" + localHeader.getValue() + ")");
      i += 1;
    }
  }
  
  public InputStream openInputStream()
    throws IOException
  {
    if (this.mInStreamLength <= 0) {
      throw new IOException("HttpEntity content is empty");
    }
    return CIHttpClient.getUngzippedContent(this.mResponse.getEntity());
  }
  
  public OutputStream openOutputStream()
    throws IOException
  {
    return null;
  }
  
  public void setEntity(AbstractHttpEntity paramAbstractHttpEntity)
    throws IOException
  {
    this.mMessage.setEntity(paramAbstractHttpEntity);
  }
  
  public void setRequestMethod(String paramString)
    throws IOException
  {}
  
  public void setRequestProperty(String paramString1, String paramString2)
  {
    this.mMessage.addHeader(paramString1, paramString2);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/CIServiceConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */