package com.coupons.mobile.networking;

import android.os.Environment;
import android.util.Log;
import java.io.FileWriter;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NetworkLogging
{
  public static final String TAG = "NW";
  
  public static boolean isLoggable()
  {
    return Log.isLoggable("NW", 2);
  }
  
  public static void logToFile(String paramString)
  {
    try
    {
      Object localObject = Environment.getExternalStorageDirectory() + "/giqNW" + ".txt";
      Log.d("NW", "Log to File " + (String)localObject);
      localObject = new FileWriter((String)localObject, true);
      Date localDate = new Date();
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("hh:mm:ss a");
      ((FileWriter)localObject).append(localSimpleDateFormat.format(localDate) + "\n");
      ((FileWriter)localObject).append(paramString);
      ((FileWriter)localObject).append("\n");
      ((FileWriter)localObject).flush();
      ((FileWriter)localObject).close();
      return;
    }
    catch (IOException paramString)
    {
      paramString.printStackTrace();
    }
  }
  
  public static void logv(String paramString)
  {
    if (paramString == null) {
      return;
    }
    Log.v("NW", paramString);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/NetworkLogging.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */