package com.coupons.mobile.networking.security;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Authorization
{
  private static final Date EXPIRATION_DATE = new Date(110, 0, 20);
  private static final DateFormat UTC_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  private static DefaultHandler sHandler = new DefaultHandler()
  {
    private boolean mIsReadingUTCTime;
    
    public void characters(char[] paramAnonymousArrayOfChar, int paramAnonymousInt1, int paramAnonymousInt2)
      throws SAXException
    {
      if (this.mIsReadingUTCTime) {
        paramAnonymousArrayOfChar = new String(paramAnonymousArrayOfChar, paramAnonymousInt1, paramAnonymousInt2);
      }
      try
      {
        paramAnonymousArrayOfChar = Authorization.UTC_FORMAT.parse(paramAnonymousArrayOfChar);
        Authorization.access$102(paramAnonymousArrayOfChar.before(Authorization.EXPIRATION_DATE));
        return;
      }
      catch (ParseException paramAnonymousArrayOfChar)
      {
        throw new SAXException(paramAnonymousArrayOfChar);
      }
    }
    
    public void endElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3)
      throws SAXException
    {
      if (paramAnonymousString2.equals("utctime")) {
        this.mIsReadingUTCTime = false;
      }
    }
    
    public void startElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3, Attributes paramAnonymousAttributes)
      throws SAXException
    {
      if (paramAnonymousString2.equals("utctime")) {
        this.mIsReadingUTCTime = true;
      }
    }
  };
  private static boolean sIsAuthorized;
  
  public static boolean isAuthorized()
  {
    return true;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/security/Authorization.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */