package com.coupons.mobile.networking.security;

import android.content.Context;

public final class UserInfo
{
  private static final String TAG = "giq_keystore";
  private static Context sContext = null;
  private static UserInfo sInstance = null;
  private static IUserDetails userDetails = null;
  private byte[] mEmailAddress = null;
  private boolean mIsLoginDataValid = false;
  private byte[] mPassword = null;
  private byte[] mUserId = null;
  private byte[] mZipcode = null;
  
  private static UserInfo getInstance()
  {
    try
    {
      if (sInstance == null) {
        sInstance = new UserInfo();
      }
      UserInfo localUserInfo = sInstance;
      return localUserInfo;
    }
    finally {}
  }
  
  public static UserInfo getInstance(Context paramContext)
  {
    if (sInstance == null)
    {
      if (sContext == null)
      {
        if (paramContext == null) {
          throw new RuntimeException("Initial getInstance() call must specify an application parameter.");
        }
        sContext = paramContext;
      }
      sInstance = getInstance();
      userDetails = (IUserDetails)paramContext;
    }
    return sInstance;
  }
  
  public byte[] getEmailAddress()
  {
    try
    {
      byte[] arrayOfByte = userDetails.getEmailAddress();
      return arrayOfByte;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public byte[] getPassword()
  {
    try
    {
      byte[] arrayOfByte = userDetails.getPassword();
      return arrayOfByte;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public byte[] getUserId()
  {
    try
    {
      byte[] arrayOfByte = userDetails.getUserId();
      return arrayOfByte;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public byte[] getZipcode()
  {
    try
    {
      byte[] arrayOfByte = userDetails.getZipcode();
      return arrayOfByte;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public boolean isLoginDataValid()
  {
    return userDetails.isLoginDataValid();
  }
  
  public void logout(boolean paramBoolean)
  {
    userDetails.logout(paramBoolean);
  }
  
  public void setEmailAddress(byte[] paramArrayOfByte)
  {
    try
    {
      userDetails.setEmailAddress(paramArrayOfByte);
      return;
    }
    finally
    {
      paramArrayOfByte = finally;
      throw paramArrayOfByte;
    }
  }
  
  public void setPassword(byte[] paramArrayOfByte)
  {
    try
    {
      userDetails.setPassword(paramArrayOfByte);
      return;
    }
    finally
    {
      paramArrayOfByte = finally;
      throw paramArrayOfByte;
    }
  }
  
  public void setUserId(byte[] paramArrayOfByte)
  {
    try
    {
      userDetails.setUserId(paramArrayOfByte);
      return;
    }
    finally
    {
      paramArrayOfByte = finally;
      throw paramArrayOfByte;
    }
  }
  
  public void setZipcode(byte[] paramArrayOfByte)
  {
    try
    {
      userDetails.setZipcode(paramArrayOfByte);
      return;
    }
    finally
    {
      paramArrayOfByte = finally;
      throw paramArrayOfByte;
    }
  }
  
  public static abstract interface IUserDetails
  {
    public abstract byte[] getEmailAddress();
    
    public abstract byte[] getPassword();
    
    public abstract byte[] getUserId();
    
    public abstract byte[] getZipcode();
    
    public abstract boolean isLoginDataValid();
    
    public abstract void logout(boolean paramBoolean);
    
    public abstract void saveKeyStore();
    
    public abstract void saveKeyStore(boolean paramBoolean);
    
    public abstract void setEmailAddress(byte[] paramArrayOfByte);
    
    public abstract void setPassword(byte[] paramArrayOfByte);
    
    public abstract void setUserId(byte[] paramArrayOfByte);
    
    public abstract void setZipcode(byte[] paramArrayOfByte);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/security/UserInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */