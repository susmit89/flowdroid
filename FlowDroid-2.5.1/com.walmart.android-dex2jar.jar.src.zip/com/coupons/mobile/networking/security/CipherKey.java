package com.coupons.mobile.networking.security;

import android.util.Log;
import java.util.Arrays;

public class CipherKey
{
  private static boolean DEBUG_FLAG = false;
  public static String DECODE_STR = " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._!%@$&";
  public static final int DECODE_STR_LEN = DECODE_STR.length();
  private static final String ENCODE_DUMMY_STRING_A = "               ";
  private static final String ENCODE_DUMMY_STRING_B = " couponsincproductio";
  private static String TAG = "Networking";
  private static String longKey;
  private static String shortKey;
  
  public static final String decode(String paramString1, String paramString2)
  {
    Object localObject1 = new int['Ā'];
    int[] arrayOfInt1 = new int['Ā'];
    Object localObject3 = new int[2];
    int i = paramString2.length();
    localObject3[0] = Integer.parseInt(paramString2.substring(i - 2, i));
    localObject3[1] = Integer.parseInt(paramString2.substring(i - 4, i - 2));
    Arrays.fill((int[])localObject1, -1);
    Arrays.fill(arrayOfInt1, -1);
    Object localObject4 = getShortKey();
    Object localObject2 = getLongKey();
    i = 0;
    while (i < DECODE_STR_LEN)
    {
      localObject1[DECODE_STR.charAt(i)] = i;
      arrayOfInt1[localObject2.charAt(i)] = i;
      i += 1;
    }
    localObject2 = new StringBuffer(paramString1.length());
    int j = ((String)localObject4).length();
    int[] arrayOfInt3 = new int[j * 2];
    int[] arrayOfInt4 = new int[j * 2];
    int[] arrayOfInt2 = new int[j * 2];
    i = 0;
    while (i < j)
    {
      arrayOfInt3[i] = (localObject1[localObject4.charAt(i)] * 2);
      arrayOfInt4[i] = localObject3[(i % 2)];
      arrayOfInt3[i] += arrayOfInt4[i];
      i += 1;
    }
    i = j;
    while (i < j * 2)
    {
      arrayOfInt3[i] = (localObject1[localObject4.charAt(i - j)] * 2);
      arrayOfInt4[i] = localObject3[(i % 2)];
      arrayOfInt3[i] += arrayOfInt4[i];
      i += 1;
    }
    int n = j * 2;
    j = 0;
    int k = 0;
    i = 0;
    if (i < paramString1.length())
    {
      int m = paramString1.codePointAt(i);
      localObject1 = paramString1.substring(i, i + 1);
      if (m < 256)
      {
        m = arrayOfInt1[m];
        if (m >= 0)
        {
          k += 1;
          int i1 = (DECODE_STR_LEN * 40 + m - j - arrayOfInt2[(k % n)]) % DECODE_STR_LEN;
          if (DEBUG_FLAG)
          {
            localObject3 = TAG;
            localObject4 = new StringBuilder().append("i = ").append(i).append(" decodedChar = ");
            if (i1 > 0)
            {
              localObject1 = Character.valueOf(DECODE_STR.charAt(i1));
              label404:
              Log.d((String)localObject3, localObject1 + " myDecode = " + i1 + " encThis = " + m + " encLast = " + j + " SumArray[mw%k] = " + arrayOfInt2[(k % n)] + " DECODE_STR_LEN = " + DECODE_STR_LEN);
            }
          }
          else
          {
            ((StringBuffer)localObject2).append(DECODE_STR.charAt(i1));
            j = m;
          }
        }
      }
      for (;;)
      {
        i += 1;
        break;
        localObject1 = "";
        break label404;
        if (DEBUG_FLAG) {
          Log.d(TAG, "i = " + i + " decodedChar = " + (String)localObject1);
        }
        ((StringBuffer)localObject2).append((String)localObject1);
        continue;
        if (DEBUG_FLAG) {
          Log.d(TAG, "i = " + i + " decodedChar = " + (String)localObject1);
        }
        ((StringBuffer)localObject2).append((String)localObject1);
      }
    }
    paramString1 = "";
    i = ((StringBuffer)localObject2).length();
    if (paramString2.equals(((StringBuffer)localObject2).substring(i - paramString2.length(), i))) {
      paramString1 = ((StringBuffer)localObject2).substring(0, i - paramString2.length()).trim();
    }
    return paramString1;
  }
  
  public static final String encode(String paramString1, String paramString2)
  {
    int[] arrayOfInt1 = new int['Ā'];
    Object localObject = new int[2];
    int i = paramString2.length();
    localObject[0] = Integer.parseInt(paramString2.substring(i - 2, i));
    localObject[1] = Integer.parseInt(paramString2.substring(i - 4, i - 2));
    Arrays.fill(arrayOfInt1, -1);
    i = 0;
    while (i < DECODE_STR_LEN)
    {
      arrayOfInt1[DECODE_STR.charAt(i)] = i;
      i += 1;
    }
    paramString1 = new StringBuffer(" couponsincproductio".length()).append(paramString1);
    if (paramString1.length() < "               ".length()) {
      paramString1.append("               ", 0, "               ".length() - paramString1.length());
    }
    paramString1.append(paramString2);
    if (paramString1.length() < " couponsincproductio".length()) {
      paramString1.append(" couponsincproductio", 0, " couponsincproductio".length() - paramString1.length());
    }
    String str = getShortKey();
    paramString2 = getLongKey();
    int j = 0;
    int k = 0;
    int n = paramString1.length();
    int m = str.length();
    StringBuffer localStringBuffer = new StringBuffer(paramString1.length());
    int[] arrayOfInt3 = new int[m * 2];
    int[] arrayOfInt4 = new int[m * 2];
    int[] arrayOfInt2 = new int[m * 2];
    i = 0;
    while (i < m)
    {
      arrayOfInt3[i] = (arrayOfInt1[str.charAt(i)] * 2);
      arrayOfInt4[i] = localObject[(i % 2)];
      arrayOfInt3[i] += arrayOfInt4[i];
      i += 1;
    }
    i = m;
    while (i < m * 2)
    {
      arrayOfInt3[i] = (arrayOfInt1[str.charAt(i - m)] * 2);
      arrayOfInt4[i] = localObject[(i % 2)];
      arrayOfInt3[i] += arrayOfInt4[i];
      i += 1;
    }
    i = 0;
    if (i < n)
    {
      int i1 = paramString1.codePointAt(i);
      localObject = paramString1.substring(i, i + 1);
      if (i1 < 256)
      {
        i1 = arrayOfInt1[i1];
        if (i1 >= 0)
        {
          k += 1;
          j = (j + i1 + arrayOfInt2[(k % (m * 2))]) % DECODE_STR_LEN;
          localStringBuffer.append(paramString2.charAt(j));
        }
      }
      for (;;)
      {
        i += 1;
        break;
        localStringBuffer.append((String)localObject);
        continue;
        localStringBuffer.append((String)localObject);
      }
    }
    return localStringBuffer.toString();
  }
  
  public static final String getLongKey()
  {
    return longKey;
  }
  
  public static final String getShortKey()
  {
    return shortKey;
  }
  
  public static void setLongKey(String paramString)
  {
    longKey = paramString;
  }
  
  public static void setShortKey(String paramString)
  {
    shortKey = paramString;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/security/CipherKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */