package com.coupons.mobile.networking;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.io.IOException;
import java.util.StringTokenizer;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.transport.AndroidHttpTransport;
import org.xmlpull.v1.XmlPullParserException;

public class LocalTransport
  extends AndroidHttpTransport
  implements Transport
{
  private static final String DELIMITER = "/";
  private static final String EXTENSION = ".xml";
  private Context mContext;
  
  public LocalTransport(String paramString, Context paramContext)
  {
    super(paramString);
    this.mContext = paramContext;
  }
  
  public void call(String paramString, SoapEnvelope paramSoapEnvelope)
    throws IOException, XmlPullParserException
  {
    paramString = getRequestName(paramString);
    paramString = paramString + ".xml";
    parseResponse(paramSoapEnvelope, this.mContext.getResources().getAssets().open(paramString));
  }
  
  public String getRequestName(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, "/");
    for (paramString = ""; localStringTokenizer.hasMoreTokens(); paramString = localStringTokenizer.nextToken()) {}
    return paramString;
  }
  
  public void logRequest() {}
  
  public void logResponse() {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/LocalTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */