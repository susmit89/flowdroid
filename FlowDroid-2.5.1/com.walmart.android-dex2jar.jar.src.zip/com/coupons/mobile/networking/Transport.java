package com.coupons.mobile.networking;

import java.io.IOException;
import org.ksoap2.SoapEnvelope;
import org.xmlpull.v1.XmlPullParserException;

public abstract interface Transport
{
  public abstract void call(String paramString, SoapEnvelope paramSoapEnvelope)
    throws IOException, XmlPullParserException;
  
  public abstract void logRequest();
  
  public abstract void logResponse();
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/Transport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */