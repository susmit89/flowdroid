package com.coupons.mobile.networking;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public abstract class NetworkActivityHelper
{
  public static final int DIALOG_NETWORK_PROGRESS = -2;
  public static final int DIALOG_NETWORK_TIMEOUT = -1;
  public static final int NETWORK_TIMEOUT_DELAY = 15000;
  private static final String TAG = "giq_network_activity_helper";
  private Handler mActivityHandler = null;
  private DialogInterface.OnClickListener mDialogListener = new DialogInterface.OnClickListener()
  {
    public void onClick(DialogInterface arg1, int paramAnonymousInt)
    {
      switch (paramAnonymousInt)
      {
      default: 
        return;
      case -1: 
        if (NetworkActivityHelper.this.getProgressDialogMessage() != 0) {
          NetworkActivityHelper.this.mTargetActivity.showDialog(-2);
        }
        if (NetworkActivityHelper.this.mNetworkThread == null) {
          NetworkActivityHelper.this.mNetworkTimeoutHandler.sendEmptyMessageDelayed(R.id.msg_network_timout, 100L);
        }
        for (;;)
        {
          synchronized (NetworkActivityHelper.this.mNetworkThreadLock)
          {
            NetworkActivityHelper.access$702(NetworkActivityHelper.this, null);
            return;
          }
          NetworkActivityHelper.this.mNetworkTimeoutHandler.sendEmptyMessageDelayed(R.id.msg_network_timout, NetworkActivityHelper.this.mNetworkThread.getTimeoutDelay());
        }
      }
      synchronized (NetworkActivityHelper.this.mNetworkThreadLock)
      {
        if (NetworkActivityHelper.this.mNetworkThread != null)
        {
          Log.d(NetworkActivityHelper.this.getLogTag(), "Interrupting thread " + NetworkActivityHelper.this.mNetworkThread.toString());
          NetworkActivityHelper.this.mNetworkThread.interrupt();
          if (NetworkActivityHelper.this.mActivityHandler != null) {
            NetworkActivityHelper.this.mActivityHandler.sendEmptyMessage(R.id.msg_network_interrupted);
          }
        }
        NetworkActivityHelper.access$702(NetworkActivityHelper.this, null);
        return;
      }
    }
  };
  private NetworkThread mNetworkThread;
  private Object mNetworkThreadLock = new Object();
  private AlertDialog mNetworkTimeoutDialog;
  public Handler mNetworkTimeoutHandler = new Handler()
  {
    public void handleMessage(Message arg1)
    {
      do
      {
        synchronized (NetworkActivityHelper.this.mNetworkThreadLock)
        {
          if (NetworkActivityHelper.this.mProgressDialog != null)
          {
            NetworkActivityHelper.this.mTargetActivity.removeDialog(-2);
            NetworkActivityHelper.access$602(NetworkActivityHelper.this, null);
          }
          if (???.what == R.id.msg_network_timout)
          {
            if ((!NetworkActivityHelper.this.mTargetActivity.isFinishing()) && (NetworkActivityHelper.this.mNetworkThread != null) && (NetworkActivityHelper.this.mNetworkThread.isTimeoutDialogEnabled())) {
              NetworkActivityHelper.this.mTargetActivity.showDialog(-1);
            }
            return;
          }
        }
      } while (???.what != R.id.msg_network_complete);
      synchronized (NetworkActivityHelper.this.mNetworkThreadLock)
      {
        if (NetworkActivityHelper.this.mNetworkTimeoutDialog != null)
        {
          if ((NetworkActivityHelper.this.mNetworkThread != null) && (NetworkActivityHelper.this.mNetworkThread.isTimeoutDialogEnabled())) {
            NetworkActivityHelper.this.mTargetActivity.dismissDialog(-1);
          }
          NetworkActivityHelper.access$702(NetworkActivityHelper.this, null);
        }
        return;
      }
    }
  };
  private ProgressDialog mProgressDialog;
  private int mProgressDialogMessage = 0;
  private Activity mTargetActivity;
  private boolean mTimeoutDialogEnabled = true;
  
  public NetworkActivityHelper(Activity paramActivity)
  {
    this.mTargetActivity = paramActivity;
    Log.d("giq_network_activity_helper", "Target Activity = " + this.mTargetActivity);
  }
  
  public abstract String getLogTag();
  
  public abstract int getProgressDialogMessage();
  
  public Dialog onCreateDialog(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return null;
    case -1: 
      return new AlertDialog.Builder(this.mTargetActivity).setTitle(R.string.networktimeout_title).setMessage(R.string.networktimeout_message).setPositiveButton(R.string.networktimeout_wait, this.mDialogListener).setNegativeButton(R.string.networktimeout_cancel, this.mDialogListener).setCancelable(false).create();
    }
    ProgressDialog localProgressDialog = new ProgressDialog(this.mTargetActivity);
    localProgressDialog.setIndeterminate(true);
    if (this.mProgressDialogMessage != 0) {
      localProgressDialog.setMessage(this.mTargetActivity.getString(this.mProgressDialogMessage));
    }
    for (;;)
    {
      localProgressDialog.setCancelable(false);
      return localProgressDialog;
      localProgressDialog.setMessage(this.mTargetActivity.getString(getProgressDialogMessage()));
    }
  }
  
  /* Error */
  public void onPrepareDialog(int paramInt, Dialog paramDialog)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 51	com/coupons/mobile/networking/NetworkActivityHelper:mNetworkThreadLock	Ljava/lang/Object;
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: iload_1
    //   8: tableswitch	default:+24->32, -2:+43->51, -1:+27->35
    //   32: aload_3
    //   33: monitorexit
    //   34: return
    //   35: aload_0
    //   36: aload_2
    //   37: checkcast 184	android/app/AlertDialog
    //   40: putfield 112	com/coupons/mobile/networking/NetworkActivityHelper:mNetworkTimeoutDialog	Landroid/app/AlertDialog;
    //   43: goto -11 -> 32
    //   46: astore_2
    //   47: aload_3
    //   48: monitorexit
    //   49: aload_2
    //   50: athrow
    //   51: aload_0
    //   52: aload_2
    //   53: checkcast 162	android/app/ProgressDialog
    //   56: putfield 106	com/coupons/mobile/networking/NetworkActivityHelper:mProgressDialog	Landroid/app/ProgressDialog;
    //   59: goto -27 -> 32
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	62	0	this	NetworkActivityHelper
    //   0	62	1	paramInt	int
    //   0	62	2	paramDialog	Dialog
    //   4	44	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   32	34	46	finally
    //   35	43	46	finally
    //   47	49	46	finally
    //   51	59	46	finally
  }
  
  public void setActivityHandler(Handler paramHandler)
  {
    this.mActivityHandler = paramHandler;
  }
  
  public void setProgressDialogMessage(int paramInt)
  {
    this.mProgressDialogMessage = paramInt;
  }
  
  public void setTargetActivity(Activity paramActivity)
  {
    this.mTargetActivity = paramActivity;
    Log.d("giq_network_activity_helper", "Target Activity = " + this.mTargetActivity);
  }
  
  public abstract class NetworkThread
    extends Thread
  {
    private boolean mTimeoutOnlyWhenNetworkOp = false;
    
    public NetworkThread() {}
    
    public NetworkThread(boolean paramBoolean)
    {
      this.mTimeoutOnlyWhenNetworkOp = paramBoolean;
    }
    
    public final int getDefaultTimeoutDelay()
    {
      return 15000;
    }
    
    public int getTimeoutDelay()
    {
      return getDefaultTimeoutDelay();
    }
    
    public boolean isTimeoutDialogEnabled()
    {
      return NetworkActivityHelper.this.mTimeoutDialogEnabled;
    }
    
    public final void run()
    {
      synchronized (NetworkActivityHelper.this.mNetworkThreadLock)
      {
        if (NetworkActivityHelper.this.mNetworkThread != null)
        {
          Log.d(NetworkActivityHelper.this.getLogTag(), "Interrupting thread " + NetworkActivityHelper.this.mNetworkThread.toString());
          NetworkActivityHelper.this.mNetworkThread.interrupt();
        }
        NetworkActivityHelper.access$202(NetworkActivityHelper.this, this);
        if (!this.mTimeoutOnlyWhenNetworkOp) {
          NetworkActivityHelper.this.mNetworkTimeoutHandler.sendEmptyMessageDelayed(R.id.msg_network_timout, getTimeoutDelay());
        }
        runNetworkOperation();
        if (!isInterrupted())
        {
          NetworkActivityHelper.this.mNetworkTimeoutHandler.removeMessages(R.id.msg_network_timout);
          NetworkActivityHelper.this.mNetworkTimeoutHandler.sendEmptyMessage(R.id.msg_network_complete);
        }
      }
      synchronized (NetworkActivityHelper.this.mNetworkThreadLock)
      {
        do
        {
          NetworkActivityHelper.access$202(NetworkActivityHelper.this, null);
          return;
          localObject2 = finally;
          throw ((Throwable)localObject2);
        } while (NetworkActivityHelper.this.mActivityHandler == null);
        NetworkActivityHelper.this.mActivityHandler.sendEmptyMessage(R.id.msg_network_interrupted_complete);
      }
    }
    
    public abstract void runNetworkOperation();
    
    public final void start()
    {
      if (((NetworkActivityHelper.this.mProgressDialogMessage != 0) || (NetworkActivityHelper.this.getProgressDialogMessage() != 0)) && (NetworkActivityHelper.this.mTargetActivity != null)) {
        NetworkActivityHelper.this.mTargetActivity.showDialog(-2);
      }
      super.start();
    }
    
    public void startLookingForTimeout()
    {
      NetworkActivityHelper.this.mNetworkTimeoutHandler.sendEmptyMessageDelayed(R.id.msg_network_timout, getTimeoutDelay());
    }
    
    public void stopLookingForTimeout()
    {
      NetworkActivityHelper.this.mNetworkTimeoutHandler.removeMessages(R.id.msg_network_timout);
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/NetworkActivityHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */