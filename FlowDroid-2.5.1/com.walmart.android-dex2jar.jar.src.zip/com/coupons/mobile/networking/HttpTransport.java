package com.coupons.mobile.networking;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.entity.ByteArrayEntity;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.transport.AndroidHttpTransport;
import org.ksoap2.transport.ServiceConnection;
import org.xmlpull.v1.XmlPullParserException;

public class HttpTransport
  extends AndroidHttpTransport
  implements Transport
{
  private AppInfo mAppInfo;
  
  public HttpTransport(String paramString)
  {
    super(paramString);
  }
  
  public void call(String paramString, SoapEnvelope paramSoapEnvelope)
    throws IOException, XmlPullParserException
  {
    Object localObject = paramString;
    if (paramString == null) {
      localObject = "\"\"";
    }
    byte[] arrayOfByte = createRequestData(paramSoapEnvelope);
    boolean bool;
    label50:
    CIServiceConnection localCIServiceConnection;
    if (NetworkLogging.isLoggable())
    {
      bool = true;
      this.debug = bool;
      if (!this.debug) {
        break label246;
      }
      paramString = new String(arrayOfByte);
      this.requestDump = paramString;
      this.responseDump = null;
      localCIServiceConnection = (CIServiceConnection)getServiceConnection();
      localCIServiceConnection.setRequestProperty("User-Agent", "kSOAP/2.0");
      localCIServiceConnection.setRequestProperty("SOAPAction", (String)localObject);
      localCIServiceConnection.setRequestProperty("Content-Type", "text/xml");
      localCIServiceConnection.setRequestProperty("Connection", "close");
      localCIServiceConnection.setEntity(new ByteArrayEntity(arrayOfByte));
    }
    for (;;)
    {
      int i;
      try
      {
        localCIServiceConnection.connect();
        paramString = localCIServiceConnection.openInputStream();
        localObject = paramString;
        if (this.debug)
        {
          localObject = new ByteArrayOutputStream();
          arrayOfByte = new byte['Ā'];
          i = paramString.read(arrayOfByte, 0, 256);
          if (i != -1) {
            break label259;
          }
          ((ByteArrayOutputStream)localObject).flush();
          localObject = ((ByteArrayOutputStream)localObject).toByteArray();
          this.responseDump = new String((byte[])localObject);
          paramString.close();
          localObject = new ByteArrayInputStream((byte[])localObject);
        }
        parseResponse(paramSoapEnvelope, (InputStream)localObject);
        if (this.debug) {
          localCIServiceConnection.logHeaders();
        }
        localCIServiceConnection.disconnect();
        return;
      }
      catch (IOException paramString)
      {
        localCIServiceConnection.disconnect();
        throw paramString;
      }
      bool = this.debug;
      break;
      label246:
      paramString = null;
      break label50;
      label259:
      ((ByteArrayOutputStream)localObject).write(arrayOfByte, 0, i);
    }
  }
  
  protected ServiceConnection getServiceConnection()
    throws IOException
  {
    if (this.mAppInfo == null) {
      return new CIServiceConnection(this.url);
    }
    return new CIServiceConnection(this.url, this.mAppInfo);
  }
  
  public void logRequest()
  {
    if (NetworkLogging.isLoggable()) {
      NetworkLogging.logv("Request:\n" + this.requestDump);
    }
  }
  
  public void logResponse()
  {
    if (NetworkLogging.isLoggable()) {
      NetworkLogging.logv("Response:\n" + this.responseDump);
    }
  }
  
  public void setAppInfo(AppInfo paramAppInfo)
  {
    this.mAppInfo = paramAppInfo;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/HttpTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */