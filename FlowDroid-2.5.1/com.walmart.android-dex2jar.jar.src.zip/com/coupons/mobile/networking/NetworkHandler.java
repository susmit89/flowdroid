package com.coupons.mobile.networking;

import android.content.Context;
import android.util.Log;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.ksoap2.SoapFault;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParserException;

public class NetworkHandler
{
  public static String CLIP_CONTEXT;
  public static String CLIP_URL;
  public static String COUPONWEB_CONTEXT = "couponweb/";
  public static String COUPONWEB_URL;
  private static String PID;
  private static String partnerCodeEmail = "0046beb1-aa81-41f6-9c99-481c2c3fad59";
  private static String partnerCodeLoyaltyCard = "8038e590-58b9-4deb-86fa-9638c3b94e6e";
  private static String partnerCodeManageUserMessage = "1db0e317-8988-441a-9375-4edee3d41661";
  private static String partnerCodeUserAccount = "c3339325-84b3-4e20-87ee-3e2cdcf54881";
  private AppInfo mAppInfo;
  
  static
  {
    CLIP_URL = "http://insight.coupons.com/";
    CLIP_CONTEXT = "COS20/";
    COUPONWEB_URL = "http://print.coupons.com/";
  }
  
  public static boolean SendLocalRequest(SOAPSimpleRequest paramSOAPSimpleRequest, SOAPSimpleResponse paramSOAPSimpleResponse, Context paramContext)
  {
    return SendRequestWithTransport(paramSOAPSimpleRequest, paramSOAPSimpleResponse, new LocalTransport(paramSOAPSimpleRequest.getTargetURI(), paramContext));
  }
  
  public static boolean SendRequest(SOAPSimpleRequest paramSOAPSimpleRequest, SOAPSimpleResponse paramSOAPSimpleResponse, AppInfo paramAppInfo)
  {
    HttpTransport localHttpTransport = new HttpTransport(paramSOAPSimpleRequest.getTargetURI());
    localHttpTransport.debug = NetworkLogging.isLoggable();
    localHttpTransport.setAppInfo(paramAppInfo);
    return SendRequestWithTransport(paramSOAPSimpleRequest, paramSOAPSimpleResponse, localHttpTransport);
  }
  
  protected static boolean SendRequestWithTransport(SOAPSimpleRequest paramSOAPSimpleRequest, SOAPSimpleResponse paramSOAPSimpleResponse, Transport paramTransport)
  {
    SoapObject localSoapObject = paramSOAPSimpleRequest.generateSoapObject();
    SoapSerializationEnvelope localSoapSerializationEnvelope = new SoapSerializationEnvelope(120);
    localSoapSerializationEnvelope.env = paramSOAPSimpleRequest.getEnvelope();
    localSoapSerializationEnvelope.setAddAdornments(false);
    localSoapSerializationEnvelope.implicitTypes = true;
    localSoapSerializationEnvelope.dotNet = true;
    localSoapSerializationEnvelope.bodyOut = localSoapObject;
    try
    {
      paramTransport.call(paramSOAPSimpleRequest.getSoapAction(), localSoapSerializationEnvelope);
      paramTransport.logRequest();
      paramTransport.logResponse();
      paramSOAPSimpleResponse.process(localSoapSerializationEnvelope.getResponse());
      return true;
    }
    catch (SoapFault paramSOAPSimpleRequest)
    {
      Log.e("NW", "Error, remote problem with SOAP request " + paramSOAPSimpleRequest.faultstring, paramSOAPSimpleRequest);
      return true;
    }
    catch (XmlPullParserException paramSOAPSimpleRequest)
    {
      Log.e("NW", "Error parsing xml for response", paramSOAPSimpleRequest);
      return true;
    }
    catch (IOException paramSOAPSimpleRequest)
    {
      Log.e("NW", paramSOAPSimpleRequest.toString());
      Log.e("NW", "IO Error with making request", paramSOAPSimpleRequest);
    }
    return false;
  }
  
  public static String getPID()
  {
    return PID;
  }
  
  public static String getPartnerCodeEmail()
  {
    return partnerCodeEmail;
  }
  
  public static String getPartnerCodeLoyaltyCard()
  {
    return partnerCodeLoyaltyCard;
  }
  
  public static String getPartnerCodeManageUserMessage()
  {
    return partnerCodeManageUserMessage;
  }
  
  public static String getPartnerCodeUserAccount()
  {
    return partnerCodeUserAccount;
  }
  
  public static void setPID(String paramString)
  {
    PID = paramString;
  }
  
  public static abstract class SOAPSimpleRequest
  {
    protected static final String ENVELOPE = "http://www.w3.org/2003/05/soap-envelope";
    protected HashMap<String, String> mValueMap = new HashMap();
    
    public SoapObject generateSoapObject()
    {
      SoapObject localSoapObject = new SoapObject(getSoapObjectNameSpace(), getSoapObjectName());
      if (!this.mValueMap.isEmpty())
      {
        Object localObject = this.mValueMap.entrySet();
        if (NetworkLogging.isLoggable()) {
          NetworkLogging.logv("Target URI = " + getTargetURI());
        }
        localObject = ((Set)localObject).iterator();
        while (((Iterator)localObject).hasNext())
        {
          Map.Entry localEntry = (Map.Entry)((Iterator)localObject).next();
          localSoapObject.addProperty((String)localEntry.getKey(), localEntry.getValue());
          if (NetworkLogging.isLoggable()) {
            NetworkLogging.logv((String)localEntry.getKey() + " = " + (String)localEntry.getValue());
          }
        }
      }
      return localSoapObject;
    }
    
    public String getEnvelope()
    {
      return "http://www.w3.org/2003/05/soap-envelope";
    }
    
    public abstract String getSoapAction();
    
    public abstract String getSoapObjectName();
    
    public abstract String getSoapObjectNameSpace();
    
    public abstract String getTargetURI();
  }
  
  public static abstract class SOAPSimpleResponse
  {
    protected abstract DefaultHandler getResponseHandler();
    
    protected abstract boolean isResponseEncoded();
    
    /* Error */
    public void process(Object paramObject)
    {
      // Byte code:
      //   0: aload_1
      //   1: instanceof 26
      //   4: ifne +12 -> 16
      //   7: ldc 28
      //   9: ldc 30
      //   11: invokestatic 36	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
      //   14: pop
      //   15: return
      //   16: aload_1
      //   17: checkcast 26	org/ksoap2/serialization/SoapPrimitive
      //   20: astore_1
      //   21: invokestatic 42	javax/xml/parsers/SAXParserFactory:newInstance	()Ljavax/xml/parsers/SAXParserFactory;
      //   24: invokevirtual 46	javax/xml/parsers/SAXParserFactory:newSAXParser	()Ljavax/xml/parsers/SAXParser;
      //   27: astore_2
      //   28: aload_0
      //   29: invokevirtual 48	com/coupons/mobile/networking/NetworkHandler$SOAPSimpleResponse:isResponseEncoded	()Z
      //   32: ifeq +109 -> 141
      //   35: aload_1
      //   36: invokevirtual 52	org/ksoap2/serialization/SoapPrimitive:toString	()Ljava/lang/String;
      //   39: invokestatic 55	com/coupons/mobile/networking/NetworkHandler:access$000	()Ljava/lang/String;
      //   42: invokestatic 61	com/coupons/mobile/networking/security/CipherKey:decode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   45: astore_1
      //   46: invokestatic 66	com/coupons/mobile/networking/NetworkLogging:isLoggable	()Z
      //   49: ifeq +7 -> 56
      //   52: aload_1
      //   53: invokestatic 70	com/coupons/mobile/networking/NetworkLogging:logToFile	(Ljava/lang/String;)V
      //   56: aload_0
      //   57: invokevirtual 48	com/coupons/mobile/networking/NetworkHandler$SOAPSimpleResponse:isResponseEncoded	()Z
      //   60: ifeq +89 -> 149
      //   63: invokestatic 66	com/coupons/mobile/networking/NetworkLogging:isLoggable	()Z
      //   66: ifeq +25 -> 91
      //   69: new 72	java/lang/StringBuilder
      //   72: dup
      //   73: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   76: ldc 75
      //   78: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   81: aload_1
      //   82: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   85: invokevirtual 80	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   88: invokestatic 83	com/coupons/mobile/networking/NetworkLogging:logv	(Ljava/lang/String;)V
      //   91: aload_2
      //   92: new 85	java/io/ByteArrayInputStream
      //   95: dup
      //   96: aload_1
      //   97: invokevirtual 91	java/lang/String:getBytes	()[B
      //   100: invokespecial 94	java/io/ByteArrayInputStream:<init>	([B)V
      //   103: aload_0
      //   104: invokevirtual 96	com/coupons/mobile/networking/NetworkHandler$SOAPSimpleResponse:getResponseHandler	()Lorg/xml/sax/helpers/DefaultHandler;
      //   107: invokevirtual 102	javax/xml/parsers/SAXParser:parse	(Ljava/io/InputStream;Lorg/xml/sax/helpers/DefaultHandler;)V
      //   110: return
      //   111: astore_1
      //   112: ldc 28
      //   114: ldc 104
      //   116: invokestatic 36	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
      //   119: pop
      //   120: return
      //   121: astore_1
      //   122: ldc 28
      //   124: ldc 106
      //   126: invokestatic 36	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
      //   129: pop
      //   130: return
      //   131: astore_1
      //   132: ldc 28
      //   134: ldc 108
      //   136: invokestatic 36	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
      //   139: pop
      //   140: return
      //   141: aload_1
      //   142: invokevirtual 52	org/ksoap2/serialization/SoapPrimitive:toString	()Ljava/lang/String;
      //   145: astore_1
      //   146: goto -100 -> 46
      //   149: invokestatic 66	com/coupons/mobile/networking/NetworkLogging:isLoggable	()Z
      //   152: ifeq -61 -> 91
      //   155: new 72	java/lang/StringBuilder
      //   158: dup
      //   159: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   162: ldc 110
      //   164: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   167: aload_1
      //   168: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   171: invokevirtual 80	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   174: invokestatic 83	com/coupons/mobile/networking/NetworkLogging:logv	(Ljava/lang/String;)V
      //   177: goto -86 -> 91
      //   180: astore_1
      //   181: ldc 28
      //   183: ldc 112
      //   185: invokestatic 36	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
      //   188: pop
      //   189: return
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	190	0	this	SOAPSimpleResponse
      //   0	190	1	paramObject	Object
      //   27	65	2	localSAXParser	javax.xml.parsers.SAXParser
      // Exception table:
      //   from	to	target	type
      //   91	110	111	java/io/IOException
      //   21	28	121	org/xml/sax/SAXException
      //   21	28	131	javax/xml/parsers/ParserConfigurationException
      //   91	110	180	org/xml/sax/SAXException
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/coupons/mobile/networking/NetworkHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */