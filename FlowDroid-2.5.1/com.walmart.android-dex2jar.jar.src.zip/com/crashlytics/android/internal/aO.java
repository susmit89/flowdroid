package com.crashlytics.android.internal;

final class aO
  extends Z
  implements ba
{
  public aO(String paramString1, String paramString2, av paramav)
  {
    this(paramString1, paramString2, paramav, ax.a);
  }
  
  private aO(String paramString1, String paramString2, av paramav, ax paramax)
  {
    super(paramString1, paramString2, paramav, paramax);
  }
  
  /* Error */
  public final org.json.JSONObject a(aZ paramaZ)
  {
    // Byte code:
    //   0: new 24	java/util/HashMap
    //   3: dup
    //   4: invokespecial 27	java/util/HashMap:<init>	()V
    //   7: astore 5
    //   9: aload 5
    //   11: ldc 29
    //   13: aload_1
    //   14: getfield 35	com/crashlytics/android/internal/aZ:e	Ljava/lang/String;
    //   17: invokeinterface 41 3 0
    //   22: pop
    //   23: aload 5
    //   25: ldc 43
    //   27: aload_1
    //   28: getfield 46	com/crashlytics/android/internal/aZ:d	Ljava/lang/String;
    //   31: invokeinterface 41 3 0
    //   36: pop
    //   37: aload 5
    //   39: ldc 48
    //   41: aload_1
    //   42: getfield 52	com/crashlytics/android/internal/aZ:f	I
    //   45: invokestatic 58	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   48: invokeinterface 41 3 0
    //   53: pop
    //   54: aload_1
    //   55: getfield 61	com/crashlytics/android/internal/aZ:g	Ljava/lang/String;
    //   58: ifnull +17 -> 75
    //   61: aload 5
    //   63: ldc 63
    //   65: aload_1
    //   66: getfield 61	com/crashlytics/android/internal/aZ:g	Ljava/lang/String;
    //   69: invokeinterface 41 3 0
    //   74: pop
    //   75: aload_1
    //   76: getfield 66	com/crashlytics/android/internal/aZ:c	Ljava/lang/String;
    //   79: astore_2
    //   80: aload_2
    //   81: invokestatic 71	com/crashlytics/android/internal/ab:e	(Ljava/lang/String;)Z
    //   84: ifne +14 -> 98
    //   87: aload 5
    //   89: ldc 73
    //   91: aload_2
    //   92: invokeinterface 41 3 0
    //   97: pop
    //   98: aload_0
    //   99: aload 5
    //   101: invokevirtual 76	com/crashlytics/android/internal/aO:a	(Ljava/util/Map;)Lcom/crashlytics/android/internal/ay;
    //   104: astore 4
    //   106: aload 4
    //   108: astore_2
    //   109: aload 4
    //   111: astore_3
    //   112: aload 4
    //   114: ldc 78
    //   116: aload_1
    //   117: getfield 80	com/crashlytics/android/internal/aZ:a	Ljava/lang/String;
    //   120: invokevirtual 85	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;Ljava/lang/String;)Lcom/crashlytics/android/internal/ay;
    //   123: ldc 87
    //   125: ldc 89
    //   127: invokevirtual 85	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;Ljava/lang/String;)Lcom/crashlytics/android/internal/ay;
    //   130: ldc 91
    //   132: aload_1
    //   133: getfield 94	com/crashlytics/android/internal/aZ:b	Ljava/lang/String;
    //   136: invokevirtual 85	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;Ljava/lang/String;)Lcom/crashlytics/android/internal/ay;
    //   139: ldc 96
    //   141: invokestatic 101	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   144: invokevirtual 105	com/crashlytics/android/internal/v:getVersion	()Ljava/lang/String;
    //   147: invokevirtual 85	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;Ljava/lang/String;)Lcom/crashlytics/android/internal/ay;
    //   150: ldc 107
    //   152: ldc 109
    //   154: invokevirtual 85	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;Ljava/lang/String;)Lcom/crashlytics/android/internal/ay;
    //   157: astore_1
    //   158: aload_1
    //   159: astore_2
    //   160: aload_1
    //   161: astore_3
    //   162: invokestatic 101	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   165: invokevirtual 112	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   168: ldc 114
    //   170: new 116	java/lang/StringBuilder
    //   173: dup
    //   174: ldc 118
    //   176: invokespecial 121	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   179: aload_0
    //   180: invokevirtual 123	com/crashlytics/android/internal/aO:a	()Ljava/lang/String;
    //   183: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   189: invokeinterface 134 3 0
    //   194: aload_1
    //   195: astore_2
    //   196: aload_1
    //   197: astore_3
    //   198: invokestatic 101	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   201: invokevirtual 112	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   204: ldc 114
    //   206: new 116	java/lang/StringBuilder
    //   209: dup
    //   210: ldc -120
    //   212: invokespecial 121	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   215: aload 5
    //   217: invokevirtual 139	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   220: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   223: invokeinterface 134 3 0
    //   228: aload_1
    //   229: astore_2
    //   230: aload_1
    //   231: astore_3
    //   232: new 141	org/json/JSONObject
    //   235: dup
    //   236: aload_1
    //   237: invokevirtual 143	com/crashlytics/android/internal/ay:c	()Ljava/lang/String;
    //   240: invokespecial 144	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   243: astore 4
    //   245: aload_1
    //   246: ifnull +37 -> 283
    //   249: invokestatic 101	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   252: invokevirtual 112	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   255: ldc 114
    //   257: new 116	java/lang/StringBuilder
    //   260: dup
    //   261: ldc -110
    //   263: invokespecial 121	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   266: aload_1
    //   267: ldc -108
    //   269: invokevirtual 151	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;)Ljava/lang/String;
    //   272: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   278: invokeinterface 134 3 0
    //   283: aload 4
    //   285: areturn
    //   286: astore_1
    //   287: aconst_null
    //   288: astore_3
    //   289: aload_3
    //   290: astore_2
    //   291: invokestatic 101	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   294: invokevirtual 112	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   297: ldc 114
    //   299: new 116	java/lang/StringBuilder
    //   302: dup
    //   303: ldc -103
    //   305: invokespecial 121	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   308: aload_0
    //   309: invokevirtual 123	com/crashlytics/android/internal/aO:a	()Ljava/lang/String;
    //   312: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   315: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   318: aload_1
    //   319: invokeinterface 156 4 0
    //   324: aload_3
    //   325: ifnull +90 -> 415
    //   328: invokestatic 101	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   331: invokevirtual 112	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   334: ldc 114
    //   336: new 116	java/lang/StringBuilder
    //   339: dup
    //   340: ldc -110
    //   342: invokespecial 121	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   345: aload_3
    //   346: ldc -108
    //   348: invokevirtual 151	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;)Ljava/lang/String;
    //   351: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   357: invokeinterface 134 3 0
    //   362: aconst_null
    //   363: areturn
    //   364: astore_1
    //   365: aconst_null
    //   366: astore_2
    //   367: aload_2
    //   368: ifnull +37 -> 405
    //   371: invokestatic 101	com/crashlytics/android/internal/v:a	()Lcom/crashlytics/android/internal/v;
    //   374: invokevirtual 112	com/crashlytics/android/internal/v:b	()Lcom/crashlytics/android/internal/q;
    //   377: ldc 114
    //   379: new 116	java/lang/StringBuilder
    //   382: dup
    //   383: ldc -110
    //   385: invokespecial 121	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   388: aload_2
    //   389: ldc -108
    //   391: invokevirtual 151	com/crashlytics/android/internal/ay:a	(Ljava/lang/String;)Ljava/lang/String;
    //   394: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   397: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   400: invokeinterface 134 3 0
    //   405: aload_1
    //   406: athrow
    //   407: astore_1
    //   408: goto -41 -> 367
    //   411: astore_1
    //   412: goto -123 -> 289
    //   415: aconst_null
    //   416: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	417	0	this	aO
    //   0	417	1	paramaZ	aZ
    //   79	310	2	localObject1	Object
    //   111	235	3	localObject2	Object
    //   104	180	4	localObject3	Object
    //   7	209	5	localHashMap	java.util.HashMap
    // Exception table:
    //   from	to	target	type
    //   0	75	286	java/lang/Exception
    //   75	98	286	java/lang/Exception
    //   98	106	286	java/lang/Exception
    //   0	75	364	finally
    //   75	98	364	finally
    //   98	106	364	finally
    //   112	158	407	finally
    //   162	194	407	finally
    //   198	228	407	finally
    //   232	245	407	finally
    //   291	324	407	finally
    //   112	158	411	java/lang/Exception
    //   162	194	411	java/lang/Exception
    //   198	228	411	java/lang/Exception
    //   232	245	411	java/lang/Exception
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */