package com.crashlytics.android.internal;

import android.content.Context;

public abstract class p
{
  private Context a;
  private boolean b;
  
  protected final void a(Context paramContext)
  {
    for (;;)
    {
      try
      {
        boolean bool = this.b;
        if (bool) {
          return;
        }
        if (paramContext == null) {
          throw new IllegalArgumentException("context cannot be null.");
        }
      }
      finally {}
      this.a = new z(paramContext.getApplicationContext(), getName());
      this.b = true;
      c();
    }
  }
  
  protected abstract void c();
  
  public String getComponentPath()
  {
    return ".TwitterSdk/" + getName();
  }
  
  public final Context getContext()
  {
    return this.a;
  }
  
  public final String getName()
  {
    return getClass().getSimpleName().toLowerCase();
  }
  
  public abstract String getVersion();
  
  public final boolean isInitialized()
  {
    try
    {
      boolean bool = this.b;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */