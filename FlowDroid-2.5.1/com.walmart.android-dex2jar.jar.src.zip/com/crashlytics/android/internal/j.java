package com.crashlytics.android.internal;

import java.util.Map;
import java.util.Set;

final class j
  implements i
{
  public final Map<Class<?>, h> a(Object paramObject)
  {
    return a.a(paramObject);
  }
  
  public final Map<Class<?>, Set<g>> b(Object paramObject)
  {
    return a.b(paramObject);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */