package com.crashlytics.android.internal;

import org.json.JSONObject;

public abstract interface ba
{
  public abstract JSONObject a(aZ paramaZ);
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */