package com.crashlytics.android.internal;

import java.io.Closeable;
import java.io.InputStream;
import java.io.OutputStream;

final class az
  extends aA<ay>
{
  az(ay paramay, Closeable paramCloseable, boolean paramBoolean, InputStream paramInputStream, OutputStream paramOutputStream)
  {
    super(paramCloseable, paramBoolean);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/az.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */