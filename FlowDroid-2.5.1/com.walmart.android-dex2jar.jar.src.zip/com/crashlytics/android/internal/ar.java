package com.crashlytics.android.internal;

import java.io.IOException;
import java.io.InputStream;

final class ar
  implements au
{
  private boolean a = true;
  
  ar(aq paramaq, StringBuilder paramStringBuilder) {}
  
  public final void a(InputStream paramInputStream, int paramInt)
    throws IOException
  {
    if (this.a) {
      this.a = false;
    }
    for (;;)
    {
      this.b.append(paramInt);
      return;
      this.b.append(", ");
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */