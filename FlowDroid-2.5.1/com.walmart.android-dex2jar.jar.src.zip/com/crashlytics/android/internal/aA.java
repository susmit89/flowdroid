package com.crashlytics.android.internal;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;

public abstract class aA<V>
  extends aE<V>
{
  private final Closeable a;
  private final boolean b;
  
  protected aA(Closeable paramCloseable, boolean paramBoolean)
  {
    this.a = paramCloseable;
    this.b = paramBoolean;
  }
  
  protected final void b()
    throws IOException
  {
    if ((this.a instanceof Flushable)) {
      ((Flushable)this.a).flush();
    }
    if (this.b) {}
    try
    {
      this.a.close();
      return;
    }
    catch (IOException localIOException) {}
    this.a.close();
    return;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */