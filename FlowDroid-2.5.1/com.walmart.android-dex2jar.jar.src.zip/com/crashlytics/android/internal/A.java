package com.crashlytics.android.internal;

public final class A
  implements q
{
  public final void a(int paramInt, String paramString1, String paramString2) {}
  
  public final void a(int paramInt, String paramString1, String paramString2, boolean paramBoolean) {}
  
  public final void a(String paramString1, String paramString2) {}
  
  public final void a(String paramString1, String paramString2, Throwable paramThrowable) {}
  
  public final void b(String paramString1, String paramString2) {}
  
  public final void c(String paramString1, String paramString2) {}
  
  public final void d(String paramString1, String paramString2) {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */