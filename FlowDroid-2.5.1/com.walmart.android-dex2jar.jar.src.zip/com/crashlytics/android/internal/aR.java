package com.crashlytics.android.internal;

public final class aR
{
  public final int a;
  
  public aR(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean)
  {
    this.a = paramInt3;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */