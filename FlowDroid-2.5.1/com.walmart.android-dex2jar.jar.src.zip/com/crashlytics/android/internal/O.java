package com.crashlytics.android.internal;

import android.app.Activity;
import android.os.Looper;
import java.util.Collections;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;

class O
  implements ak
{
  U a;
  private final String b;
  private final String c;
  private final String d;
  private final String e;
  private final String f;
  private final String g;
  private final String h;
  private final String i;
  private final ScheduledExecutorService j;
  
  public O(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, K paramK, av paramav)
  {
    this(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramK, ah.b("Crashlytics SAM"), paramav);
  }
  
  O(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, K paramK, ScheduledExecutorService paramScheduledExecutorService, av paramav)
  {
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramString3;
    this.e = paramString4;
    this.f = paramString5;
    this.g = paramString6;
    this.h = paramString7;
    this.i = UUID.randomUUID().toString();
    this.j = paramScheduledExecutorService;
    this.a = new J(paramScheduledExecutorService, paramK, paramav);
    paramK.a(this);
  }
  
  private void a(V paramV, boolean paramBoolean)
  {
    a(new Q(this, paramV, paramBoolean));
  }
  
  private void a(W paramW, Activity paramActivity, boolean paramBoolean)
  {
    a(V.a(this.b, this.i, this.c, this.d, this.e, this.f, this.g, this.h, paramW, Collections.singletonMap("activity", paramActivity.getClass().getName())), false);
  }
  
  private void a(Runnable paramRunnable)
  {
    try
    {
      this.j.submit(paramRunnable);
      return;
    }
    catch (Exception paramRunnable)
    {
      ab.d("Crashlytics failed to submit analytics task");
    }
  }
  
  void a()
  {
    a(new T(this));
  }
  
  public final void a(Activity paramActivity)
  {
    a(W.a, paramActivity, false);
  }
  
  final void a(aK paramaK, String paramString)
  {
    a(new R(this, paramaK, paramString));
  }
  
  public final void a(String paramString)
  {
    if (Looper.myLooper() == Looper.getMainLooper()) {
      throw new IllegalStateException("onCrash called from main thread!!!");
    }
    paramString = new P(this, paramString);
    try
    {
      this.j.submit(paramString).get();
      return;
    }
    catch (Exception paramString)
    {
      ab.d("Crashlytics failed to run analytics task");
    }
  }
  
  public final void b()
  {
    a(V.a(this.b, this.i, this.c, this.d, this.e, this.f, this.g, this.h, W.j, new HashMap()), true);
  }
  
  public final void b(Activity paramActivity)
  {
    a(W.g, paramActivity, false);
  }
  
  public final void b(String paramString)
  {
    String str1 = this.b;
    String str2 = this.i;
    String str3 = this.c;
    String str4 = this.d;
    String str5 = this.e;
    String str6 = this.f;
    String str7 = this.g;
    String str8 = this.h;
    paramString = Collections.singletonMap("sessionId", paramString);
    a(V.a(str1, str2, str3, str4, str5, str6, str7, str8, W.h, paramString), false);
  }
  
  public final void c()
  {
    a(new S(this));
  }
  
  public final void c(Activity paramActivity)
  {
    a(W.e, paramActivity, false);
  }
  
  public final void d(Activity paramActivity)
  {
    a(W.c, paramActivity, false);
  }
  
  public final void e(Activity paramActivity)
  {
    a(W.d, paramActivity, false);
  }
  
  public final void f(Activity paramActivity)
  {
    a(W.b, paramActivity, false);
  }
  
  public final void g(Activity paramActivity)
  {
    a(W.f, paramActivity, false);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */