package com.crashlytics.android.internal;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

final class X
{
  private static JSONObject a(Map<String, String> paramMap)
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    paramMap = paramMap.entrySet().iterator();
    while (paramMap.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)paramMap.next();
      localJSONObject.put((String)localEntry.getKey(), localEntry.getValue());
    }
    return localJSONObject;
  }
  
  public final byte[] a(V paramV)
    throws IOException
  {
    try
    {
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put("appBundleId", paramV.a);
      localJSONObject.put("executionId", paramV.b);
      localJSONObject.put("installationId", paramV.c);
      localJSONObject.put("androidId", paramV.d);
      localJSONObject.put("osVersion", paramV.e);
      localJSONObject.put("deviceModel", paramV.f);
      localJSONObject.put("appVersionCode", paramV.g);
      localJSONObject.put("appVersionName", paramV.h);
      localJSONObject.put("timestamp", paramV.i);
      localJSONObject.put("type", paramV.j.toString());
      localJSONObject.put("details", a(paramV.k));
      paramV = localJSONObject.toString().getBytes("UTF-8");
      return paramV;
    }
    catch (JSONException paramV)
    {
      throw new IOException(paramV.getMessage());
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/X.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */