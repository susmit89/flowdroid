package com.crashlytics.android.internal;

import java.io.InputStream;

public abstract interface aG
{
  public abstract InputStream a();
  
  public abstract String b();
  
  public abstract String[] c();
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */