package com.crashlytics.android.internal;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

final class an
  extends aa
{
  an(String paramString, ExecutorService paramExecutorService, long paramLong, TimeUnit paramTimeUnit) {}
  
  public final void a()
  {
    try
    {
      v.a().b().a("Crashlytics", "Executing shutdown hook for " + this.a);
      this.b.shutdown();
      if (!this.b.awaitTermination(this.c, this.d))
      {
        v.a().b().a("Crashlytics", this.a + " did not shut down in the allocated time. Requesting immediate shutdown.");
        this.b.shutdownNow();
      }
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      v.a().b().a("Crashlytics", String.format(Locale.US, "Interrupted while waiting for %s to shut down. Requesting immediate shutdown.", new Object[] { this.a }));
      this.b.shutdownNow();
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */