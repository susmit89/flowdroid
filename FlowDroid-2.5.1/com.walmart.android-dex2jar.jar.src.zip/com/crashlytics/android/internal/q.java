package com.crashlytics.android.internal;

public abstract interface q
{
  public abstract void a(int paramInt, String paramString1, String paramString2);
  
  public abstract void a(int paramInt, String paramString1, String paramString2, boolean paramBoolean);
  
  public abstract void a(String paramString1, String paramString2);
  
  public abstract void a(String paramString1, String paramString2, Throwable paramThrowable);
  
  public abstract void b(String paramString1, String paramString2);
  
  public abstract void c(String paramString1, String paramString2);
  
  public abstract void d(String paramString1, String paramString2);
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */