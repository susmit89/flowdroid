package com.crashlytics.android.internal;

import android.os.Looper;

final class o
  implements m
{
  public final void a(b paramb)
  {
    if (Looper.myLooper() != Looper.getMainLooper()) {
      throw new IllegalStateException("Event bus " + paramb + " accessed from non-main thread " + Looper.myLooper());
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */