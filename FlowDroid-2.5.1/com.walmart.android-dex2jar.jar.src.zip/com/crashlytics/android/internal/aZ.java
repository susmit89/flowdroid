package com.crashlytics.android.internal;

public final class aZ
{
  public final String a;
  public final String b;
  public final String c;
  public final String d;
  public final String e;
  public final int f;
  public final String g;
  
  public aZ(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt, String paramString6)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramString4;
    this.e = paramString5;
    this.f = paramInt;
    this.g = paramString6;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aZ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */