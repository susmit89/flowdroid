package com.crashlytics.android.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

public final class v
  extends p
{
  private b a = new B(m.a);
  private AtomicReference<q> b = new AtomicReference();
  private boolean c;
  private File d;
  private Application e;
  private WeakReference<Activity> f;
  private String g;
  private int h = 4;
  private ConcurrentHashMap<Class<? extends u>, u> i = new ConcurrentHashMap();
  
  public static v a()
  {
    return y.a();
  }
  
  private v a(Activity paramActivity)
  {
    this.f = new WeakReference(paramActivity);
    return this;
  }
  
  public static void a(Context paramContext, u... paramVarArgs)
  {
    for (;;)
    {
      try
      {
        boolean bool = y.a().isInitialized();
        if (bool) {
          return;
        }
        v localv = y.a();
        localv.e = r.b(paramContext);
        localv = localv.a(r.a(paramContext));
        int k = paramVarArgs.length;
        int j = 0;
        if (j < k)
        {
          u localu = paramVarArgs[j];
          if (!localv.i.containsKey(paramVarArgs)) {
            localv.i.putIfAbsent(localu.getClass(), localu);
          }
        }
        else
        {
          localv.a(paramContext);
          continue;
        }
        j += 1;
      }
      finally {}
    }
  }
  
  public final <T extends u> T a(Class<T> paramClass)
  {
    return (u)this.i.get(paramClass);
  }
  
  public final void a(q paramq)
  {
    this.b.set(paramq);
  }
  
  public final void a(String paramString)
  {
    this.g = paramString;
  }
  
  public final void a(boolean paramBoolean)
  {
    this.c = paramBoolean;
    if (paramBoolean) {}
    for (int j = 3;; j = 4)
    {
      this.h = j;
      return;
    }
  }
  
  public final q b()
  {
    Object localObject2 = (q)this.b.get();
    Object localObject1 = localObject2;
    if (localObject2 == null)
    {
      localObject2 = new r();
      localObject1 = localObject2;
      if (!this.b.compareAndSet(null, localObject2)) {
        localObject1 = (q)this.b.get();
      }
    }
    return (q)localObject1;
  }
  
  protected final void c()
  {
    Context localContext = getContext();
    this.d = new File(localContext.getFilesDir(), "com.crashlytics.sdk.android");
    if (!this.d.exists()) {
      this.d.mkdirs();
    }
    if (Build.VERSION.SDK_INT >= 14) {
      w.a(new w(this, (byte)0), this.e);
    }
    Object localObject;
    if ((this.c) && (Log.isLoggable("CrashlyticsInternal", 3)))
    {
      localObject = new StringBuilder();
      Iterator localIterator = this.i.values().iterator();
      while (localIterator.hasNext())
      {
        p localp = (p)localIterator.next();
        long l = System.nanoTime();
        localp.a(localContext);
        ((StringBuilder)localObject).append("sdkPerfStart.").append(localp.getClass().getName()).append('=').append(System.nanoTime() - l).append('\n');
      }
      Log.d("CrashlyticsInternal", ((StringBuilder)localObject).toString());
    }
    for (;;)
    {
      return;
      localObject = this.i.values().iterator();
      while (((Iterator)localObject).hasNext()) {
        ((p)((Iterator)localObject).next()).a(localContext);
      }
    }
  }
  
  public final Application d()
  {
    return this.e;
  }
  
  public final Activity e()
  {
    if (this.f != null) {
      return (Activity)this.f.get();
    }
    return null;
  }
  
  public final boolean f()
  {
    return this.c;
  }
  
  public final int g()
  {
    return this.h;
  }
  
  public final String getVersion()
  {
    return "1.1.11.10";
  }
  
  public final File h()
  {
    return this.d;
  }
  
  public final String i()
  {
    return this.g;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */