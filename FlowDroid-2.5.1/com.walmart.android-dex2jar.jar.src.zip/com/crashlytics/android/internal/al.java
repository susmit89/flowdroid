package com.crashlytics.android.internal;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

final class al
  implements ThreadFactory
{
  al(String paramString, AtomicLong paramAtomicLong) {}
  
  public final Thread newThread(Runnable paramRunnable)
  {
    paramRunnable = Executors.defaultThreadFactory().newThread(new am(this, paramRunnable));
    paramRunnable.setName(String.format(Locale.US, this.a, new Object[] { Long.valueOf(this.b.getAndIncrement()) }));
    return paramRunnable;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */