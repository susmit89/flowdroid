package com.crashlytics.android.internal;

import java.io.File;
import java.util.Iterator;
import java.util.List;

final class H
  extends Z
  implements N
{
  public H(String paramString1, String paramString2, av paramav)
  {
    super(paramString1, paramString2, paramav, ax.b);
  }
  
  public final boolean a(String paramString, List<File> paramList)
  {
    boolean bool = false;
    paramString = b().a("X-CRASHLYTICS-API-CLIENT-TYPE", "android").a("X-CRASHLYTICS-API-CLIENT-VERSION", v.a().getVersion()).a("X-CRASHLYTICS-API-KEY", paramString);
    Iterator localIterator = paramList.iterator();
    int i = 0;
    while (localIterator.hasNext())
    {
      File localFile = (File)localIterator.next();
      ab.c("Adding analytics session file " + localFile.getName() + " to multipart POST");
      paramString.a("session_analytics_file_" + i, localFile.getName(), "application/vnd.crashlytics.android.events", localFile);
      i += 1;
    }
    ab.c("Sending " + paramList.size() + " analytics files to " + a());
    i = paramString.b();
    ab.c("Response code for analytics file send is " + i);
    if (r.a(i) == 0) {
      bool = true;
    }
    return bool;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/H.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */