package com.crashlytics.android.internal;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public abstract interface aB
{
  public static final aB a = new aC();
  
  public abstract HttpURLConnection a(URL paramURL)
    throws IOException;
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */