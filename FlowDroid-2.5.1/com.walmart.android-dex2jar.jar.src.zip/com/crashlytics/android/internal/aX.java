package com.crashlytics.android.internal;

public final class aX
{
  public final aM a;
  public final aR b;
  public final aQ c;
  public final aP d;
  public final aK e;
  public final long f;
  
  public aX(long paramLong, aM paramaM, aR paramaR, aQ paramaQ, aP paramaP, aK paramaK, int paramInt1, int paramInt2)
  {
    this.f = paramLong;
    this.a = paramaM;
    this.b = paramaR;
    this.c = paramaQ;
    this.d = paramaP;
    this.e = paramaK;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */