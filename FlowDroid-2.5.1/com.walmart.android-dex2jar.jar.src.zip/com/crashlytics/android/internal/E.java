package com.crashlytics.android.internal;

final class E
  extends aa
{
  E(D paramD) {}
  
  public final void a()
  {
    try
    {
      D.a(this.a);
      return;
    }
    catch (Exception localException)
    {
      v.a().b().a("Crashlytics", "Problem encountered during Crashlytics initialization.", localException);
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */