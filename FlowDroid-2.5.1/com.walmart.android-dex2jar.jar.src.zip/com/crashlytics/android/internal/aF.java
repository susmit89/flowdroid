package com.crashlytics.android.internal;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

public final class aF
  extends BufferedOutputStream
{
  private final CharsetEncoder a;
  
  public aF(OutputStream paramOutputStream, String paramString, int paramInt)
  {
    super(paramOutputStream, paramInt);
    this.a = Charset.forName(ay.b(paramString)).newEncoder();
  }
  
  public final aF a(String paramString)
    throws IOException
  {
    paramString = this.a.encode(CharBuffer.wrap(paramString));
    super.write(paramString.array(), 0, paramString.limit());
    return this;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */