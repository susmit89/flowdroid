package com.crashlytics.android.internal;

final class Y
  implements Runnable
{
  private final K a;
  private final U b;
  
  public Y(K paramK, U paramU)
  {
    this.a = paramK;
    this.b = paramU;
  }
  
  public final void run()
  {
    try
    {
      ab.c("Performing time based analytics file roll over.");
      if (!this.a.a()) {
        this.b.c();
      }
      return;
    }
    catch (Exception localException)
    {
      ab.d("Crashlytics failed to roll over session analytics file");
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */