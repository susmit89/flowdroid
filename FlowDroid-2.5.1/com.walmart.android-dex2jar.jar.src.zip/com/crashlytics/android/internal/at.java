package com.crashlytics.android.internal;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

final class at
  extends InputStream
{
  private int a;
  private int b;
  
  private at(aq paramaq, as paramas)
  {
    this.a = aq.a(paramaq, paramas.b + 4);
    this.b = paramas.c;
  }
  
  public final int read()
    throws IOException
  {
    if (this.b == 0) {
      return -1;
    }
    aq.a(this.c).seek(this.a);
    int i = aq.a(this.c).read();
    this.a = aq.a(this.c, this.a + 1);
    this.b -= 1;
    return i;
  }
  
  public final int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    aq.a(paramArrayOfByte, "buffer");
    if (((paramInt1 | paramInt2) < 0) || (paramInt2 > paramArrayOfByte.length - paramInt1)) {
      throw new ArrayIndexOutOfBoundsException();
    }
    if (this.b > 0)
    {
      int i = paramInt2;
      if (paramInt2 > this.b) {
        i = this.b;
      }
      aq.a(this.c, this.a, paramArrayOfByte, paramInt1, i);
      this.a = aq.a(this.c, this.a + i);
      this.b -= i;
      return i;
    }
    return -1;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */