package com.crashlytics.android.internal;

import java.util.Map;
import java.util.Set;

abstract interface i
{
  public static final i a = new j();
  
  public abstract Map<Class<?>, h> a(Object paramObject);
  
  public abstract Map<Class<?>, Set<g>> b(Object paramObject);
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */