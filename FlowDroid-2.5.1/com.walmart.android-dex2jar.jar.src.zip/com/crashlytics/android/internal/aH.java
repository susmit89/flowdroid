package com.crashlytics.android.internal;

import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

final class aH
  implements X509TrustManager
{
  private final TrustManager[] a;
  private final aI b;
  private final long c;
  private final List<byte[]> d = new LinkedList();
  private final Set<X509Certificate> e = Collections.synchronizedSet(new HashSet());
  
  public aH(aI paramaI, aG paramaG)
  {
    this.a = a(paramaI);
    this.b = paramaI;
    this.c = -1L;
    paramaI = paramaG.c();
    int j = paramaI.length;
    int i = 0;
    while (i < j)
    {
      paramaG = paramaI[i];
      this.d.add(a(paramaG));
      i += 1;
    }
  }
  
  private boolean a(X509Certificate paramX509Certificate)
    throws CertificateException
  {
    try
    {
      paramX509Certificate = MessageDigest.getInstance("SHA1").digest(paramX509Certificate.getPublicKey().getEncoded());
      Iterator localIterator = this.d.iterator();
      while (localIterator.hasNext())
      {
        boolean bool = Arrays.equals((byte[])localIterator.next(), paramX509Certificate);
        if (bool) {
          return true;
        }
      }
      return false;
    }
    catch (NoSuchAlgorithmException paramX509Certificate)
    {
      throw new CertificateException(paramX509Certificate);
    }
  }
  
  private static byte[] a(String paramString)
  {
    int j = paramString.length();
    byte[] arrayOfByte = new byte[j / 2];
    int i = 0;
    while (i < j)
    {
      arrayOfByte[(i / 2)] = ((byte)((Character.digit(paramString.charAt(i), 16) << 4) + Character.digit(paramString.charAt(i + 1), 16)));
      i += 2;
    }
    return arrayOfByte;
  }
  
  private static TrustManager[] a(aI paramaI)
  {
    try
    {
      TrustManagerFactory localTrustManagerFactory = TrustManagerFactory.getInstance("X509");
      localTrustManagerFactory.init(paramaI.a);
      paramaI = localTrustManagerFactory.getTrustManagers();
      return paramaI;
    }
    catch (NoSuchAlgorithmException paramaI)
    {
      throw new AssertionError(paramaI);
    }
    catch (KeyStoreException paramaI)
    {
      throw new AssertionError(paramaI);
    }
  }
  
  public final void checkClientTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString)
    throws CertificateException
  {
    throw new CertificateException("Client certificates not supported!");
  }
  
  public final void checkServerTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString)
    throws CertificateException
  {
    if (this.e.contains(paramArrayOfX509Certificate[0])) {
      return;
    }
    TrustManager[] arrayOfTrustManager = this.a;
    int j = arrayOfTrustManager.length;
    int i = 0;
    while (i < j)
    {
      ((X509TrustManager)arrayOfTrustManager[i]).checkServerTrusted(paramArrayOfX509Certificate, paramString);
      i += 1;
    }
    if ((this.c != -1L) && (System.currentTimeMillis() - this.c > 15552000000L))
    {
      v.a().b().c("Crashlytics", "Certificate pins are stale, (" + (System.currentTimeMillis() - this.c) + " millis vs 15552000000" + " millis) falling back to system trust.");
      this.e.add(paramArrayOfX509Certificate[0]);
      return;
    }
    paramString = av.a(paramArrayOfX509Certificate, this.b);
    j = paramString.length;
    i = 0;
    for (;;)
    {
      if (i >= j) {
        break label180;
      }
      if (a(paramString[i])) {
        break;
      }
      i += 1;
    }
    label180:
    throw new CertificateException("No valid pins found in chain!");
  }
  
  public final X509Certificate[] getAcceptedIssuers()
  {
    return null;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */