package com.crashlytics.android.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;

public class aJ
{
  private final String a;
  private final Context b;
  
  public aJ(u paramu)
  {
    if (paramu.getContext() == null) {
      throw new IllegalStateException("Cannot get directory before context has been set. Call Sdk.start() first");
    }
    this.b = paramu.getContext();
    this.a = paramu.getClass().getName();
  }
  
  public SharedPreferences a()
  {
    return this.b.getSharedPreferences(this.a, 0);
  }
  
  public boolean a(SharedPreferences.Editor paramEditor)
  {
    if (Build.VERSION.SDK_INT >= 9)
    {
      paramEditor.apply();
      return true;
    }
    return paramEditor.commit();
  }
  
  public SharedPreferences.Editor b()
  {
    return a().edit();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */