package com.crashlytics.android.internal;

public final class aQ
{
  public final String a;
  public final String b;
  public final String c;
  public final boolean d;
  public final String e;
  public final boolean f;
  public final String g;
  
  public aQ(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, String paramString4, boolean paramBoolean2, String paramString5)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramBoolean1;
    this.e = paramString4;
    this.f = paramBoolean2;
    this.g = paramString5;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aQ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */