package com.crashlytics.android.internal;

public abstract interface m
{
  public static final m a = new n();
  public static final m b = new o();
  
  public abstract void a(b paramb);
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */