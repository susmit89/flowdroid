package com.crashlytics.android.internal;

final class Q
  implements Runnable
{
  Q(O paramO, V paramV, boolean paramBoolean) {}
  
  public final void run()
  {
    try
    {
      this.c.a.a(this.a);
      if (this.b) {
        this.c.a.d();
      }
      return;
    }
    catch (Exception localException)
    {
      ab.d("Crashlytics failed to record session event.");
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/Q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */