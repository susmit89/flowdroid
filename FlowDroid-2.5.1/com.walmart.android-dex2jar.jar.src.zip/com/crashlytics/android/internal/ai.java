package com.crashlytics.android.internal;

public enum ai
{
  private final int e;
  
  private ai(int paramInt)
  {
    this.e = paramInt;
  }
  
  public static ai a(String paramString)
  {
    if (paramString != null) {}
    for (int i = 1; i != 0; i = 0) {
      return d;
    }
    return a;
  }
  
  public final int a()
  {
    return this.e;
  }
  
  public final String toString()
  {
    return Integer.toString(this.e);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */