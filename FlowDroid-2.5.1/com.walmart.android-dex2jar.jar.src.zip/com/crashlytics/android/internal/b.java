package com.crashlytics.android.internal;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArraySet;

public class b
{
  public static final String a = "default";
  private final ConcurrentMap<Class<?>, Set<g>> b = new ConcurrentHashMap();
  private final ConcurrentMap<Class<?>, h> c = new ConcurrentHashMap();
  private final String d;
  private final m e;
  private final i f;
  private final ThreadLocal<ConcurrentLinkedQueue<e>> g = new c(this);
  private final ThreadLocal<Boolean> h = new d(this);
  private final Map<Class<?>, Set<Class<?>>> i = new HashMap();
  
  public b()
  {
    this("default");
  }
  
  public b(m paramm)
  {
    this(paramm, "default");
  }
  
  public b(m paramm, String paramString)
  {
    this(paramm, paramString, i.a);
  }
  
  private b(m paramm, String paramString, i parami)
  {
    this.e = paramm;
    this.d = paramString;
    this.f = parami;
  }
  
  public b(String paramString)
  {
    this(m.b, paramString);
  }
  
  private Set<g> a(Class<?> paramClass)
  {
    return (Set)this.b.get(paramClass);
  }
  
  private void a()
  {
    if (((Boolean)this.h.get()).booleanValue()) {
      return;
    }
    this.h.set(Boolean.valueOf(true));
    try
    {
      for (;;)
      {
        e locale = (e)((ConcurrentLinkedQueue)this.g.get()).poll();
        if (locale == null) {
          break;
        }
        if (locale.b.a()) {
          a(locale.a, locale.b);
        }
      }
    }
    finally
    {
      this.h.set(Boolean.valueOf(false));
    }
  }
  
  private void a(g paramg, h paramh)
  {
    Object localObject1 = null;
    try
    {
      Object localObject2 = paramh.c();
      paramh = (h)localObject2;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      for (;;)
      {
        a("Producer " + paramh + " threw an exception.", localInvocationTargetException);
        paramh = (h)localObject1;
      }
      a(paramh, paramg);
    }
    if (paramh == null) {
      return;
    }
  }
  
  private static void a(Object paramObject, g paramg)
  {
    try
    {
      paramg.a(paramObject);
      return;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      a("Could not dispatch event: " + paramObject.getClass() + " to handler " + paramg, localInvocationTargetException);
    }
  }
  
  private static void a(String paramString, InvocationTargetException paramInvocationTargetException)
  {
    paramInvocationTargetException = paramInvocationTargetException.getCause();
    if (paramInvocationTargetException != null) {
      throw new RuntimeException(paramString, paramInvocationTargetException);
    }
    throw new RuntimeException(paramString);
  }
  
  public void a(Object paramObject)
  {
    this.e.a(this);
    Object localObject1 = this.f.a(paramObject);
    Object localObject2 = ((Map)localObject1).keySet().iterator();
    Object localObject5;
    while (((Iterator)localObject2).hasNext())
    {
      localObject4 = (Class)((Iterator)localObject2).next();
      localObject3 = (h)((Map)localObject1).get(localObject4);
      localObject5 = (h)this.c.putIfAbsent(localObject4, localObject3);
      if (localObject5 != null) {
        throw new IllegalArgumentException("Producer method for type " + localObject4 + " found on type " + ((h)localObject3).a.getClass() + ", but already registered by type " + ((h)localObject5).a.getClass() + ".");
      }
      localObject4 = (Set)this.b.get(localObject4);
      if ((localObject4 != null) && (!((Set)localObject4).isEmpty()))
      {
        localObject4 = ((Set)localObject4).iterator();
        while (((Iterator)localObject4).hasNext()) {
          a((g)((Iterator)localObject4).next(), (h)localObject3);
        }
      }
    }
    Object localObject3 = this.f.b(paramObject);
    Object localObject4 = ((Map)localObject3).keySet().iterator();
    while (((Iterator)localObject4).hasNext())
    {
      localObject5 = (Class)((Iterator)localObject4).next();
      localObject1 = (Set)this.b.get(localObject5);
      paramObject = localObject1;
      if (localObject1 == null)
      {
        localObject1 = new CopyOnWriteArraySet();
        localObject2 = (Set)this.b.putIfAbsent(localObject5, localObject1);
        paramObject = localObject2;
        if (localObject2 == null) {
          paramObject = localObject1;
        }
      }
      ((Set)paramObject).addAll((Set)((Map)localObject3).get(localObject5));
    }
    paramObject = ((Map)localObject3).entrySet().iterator();
    label468:
    while (((Iterator)paramObject).hasNext())
    {
      localObject2 = (Map.Entry)((Iterator)paramObject).next();
      localObject1 = (Class)((Map.Entry)localObject2).getKey();
      localObject1 = (h)this.c.get(localObject1);
      if ((localObject1 != null) && (((h)localObject1).a()))
      {
        localObject2 = ((Set)((Map.Entry)localObject2).getValue()).iterator();
        for (;;)
        {
          if (!((Iterator)localObject2).hasNext()) {
            break label468;
          }
          localObject3 = (g)((Iterator)localObject2).next();
          if (!((h)localObject1).a()) {
            break;
          }
          if (((g)localObject3).a()) {
            a((g)localObject3, (h)localObject1);
          }
        }
      }
    }
  }
  
  public void b(Object paramObject)
  {
    this.e.a(this);
    Iterator localIterator = this.f.a(paramObject).entrySet().iterator();
    Object localObject3;
    Object localObject1;
    Object localObject2;
    while (localIterator.hasNext())
    {
      localObject3 = (Map.Entry)localIterator.next();
      localObject1 = (Class)((Map.Entry)localObject3).getKey();
      localObject2 = (h)this.c.get(localObject1);
      localObject3 = (h)((Map.Entry)localObject3).getValue();
      if ((localObject3 == null) || (!((h)localObject3).equals(localObject2))) {
        throw new IllegalArgumentException("Missing event producer for an annotated method. Is " + paramObject.getClass() + " registered?");
      }
      ((h)this.c.remove(localObject1)).b();
    }
    localIterator = this.f.b(paramObject).entrySet().iterator();
    while (localIterator.hasNext())
    {
      localObject2 = (Map.Entry)localIterator.next();
      localObject1 = a((Class)((Map.Entry)localObject2).getKey());
      localObject2 = (Collection)((Map.Entry)localObject2).getValue();
      if ((localObject1 == null) || (!((Set)localObject1).containsAll((Collection)localObject2))) {
        throw new IllegalArgumentException("Missing event handler for an annotated method. Is " + paramObject.getClass() + " registered?");
      }
      localObject3 = ((Set)localObject1).iterator();
      while (((Iterator)localObject3).hasNext())
      {
        g localg = (g)((Iterator)localObject3).next();
        if (((Collection)localObject2).contains(localg)) {
          localg.b();
        }
      }
      ((Set)localObject1).removeAll((Collection)localObject2);
    }
  }
  
  public void c(Object paramObject)
  {
    this.e.a(this);
    Object localObject3 = paramObject.getClass();
    Object localObject2 = (Set)this.i.get(localObject3);
    Object localObject1 = localObject2;
    if (localObject2 == null)
    {
      localObject2 = new LinkedList();
      localObject1 = new HashSet();
      ((List)localObject2).add(localObject3);
      while (!((List)localObject2).isEmpty())
      {
        Class localClass = (Class)((List)localObject2).remove(0);
        ((Set)localObject1).add(localClass);
        localClass = localClass.getSuperclass();
        if (localClass != null) {
          ((List)localObject2).add(localClass);
        }
      }
      this.i.put(localObject3, localObject1);
    }
    localObject1 = ((Set)localObject1).iterator();
    int j = 0;
    if (((Iterator)localObject1).hasNext())
    {
      localObject2 = a((Class)((Iterator)localObject1).next());
      if ((localObject2 != null) && (!((Set)localObject2).isEmpty()))
      {
        localObject2 = ((Set)localObject2).iterator();
        while (((Iterator)localObject2).hasNext())
        {
          localObject3 = (g)((Iterator)localObject2).next();
          ((ConcurrentLinkedQueue)this.g.get()).offer(new e(paramObject, (g)localObject3));
        }
      }
    }
    for (;;)
    {
      break;
      if ((j == 0) && (!(paramObject instanceof f))) {
        c(new f(this, paramObject));
      }
      a();
      return;
      j = 1;
    }
  }
  
  public String toString()
  {
    return "[Bus \"" + this.d + "\"]";
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */