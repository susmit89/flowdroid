package com.crashlytics.android.internal;

public class aK
{
  public final String a;
  public final int b;
  public final int c;
  
  public aK(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.a = paramString;
    this.b = paramInt1;
    this.c = paramInt2;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/aK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */