package com.crashlytics.android.internal;

final class as
{
  static final as a = new as(0, 0);
  final int b;
  final int c;
  
  as(int paramInt1, int paramInt2)
  {
    this.b = paramInt1;
    this.c = paramInt2;
  }
  
  public final String toString()
  {
    return getClass().getSimpleName() + "[position = " + this.b + ", length = " + this.c + "]";
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */