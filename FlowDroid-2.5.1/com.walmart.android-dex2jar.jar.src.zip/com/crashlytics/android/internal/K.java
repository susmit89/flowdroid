package com.crashlytics.android.internal;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

final class K
{
  private final X a;
  private final ah b;
  private aK c;
  private final aj d;
  private final int e;
  private List<ak> f = new CopyOnWriteArrayList();
  
  K(X paramX, ah paramah, aj paramaj)
    throws IOException
  {
    this(paramX, paramah, paramaj, 100);
  }
  
  private K(X paramX, ah paramah, aj paramaj, int paramInt)
    throws IOException
  {
    this.a = paramX;
    this.d = paramaj;
    this.b = paramah;
    this.b.a();
    this.e = 100;
  }
  
  private void a(String paramString)
  {
    paramString = this.f.iterator();
    while (paramString.hasNext())
    {
      ak localak = (ak)paramString.next();
      try
      {
        localak.c();
      }
      catch (Exception localException)
      {
        v.a().b().a("Crashlytics", "One of the roll over listeners threw an exception", localException);
      }
    }
  }
  
  private static long b(String paramString)
  {
    paramString = paramString.split("_");
    if (paramString.length != 3) {
      return 0L;
    }
    try
    {
      long l = Long.valueOf(paramString[2]).longValue();
      return l;
    }
    catch (NumberFormatException paramString) {}
    return 0L;
  }
  
  private int e()
  {
    if (this.c == null) {
      return 8000;
    }
    return this.c.c;
  }
  
  final void a(V paramV)
    throws IOException
  {
    paramV = this.a.a(paramV);
    int i = paramV.length;
    if (!this.d.a(i, e()))
    {
      ab.a(4, String.format(Locale.US, "session analytics events file is %d bytes, new event is %d bytes, this is over flush limit of %d, rolling it over", new Object[] { Integer.valueOf(this.d.a()), Integer.valueOf(i), Integer.valueOf(e()) }));
      a();
    }
    this.d.a(paramV);
  }
  
  final void a(aK paramaK)
  {
    this.c = paramaK;
  }
  
  final void a(ak paramak)
  {
    if (paramak != null) {
      this.f.add(paramak);
    }
  }
  
  final void a(List<File> paramList)
  {
    this.d.a(paramList);
  }
  
  final boolean a()
    throws IOException
  {
    boolean bool = true;
    Object localObject = null;
    if (!this.d.b())
    {
      localObject = UUID.randomUUID();
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("sa");
      localStringBuilder.append("_");
      localStringBuilder.append(((UUID)localObject).toString());
      localStringBuilder.append("_");
      localStringBuilder.append(this.b.a());
      localStringBuilder.append(".tap");
      localObject = localStringBuilder.toString();
      this.d.a((String)localObject);
      ab.a(4, String.format(Locale.US, "generated new to-send analytics file %s", new Object[] { localObject }));
      this.b.a();
    }
    for (;;)
    {
      a((String)localObject);
      return bool;
      bool = false;
    }
  }
  
  final List<File> b()
  {
    return this.d.a(1);
  }
  
  final void c()
  {
    this.d.a(this.d.c());
    this.d.d();
  }
  
  final void d()
  {
    Object localObject2 = this.d.c();
    if (((List)localObject2).size() <= this.e) {
      return;
    }
    int i = ((List)localObject2).size() - this.e;
    ab.c(String.format(Locale.US, "Found %d files in session analytics roll over directory, this is greater than %d, deleting %d oldest files", new Object[] { Integer.valueOf(((List)localObject2).size()), Integer.valueOf(this.e), Integer.valueOf(i) }));
    Object localObject1 = new TreeSet(new L(this));
    localObject2 = ((List)localObject2).iterator();
    while (((Iterator)localObject2).hasNext())
    {
      File localFile = (File)((Iterator)localObject2).next();
      ((TreeSet)localObject1).add(new M(this, localFile, b(localFile.getName())));
    }
    localObject2 = new ArrayList();
    localObject1 = ((TreeSet)localObject1).iterator();
    do
    {
      if (!((Iterator)localObject1).hasNext()) {
        break;
      }
      ((ArrayList)localObject2).add(((M)((Iterator)localObject1).next()).a);
    } while (((ArrayList)localObject2).size() != i);
    this.d.a((List)localObject2);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/internal/K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */