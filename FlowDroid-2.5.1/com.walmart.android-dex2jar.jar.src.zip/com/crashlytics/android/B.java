package com.crashlytics.android;

import com.crashlytics.android.internal.q;
import java.io.File;
import java.util.concurrent.Callable;

final class B
  implements Callable<Boolean>
{
  B(v paramv) {}
  
  private Boolean a()
    throws Exception
  {
    try
    {
      boolean bool = v.f(this.a).delete();
      com.crashlytics.android.internal.v.a().b().a("Crashlytics", "Initialization marker file removed: " + bool);
      return Boolean.valueOf(bool);
    }
    catch (Exception localException)
    {
      com.crashlytics.android.internal.v.a().b().a("Crashlytics", "Problem encountered deleting Crashlytics initialization marker.", localException);
    }
    return Boolean.valueOf(false);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */