package com.crashlytics.android;

import java.util.concurrent.Callable;

final class A
  implements Callable<Void>
{
  A(v paramv) {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/com/crashlytics/android/A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */