package android.support.v7.app;

import android.app.Activity;

public class ActionBarImplJB
  extends ActionBarImplICS
{
  public ActionBarImplJB(Activity paramActivity, ActionBar.Callback paramCallback)
  {
    super(paramActivity, paramCallback, false);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/android/support/v7/app/ActionBarImplJB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */