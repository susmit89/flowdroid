package RLSDK;

public final class de
{
  private static final int[] a = { 8, 1, 1, 1, 1, 1, 1, 3 };
  private static final int[] b = { 3, 1, 1, 1, 1, 1, 1, 8 };
  private static final int[] c = { 7, 1, 1, 3, 1, 1, 1, 2, 1 };
  private static final int[] d = { 1, 2, 1, 1, 1, 3, 1, 1, 7 };
  private final s e;
  
  public de(s params)
  {
    this.e = params;
  }
  
  private static void a(ad[] paramArrayOfad, boolean paramBoolean)
  {
    float f2 = paramArrayOfad[4].b() - paramArrayOfad[6].b();
    float f1 = f2;
    if (paramBoolean) {
      f1 = -f2;
    }
    if (f1 > 2.0F)
    {
      f1 = paramArrayOfad[4].a();
      f2 = paramArrayOfad[0].a();
      f3 = paramArrayOfad[6].a();
      f4 = paramArrayOfad[0].a();
      f1 = (f1 - f2) * (paramArrayOfad[6].b() - paramArrayOfad[0].b()) / (f3 - f4);
    }
    do
    {
      paramArrayOfad[4] = new ad(paramArrayOfad[4].a(), f1 + paramArrayOfad[4].b());
      for (;;)
      {
        f2 = paramArrayOfad[7].b() - paramArrayOfad[5].b();
        f1 = f2;
        if (paramBoolean) {
          f1 = -f2;
        }
        if (f1 <= 2.0F) {
          break;
        }
        f1 = paramArrayOfad[5].a();
        f2 = paramArrayOfad[1].a();
        f3 = paramArrayOfad[7].a();
        f4 = paramArrayOfad[1].a();
        f1 = (f1 - f2) * (paramArrayOfad[7].b() - paramArrayOfad[1].b()) / (f3 - f4);
        paramArrayOfad[5] = new ad(paramArrayOfad[5].a(), f1 + paramArrayOfad[5].b());
        return;
        if (-f1 > 2.0F)
        {
          f1 = paramArrayOfad[2].a();
          f2 = paramArrayOfad[6].a();
          f3 = paramArrayOfad[2].a();
          f4 = paramArrayOfad[4].a();
          f1 = (f1 - f2) * (paramArrayOfad[2].b() - paramArrayOfad[4].b()) / (f3 - f4);
          paramArrayOfad[6] = new ad(paramArrayOfad[6].a(), paramArrayOfad[6].b() - f1);
        }
      }
    } while (-f1 <= 2.0F);
    f1 = paramArrayOfad[3].a();
    f2 = paramArrayOfad[7].a();
    float f3 = paramArrayOfad[3].a();
    float f4 = paramArrayOfad[5].a();
    f1 = (f1 - f2) * (paramArrayOfad[3].b() - paramArrayOfad[5].b()) / (f3 - f4);
    paramArrayOfad[7] = new ad(paramArrayOfad[7].a(), paramArrayOfad[7].b() - f1);
  }
  
  private static int[] a(ak paramak, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int[] paramArrayOfInt)
  {
    int i3 = paramArrayOfInt.length;
    int[] arrayOfInt = new int[i3];
    int m = 0;
    int k = paramInt1;
    int i = paramInt1;
    if (k < paramInt1 + paramInt3)
    {
      int j;
      if ((paramak.a(k, paramInt2) ^ paramBoolean))
      {
        arrayOfInt[m] += 1;
        j = i;
      }
      for (;;)
      {
        k += 1;
        i = j;
        break;
        if (m == i3 - 1)
        {
          int i4 = arrayOfInt.length;
          int i1 = 0;
          int n = 0;
          int i2;
          for (j = 0; n < i4; j = i2 + j)
          {
            i2 = arrayOfInt[n];
            i1 += paramArrayOfInt[n];
            n += 1;
          }
          if (j < i1) {
            j = Integer.MAX_VALUE;
          }
          while (j < 107)
          {
            return new int[] { i, k };
            int i5 = (j << 8) / i1;
            i1 = 0;
            n = 0;
            for (;;)
            {
              if (n >= i4) {
                break label269;
              }
              i2 = arrayOfInt[n] << 8;
              int i6 = paramArrayOfInt[n] * i5;
              if (i2 > i6) {
                i2 -= i6;
              }
              for (;;)
              {
                if (i2 <= i5 * 204 >> 8) {
                  break label253;
                }
                j = Integer.MAX_VALUE;
                break;
                i2 = i6 - i2;
              }
              label253:
              i1 += i2;
              n += 1;
            }
            label269:
            j = i1 / j;
          }
          j = i + (arrayOfInt[0] + arrayOfInt[1]);
          i = 2;
          while (i < i3)
          {
            arrayOfInt[(i - 2)] = arrayOfInt[i];
            i += 1;
          }
          arrayOfInt[(i3 - 2)] = 0;
          arrayOfInt[(i3 - 1)] = 0;
        }
        for (i = m - 1;; i = m)
        {
          arrayOfInt[i] = 1;
          if (paramBoolean) {
            break label384;
          }
          paramBoolean = true;
          m = i;
          break;
          m += 1;
          j = i;
        }
        label384:
        paramBoolean = false;
        m = i;
      }
    }
    return null;
  }
  
  public final ar a()
    throws y
  {
    ak localak = this.e.c();
    int m = localak.b;
    int k = localak.a;
    Object localObject2 = new ad[8];
    int i = 0;
    Object localObject1;
    if (i < m)
    {
      localObject1 = a(localak, 0, i, k, false, a);
      if (localObject1 != null)
      {
        localObject2[0] = new ad(localObject1[0], i);
        localObject2[4] = new ad(localObject1[1], i);
      }
    }
    for (int j = 1;; j = 0)
    {
      i = j;
      if (j != 0)
      {
        i = m - 1;
        label107:
        if (i <= 0) {
          break label1051;
        }
        localObject1 = a(localak, 0, i, k, false, a);
        if (localObject1 == null) {
          break label669;
        }
        localObject2[1] = new ad(localObject1[0], i);
        localObject2[5] = new ad(localObject1[1], i);
      }
      label177:
      label253:
      label320:
      label353:
      label424:
      label500:
      label569:
      label638:
      label669:
      label676:
      label683:
      label696:
      label703:
      label710:
      label730:
      label736:
      label743:
      label1026:
      label1031:
      label1036:
      label1041:
      label1046:
      label1051:
      for (i = 1;; i = 0)
      {
        j = i;
        if (i != 0)
        {
          i = 0;
          if (i >= m) {
            break label1046;
          }
          localObject1 = a(localak, 0, i, k, false, c);
          if (localObject1 == null) {
            break label676;
          }
          localObject2[2] = new ad(localObject1[1], i);
          localObject2[6] = new ad(localObject1[0], i);
        }
        for (j = 1;; j = 0)
        {
          i = j;
          if (j != 0)
          {
            i = m - 1;
            if (i <= 0) {
              break label1041;
            }
            localObject1 = a(localak, 0, i, k, false, c);
            if (localObject1 == null) {
              break label683;
            }
            localObject2[3] = new ad(localObject1[1], i);
            localObject2[7] = new ad(localObject1[0], i);
          }
          for (i = 1;; i = 0)
          {
            if (i != 0)
            {
              if (localObject2 != null) {
                break label730;
              }
              k = localak.b;
              m = localak.a >> 1;
              localObject1 = new ad[8];
              i = k - 1;
              if (i <= 0) {
                break label1036;
              }
              localObject2 = a(localak, m, i, m, true, b);
              if (localObject2 == null) {
                break label696;
              }
              localObject1[0] = new ad(localObject2[1], i);
              localObject1[4] = new ad(localObject2[0], i);
            }
            for (j = 1;; j = 0)
            {
              i = j;
              if (j != 0)
              {
                i = 0;
                if (i >= k) {
                  break label1031;
                }
                localObject2 = a(localak, m, i, m, true, b);
                if (localObject2 == null) {
                  break label703;
                }
                localObject1[1] = new ad(localObject2[1], i);
                localObject1[5] = new ad(localObject2[0], i);
              }
              for (i = 1;; i = 0)
              {
                j = i;
                if (i != 0)
                {
                  i = k - 1;
                  if (i <= 0) {
                    break label1026;
                  }
                  localObject2 = a(localak, 0, i, m, false, d);
                  if (localObject2 == null) {
                    break label710;
                  }
                  localObject1[2] = new ad(localObject2[0], i);
                  localObject1[6] = new ad(localObject2[1], i);
                }
                for (j = 1;; j = 0)
                {
                  if (j != 0)
                  {
                    i = 0;
                    if (i < k)
                    {
                      localObject2 = a(localak, 0, i, m, false, d);
                      if (localObject2 != null)
                      {
                        localObject1[3] = new ad(localObject2[0], i);
                        localObject1[7] = new ad(localObject2[1], i);
                        i = 1;
                      }
                    }
                  }
                  for (;;)
                  {
                    if (i != 0)
                    {
                      localObject2 = localObject1;
                      if (localObject1 == null) {
                        break label736;
                      }
                      a((ad[])localObject1, true);
                    }
                    for (;;)
                    {
                      if (localObject1 != null) {
                        break label743;
                      }
                      throw y.a();
                      i += 1;
                      break;
                      i -= 1;
                      break label107;
                      i += 1;
                      break label177;
                      i -= 1;
                      break label253;
                      localObject2 = null;
                      break label320;
                      i -= 1;
                      break label353;
                      i += 1;
                      break label424;
                      i -= 1;
                      break label500;
                      i += 1;
                      break label569;
                      localObject1 = null;
                      break label638;
                      a((ad[])localObject2, false);
                      localObject1 = localObject2;
                    }
                    float f = ((ad.a(localObject1[0], localObject1[4]) + ad.a(localObject1[1], localObject1[5])) / 34.0F + (ad.a(localObject1[6], localObject1[2]) + ad.a(localObject1[7], localObject1[3])) / 36.0F) / 2.0F;
                    if (f < 1.0F) {
                      throw y.a();
                    }
                    localObject2 = localObject1[4];
                    ad localad1 = localObject1[6];
                    ad localad2 = localObject1[5];
                    ad localad3 = localObject1[7];
                    i = (int)(ad.a((ad)localObject2, localad1) / f + 0.5F);
                    i = (((int)(ad.a(localad2, localad3) / f + 0.5F) + i >> 1) + 8) / 17 * 17;
                    if (i <= 0) {
                      throw y.a();
                    }
                    localObject2 = localObject1[4];
                    localad1 = localObject1[5];
                    localad2 = localObject1[6];
                    localad3 = localObject1[7];
                    return new ar(au.a().a(localak, i, i, 0.0F, 0.0F, i, 0.0F, i, i, 0.0F, i, ((ad)localObject2).a(), ((ad)localObject2).b(), localad2.a(), localad2.b(), localad3.a(), localad3.b(), localad1.a(), localad1.b()), new ad[] { localObject1[4], localObject1[5], localObject1[6], localObject1[7] });
                    i = 0;
                    continue;
                    i = j;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/de.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */