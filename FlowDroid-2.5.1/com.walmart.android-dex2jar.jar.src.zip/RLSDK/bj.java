package RLSDK;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public final class bj
{
  private static final Integer[] a = { new Integer(0), new Integer(1), new Integer(2), new Integer(3), new Integer(4) };
  private final ak b;
  private final ay c;
  
  public bj(ak paramak)
    throws y
  {
    this.b = paramak;
    this.c = new ay(paramak);
  }
  
  private static int a(ad paramad1, ad paramad2)
  {
    return (int)((float)Math.sqrt((paramad1.a() - paramad2.a()) * (paramad1.a() - paramad2.a()) + (paramad1.b() - paramad2.b()) * (paramad1.b() - paramad2.b())) + 0.5F);
  }
  
  private static ak a(ak paramak, ad paramad1, ad paramad2, ad paramad3, ad paramad4, int paramInt1, int paramInt2)
    throws y
  {
    return au.a().a(paramak, paramInt1, paramInt2, 0.5F, 0.5F, paramInt1 - 0.5F, 0.5F, paramInt1 - 0.5F, paramInt2 - 0.5F, 0.5F, paramInt2 - 0.5F, paramad1.a(), paramad1.b(), paramad4.a(), paramad4.b(), paramad3.a(), paramad3.b(), paramad2.a(), paramad2.b());
  }
  
  private static void a(Hashtable paramHashtable, ad paramad)
  {
    Integer localInteger = (Integer)paramHashtable.get(paramad);
    if (localInteger == null) {}
    for (localInteger = a[1];; localInteger = a[(localInteger.intValue() + 1)])
    {
      paramHashtable.put(paramad, localInteger);
      return;
    }
  }
  
  private boolean a(ad paramad)
  {
    return (paramad.a() >= 0.0F) && (paramad.a() < this.b.a) && (paramad.b() > 0.0F) && (paramad.b() < this.b.b);
  }
  
  private a b(ad paramad1, ad paramad2)
  {
    int j = (int)paramad1.a();
    int i = (int)paramad1.b();
    int i1 = (int)paramad2.a();
    int i2 = (int)paramad2.b();
    int n;
    if (Math.abs(i2 - i) > Math.abs(i1 - j))
    {
      n = 1;
      if (n == 0) {
        break label342;
      }
    }
    for (;;)
    {
      int i8 = Math.abs(i2 - i);
      int i9 = Math.abs(i1 - j);
      int i5 = -i8;
      int i3;
      label87:
      int i4;
      label96:
      ak localak;
      label114:
      label122:
      boolean bool1;
      if (j < i1)
      {
        i3 = 1;
        if (i >= i2) {
          break label297;
        }
        i4 = 1;
        i6 = 0;
        localak = this.b;
        if (n == 0) {
          break label303;
        }
        k = j;
        if (n == 0) {
          break label309;
        }
        m = i;
        bool1 = localak.a(k, m);
        i5 >>= 1;
        k = i6;
        label143:
        i6 = k;
        if (i == i2) {
          break label329;
        }
        localak = this.b;
        if (n == 0) {
          break label316;
        }
        m = j;
        label168:
        if (n == 0) {
          break label322;
        }
      }
      label297:
      label303:
      label309:
      label316:
      label322:
      for (int i6 = i;; i6 = j)
      {
        boolean bool3 = localak.a(m, i6);
        m = k;
        boolean bool2 = bool1;
        if (bool3 != bool1)
        {
          m = k + 1;
          bool2 = bool3;
        }
        int i7 = i5 + i9;
        k = i7;
        i5 = j;
        if (i7 > 0)
        {
          i6 = m;
          if (j == i1) {
            break label329;
          }
          i5 = j + i3;
          k = i7 - i8;
        }
        i += i4;
        i6 = k;
        j = i5;
        k = m;
        bool1 = bool2;
        i5 = i6;
        break label143;
        n = 0;
        break;
        i3 = -1;
        break label87;
        i4 = -1;
        break label96;
        k = i;
        break label114;
        m = j;
        break label122;
        m = i;
        break label168;
      }
      label329:
      return new a(paramad1, paramad2, i6, (byte)0);
      label342:
      int k = i1;
      i1 = i2;
      int m = j;
      i2 = k;
      j = i;
      i = m;
    }
  }
  
  public final ar a()
    throws y
  {
    Object localObject1 = this.c.a();
    ad localad1 = localObject1[0];
    ad localad2 = localObject1[1];
    ad localad3 = localObject1[2];
    ad localad4 = localObject1[3];
    Object localObject2 = new Vector(4);
    ((Vector)localObject2).addElement(b(localad1, localad2));
    ((Vector)localObject2).addElement(b(localad1, localad3));
    ((Vector)localObject2).addElement(b(localad2, localad4));
    ((Vector)localObject2).addElement(b(localad3, localad4));
    an.a((Vector)localObject2, new b((byte)0));
    localObject1 = (a)((Vector)localObject2).elementAt(0);
    localObject2 = (a)((Vector)localObject2).elementAt(1);
    Hashtable localHashtable = new Hashtable();
    a(localHashtable, ((a)localObject1).a());
    a(localHashtable, ((a)localObject1).b());
    a(localHashtable, ((a)localObject2).a());
    a(localHashtable, ((a)localObject2).b());
    Enumeration localEnumeration = localHashtable.keys();
    Object localObject3 = null;
    localObject2 = null;
    Object localObject4 = null;
    while (localEnumeration.hasMoreElements())
    {
      localObject1 = (ad)localEnumeration.nextElement();
      if (((Integer)localHashtable.get(localObject1)).intValue() == 2) {
        localObject3 = localObject1;
      } else if (localObject2 == null) {
        localObject2 = localObject1;
      } else {
        localObject4 = localObject1;
      }
    }
    if ((localObject2 == null) || (localObject3 == null) || (localObject4 == null)) {
      throw y.a();
    }
    localObject1 = new ad[3];
    localObject1[0] = localObject2;
    localObject1[1] = localObject3;
    localObject1[2] = localObject4;
    ad.a((ad[])localObject1);
    localEnumeration = localObject1[0];
    ad localad5 = localObject1[1];
    ad localad6 = localObject1[2];
    if (!localHashtable.containsKey(localad1)) {
      localObject1 = localad1;
    }
    for (;;)
    {
      int k = b(localad6, (ad)localObject1).c();
      int j = b(localEnumeration, (ad)localObject1).c();
      int i = k;
      if ((k & 0x1) == 1) {
        i = k + 1;
      }
      k = i + 2;
      i = j;
      if ((j & 0x1) == 1) {
        i = j + 1;
      }
      i += 2;
      if ((k * 4 >= i * 7) || (i * 4 >= k * 7))
      {
        f1 = a(localad5, localEnumeration) / k;
        j = a(localad6, (ad)localObject1);
        f2 = (((ad)localObject1).a() - localad6.a()) / j;
        f3 = (((ad)localObject1).b() - localad6.b()) / j;
        localObject3 = new ad(f2 * f1 + ((ad)localObject1).a(), f1 * f3 + ((ad)localObject1).b());
        f1 = a(localad5, localad6) / i;
        j = a(localEnumeration, (ad)localObject1);
        f2 = (((ad)localObject1).a() - localEnumeration.a()) / j;
        f3 = (((ad)localObject1).b() - localEnumeration.b()) / j;
        localObject4 = new ad(f2 * f1 + ((ad)localObject1).a(), f1 * f3 + ((ad)localObject1).b());
        if (!a((ad)localObject3))
        {
          if (a((ad)localObject4)) {
            break label875;
          }
          localObject2 = null;
        }
        for (;;)
        {
          localObject3 = localObject2;
          if (localObject2 == null) {
            localObject3 = localObject1;
          }
          j = b(localad6, (ad)localObject3).c();
          k = b(localEnumeration, (ad)localObject3).c();
          i = j;
          if ((j & 0x1) == 1) {
            i = j + 1;
          }
          j = k;
          if ((k & 0x1) == 1) {
            j = k + 1;
          }
          localObject1 = a(this.b, localad6, localad5, localEnumeration, (ad)localObject3, i, j);
          return new ar((ak)localObject1, new ad[] { localad6, localad5, localEnumeration, localObject3 });
          if (!localHashtable.containsKey(localad2))
          {
            localObject1 = localad2;
            break;
          }
          if (localHashtable.containsKey(localad3)) {
            break label1237;
          }
          localObject1 = localad3;
          break;
          localObject2 = localObject3;
          if (a((ad)localObject4))
          {
            localObject2 = localObject3;
            if (Math.abs(k - b(localad6, (ad)localObject3).c()) + Math.abs(i - b(localEnumeration, (ad)localObject3).c()) > Math.abs(k - b(localad6, (ad)localObject4).c()) + Math.abs(i - b(localEnumeration, (ad)localObject4).c())) {
              label875:
              localObject2 = localObject4;
            }
          }
        }
      }
      i = Math.min(i, k);
      float f1 = a(localad5, localEnumeration) / i;
      j = a(localad6, (ad)localObject1);
      float f2 = (((ad)localObject1).a() - localad6.a()) / j;
      float f3 = (((ad)localObject1).b() - localad6.b()) / j;
      localObject3 = new ad(f2 * f1 + ((ad)localObject1).a(), f1 * f3 + ((ad)localObject1).b());
      f1 = a(localad5, localEnumeration) / i;
      i = a(localEnumeration, (ad)localObject1);
      f2 = (((ad)localObject1).a() - localEnumeration.a()) / i;
      f3 = (((ad)localObject1).b() - localEnumeration.b()) / i;
      localObject4 = new ad(f2 * f1 + ((ad)localObject1).a(), f1 * f3 + ((ad)localObject1).b());
      if (!a((ad)localObject3))
      {
        if (a((ad)localObject4)) {
          break label1230;
        }
        localObject2 = null;
      }
      for (;;)
      {
        localObject3 = localObject2;
        if (localObject2 == null) {
          localObject3 = localObject1;
        }
        j = Math.max(b(localad6, (ad)localObject3).c(), b(localEnumeration, (ad)localObject3).c()) + 1;
        i = j;
        if ((j & 0x1) == 1) {
          i = j + 1;
        }
        localObject1 = a(this.b, localad6, localad5, localEnumeration, (ad)localObject3, i, i);
        break;
        localObject2 = localObject3;
        if (a((ad)localObject4))
        {
          localObject2 = localObject3;
          if (Math.abs(b(localad6, (ad)localObject3).c() - b(localEnumeration, (ad)localObject3).c()) > Math.abs(b(localad6, (ad)localObject4).c() - b(localEnumeration, (ad)localObject4).c())) {
            label1230:
            localObject2 = localObject4;
          }
        }
      }
      label1237:
      localObject1 = localad4;
    }
  }
  
  private static final class a
  {
    private final ad a;
    private final ad b;
    private final int c;
    
    private a(ad paramad1, ad paramad2, int paramInt)
    {
      this.a = paramad1;
      this.b = paramad2;
      this.c = paramInt;
    }
    
    public final ad a()
    {
      return this.a;
    }
    
    public final ad b()
    {
      return this.b;
    }
    
    public final int c()
    {
      return this.c;
    }
    
    public final String toString()
    {
      return this.a + "/" + this.b + '/' + this.c;
    }
  }
  
  private static final class b
    implements ao
  {
    public final int a(Object paramObject1, Object paramObject2)
    {
      return ((bj.a)paramObject1).c() - ((bj.a)paramObject2).c();
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */