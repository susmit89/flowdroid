package RLSDK;

public final class bi
{
  private static final bi[] a = { new bi(1, 10, 10, 8, 8, new b(5, new a(1, 3, 0), 0)), new bi(2, 12, 12, 10, 10, new b(7, new a(1, 5, 0), 0)), new bi(3, 14, 14, 12, 12, new b(10, new a(1, 8, 0), 0)), new bi(4, 16, 16, 14, 14, new b(12, new a(1, 12, 0), 0)), new bi(5, 18, 18, 16, 16, new b(14, new a(1, 18, 0), 0)), new bi(6, 20, 20, 18, 18, new b(18, new a(1, 22, 0), 0)), new bi(7, 22, 22, 20, 20, new b(20, new a(1, 30, 0), 0)), new bi(8, 24, 24, 22, 22, new b(24, new a(1, 36, 0), 0)), new bi(9, 26, 26, 24, 24, new b(28, new a(1, 44, 0), 0)), new bi(10, 32, 32, 14, 14, new b(36, new a(1, 62, 0), 0)), new bi(11, 36, 36, 16, 16, new b(42, new a(1, 86, 0), 0)), new bi(12, 40, 40, 18, 18, new b(48, new a(1, 114, 0), 0)), new bi(13, 44, 44, 20, 20, new b(56, new a(1, 144, 0), 0)), new bi(14, 48, 48, 22, 22, new b(68, new a(1, 174, 0), 0)), new bi(15, 52, 52, 24, 24, new b(42, new a(2, 102, 0), 0)), new bi(16, 64, 64, 14, 14, new b(56, new a(2, 140, 0), 0)), new bi(17, 72, 72, 16, 16, new b(36, new a(4, 92, 0), 0)), new bi(18, 80, 80, 18, 18, new b(48, new a(4, 114, 0), 0)), new bi(19, 88, 88, 20, 20, new b(56, new a(4, 144, 0), 0)), new bi(20, 96, 96, 22, 22, new b(68, new a(4, 174, 0), 0)), new bi(21, 104, 104, 24, 24, new b(56, new a(6, 136, 0), 0)), new bi(22, 120, 120, 18, 18, new b(68, new a(6, 175, 0), 0)), new bi(23, 132, 132, 20, 20, new b(62, new a(8, 163, 0), 0)), new bi(24, 144, 144, 22, 22, new b(new a(8, 156, 0), new a(2, 155, 0))), new bi(25, 8, 18, 6, 16, new b(7, new a(1, 5, 0), 0)), new bi(26, 8, 32, 6, 14, new b(11, new a(1, 10, 0), 0)), new bi(27, 12, 26, 10, 24, new b(14, new a(1, 16, 0), 0)), new bi(28, 12, 36, 10, 16, new b(18, new a(1, 22, 0), 0)), new bi(29, 16, 36, 14, 16, new b(24, new a(1, 32, 0), 0)), new bi(30, 16, 48, 14, 22, new b(28, new a(1, 49, 0), 0)) };
  private final int b;
  private final int c;
  private final int d;
  private final int e;
  private final int f;
  private final b g;
  private final int h;
  
  private bi(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, b paramb)
  {
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramInt3;
    this.e = paramInt4;
    this.f = paramInt5;
    this.g = paramb;
    paramInt3 = paramb.a();
    paramb = paramb.b();
    paramInt2 = 0;
    paramInt1 = i;
    while (paramInt1 < paramb.length)
    {
      Object localObject = paramb[paramInt1];
      paramInt4 = ((a)localObject).a();
      paramInt2 += (((a)localObject).b() + paramInt3) * paramInt4;
      paramInt1 += 1;
    }
    this.h = paramInt2;
  }
  
  public static bi a(int paramInt1, int paramInt2)
    throws v
  {
    if (((paramInt1 & 0x1) != 0) || ((paramInt2 & 0x1) != 0)) {
      throw v.a();
    }
    int j = a.length;
    int i = 0;
    while (i < j)
    {
      bi localbi = a[i];
      if ((localbi.c == paramInt1) && (localbi.d == paramInt2)) {
        return localbi;
      }
      i += 1;
    }
    throw v.a();
  }
  
  public final int a()
  {
    return this.b;
  }
  
  public final int b()
  {
    return this.c;
  }
  
  public final int c()
  {
    return this.d;
  }
  
  public final int d()
  {
    return this.e;
  }
  
  public final int e()
  {
    return this.f;
  }
  
  public final int f()
  {
    return this.h;
  }
  
  final b g()
  {
    return this.g;
  }
  
  public final String toString()
  {
    return String.valueOf(this.b);
  }
  
  static final class a
  {
    private final int a;
    private final int b;
    
    private a(int paramInt1, int paramInt2)
    {
      this.a = paramInt1;
      this.b = paramInt2;
    }
    
    final int a()
    {
      return this.a;
    }
    
    final int b()
    {
      return this.b;
    }
  }
  
  static final class b
  {
    private final int a;
    private final bi.a[] b;
    
    private b(int paramInt, bi.a parama)
    {
      this.a = paramInt;
      this.b = new bi.a[] { parama };
    }
    
    private b(int paramInt, bi.a parama1, bi.a parama2)
    {
      this.a = 62;
      this.b = new bi.a[] { parama1, parama2 };
    }
    
    final int a()
    {
      return this.a;
    }
    
    final bi.a[] b()
    {
      return this.b;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */