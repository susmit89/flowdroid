package RLSDK;

public final class ah
{
  private static final int[] a = { 0, 104, 240, 408, 608 };
  private static final int[] b = { 0, 128, 288, 480, 704, 960, 1248, 1568, 1920, 2304, 2720, 3168, 3648, 4160, 4704, 5280, 5888, 6528, 7200, 7904, 8640, 9408, 10208, 11040, 11904, 12800, 13728, 14688, 15680, 16704, 17760, 18848, 19968 };
  private static final int[] c = { 0, 17, 40, 51, 76 };
  private static final int[] d = { 0, 21, 48, 60, 88, 120, 156, 196, 240, 230, 272, 316, 364, 416, 470, 528, 588, 652, 720, 790, 864, 940, 1020, 920, 992, 1066, 1144, 1224, 1306, 1392, 1480, 1570, 1664 };
  private static final String[] e = { "CTRL_PS", " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "CTRL_LL", "CTRL_ML", "CTRL_DL", "CTRL_BS" };
  private static final String[] f = { "CTRL_PS", " ", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "CTRL_US", "CTRL_ML", "CTRL_DL", "CTRL_BS" };
  private static final String[] g = { "CTRL_PS", " ", "\001", "\002", "\003", "\004", "\005", "\006", "\007", "\b", "\t", "\n", "\013", "\f", "\r", "\033", "\034", "\035", "\036", "\037", "@", "\\", "^", "_", "`", "|", "~", "", "CTRL_LL", "CTRL_UL", "CTRL_PL", "CTRL_BS" };
  private static final String[] h = { "", "\r", "\r\n", ". ", ", ", ": ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", "}", "CTRL_UL" };
  private static final String[] i = { "CTRL_PS", " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ",", ".", "CTRL_UL", "CTRL_US" };
  private int j;
  private int k;
  private af l;
  private int m;
  
  private static int a(boolean[] paramArrayOfBoolean, int paramInt1, int paramInt2)
  {
    int n = 0;
    int i1 = paramInt1;
    while (i1 < paramInt1 + paramInt2)
    {
      int i2 = n << 1;
      n = i2;
      if (paramArrayOfBoolean[i1] != 0) {
        n = i2 + 1;
      }
      i1 += 1;
    }
    return n;
  }
  
  private boolean[] a(boolean[] paramArrayOfBoolean)
    throws v
  {
    az localaz;
    int i5;
    int n;
    int i1;
    label78:
    int[] arrayOfInt;
    int i2;
    if (this.l.a() <= 2)
    {
      this.k = 6;
      localaz = az.c;
      i5 = this.l.b();
      if (!this.l.c()) {
        break label229;
      }
      n = a[this.l.a()] - this.j * this.k;
      i1 = c[this.l.a()] - i5;
      arrayOfInt = new int[this.j];
      i2 = 0;
    }
    int i3;
    int i4;
    for (;;)
    {
      if (i2 >= this.j) {
        break label278;
      }
      i3 = 1;
      i4 = 1;
      for (;;)
      {
        if (i3 <= this.k)
        {
          if (paramArrayOfBoolean[(this.k * i2 + this.k - i3 + n)] != 0) {
            arrayOfInt[i2] += i4;
          }
          i4 <<= 1;
          i3 += 1;
          continue;
          if (this.l.a() <= 8)
          {
            this.k = 8;
            localaz = az.g;
            break;
          }
          if (this.l.a() <= 22)
          {
            this.k = 10;
            localaz = az.b;
            break;
          }
          this.k = 12;
          localaz = az.a;
          break;
          label229:
          n = b[this.l.a()] - this.j * this.k;
          i1 = d[this.l.a()] - i5;
          break label78;
        }
      }
      i2 += 1;
    }
    for (;;)
    {
      try
      {
        label278:
        new bb(localaz).a(arrayOfInt, i1);
        this.m = 0;
        paramArrayOfBoolean = new boolean[this.k * i5];
        i2 = 0;
        n = 0;
        if (i2 >= i5) {
          break;
        }
        i1 = this.k;
        i3 = 0;
        i4 = 1 << i1 - 1;
        i1 = 0;
        i6 = 0;
        if (i3 >= this.k) {
          break label470;
        }
        if ((arrayOfInt[i2] & i4) == i4)
        {
          i7 = 1;
          if (i1 != this.k - 1) {
            break label431;
          }
          if (i7 != i6) {
            break label397;
          }
          throw v.a();
        }
      }
      catch (bc paramArrayOfBoolean)
      {
        throw v.a();
      }
      int i7 = 0;
      continue;
      label397:
      n += 1;
      this.m += 1;
      int i6 = 0;
      i1 = 0;
      i4 >>>= 1;
      i3 += 1;
      continue;
      label431:
      if (i6 == i7) {
        i1 += 1;
      }
      for (;;)
      {
        paramArrayOfBoolean[(this.k * i2 + i3 - n)] = i7;
        break;
        i6 = i7;
        i1 = 1;
      }
      label470:
      i2 += 1;
    }
    return paramArrayOfBoolean;
  }
  
  public final ap a(af paramaf)
    throws v
  {
    this.l = paramaf;
    paramaf = paramaf.d();
    if (!this.l.c())
    {
      localObject = this.l.d();
      n = (((ak)localObject).a - 1) / 2 / 16 * 2 + 1;
      paramaf = new ak(((ak)localObject).a - n, ((ak)localObject).b - n);
      i1 = 0;
      n = 0;
      while (n < ((ak)localObject).a)
      {
        i2 = i1;
        if ((((ak)localObject).a / 2 - n) % 16 != 0)
        {
          i3 = 0;
          i2 = 0;
          while (i2 < ((ak)localObject).b)
          {
            i4 = i3;
            if ((((ak)localObject).a / 2 - i2) % 16 != 0)
            {
              if (((ak)localObject).a(n, i2)) {
                paramaf.b(i1, i3);
              }
              i4 = i3 + 1;
            }
            i2 += 1;
            i3 = i4;
          }
          i2 = i1 + 1;
        }
        n += 1;
        i1 = i2;
      }
    }
    if (this.l.c())
    {
      if (this.l.a() > a.length) {
        throw v.a();
      }
      localObject = new boolean[a[this.l.a()]];
      this.j = c[this.l.a()];
      i1 = this.l.a();
      n = paramaf.b;
      i2 = 0;
      i3 = 0;
    }
    for (;;)
    {
      if (i1 == 0) {
        break label555;
      }
      i5 = 0;
      i4 = 0;
      for (;;)
      {
        if (i4 < n * 2 - 4)
        {
          localObject[(i2 + i4)] = paramaf.a(i3 + i5, i4 / 2 + i3);
          localObject[(n * 2 + i2 - 4 + i4)] = paramaf.a(i4 / 2 + i3, i3 + n - 1 - i5);
          i5 = (i5 + 1) % 2;
          i4 += 1;
          continue;
          if (this.l.a() > b.length) {
            throw v.a();
          }
          localObject = new boolean[b[this.l.a()]];
          this.j = d[this.l.a()];
          break;
        }
      }
      i5 = 0;
      i4 = n * 2 + 1;
      while (i4 > 5)
      {
        localObject[(n * 4 + i2 - 8 + (n * 2 - i4) + 1)] = paramaf.a(i3 + n - 1 - i5, i4 / 2 + i3 - 1);
        localObject[(n * 6 + i2 - 12 + (n * 2 - i4) + 1)] = paramaf.a(i4 / 2 + i3 - 1, i3 + i5);
        i5 = (i5 + 1) % 2;
        i4 -= 1;
      }
      i3 += 2;
      i2 += n * 8 - 16;
      i1 -= 1;
      n -= 4;
    }
    label555:
    Object localObject = a((boolean[])localObject);
    int i8 = this.k * this.l.b() - this.m;
    if (i8 > localObject.length) {
      throw v.a();
    }
    int i5 = 0;
    StringBuffer localStringBuffer = new StringBuffer(20);
    int i2 = 0;
    int i1 = 0;
    int i4 = 0;
    int i3 = 0;
    int n = 0;
    for (;;)
    {
      if (i2 == 0)
      {
        if (i1 != 0)
        {
          i4 = i5;
          i5 = 1;
          switch (n)
          {
          default: 
            label637:
            i6 = 5;
            if (n == 3) {
              i6 = 4;
            }
            if (i8 - i3 < i6)
            {
              i7 = 1;
              i2 = i3;
              i6 = i1;
              i1 = i7;
              i3 = n;
              n = i2;
              i2 = i6;
            }
            break;
          }
        }
        for (;;)
        {
          if (i5 == 0) {
            break label1111;
          }
          i6 = 0;
          i2 = i1;
          i1 = i4;
          i7 = 0;
          i5 = i4;
          i3 = n;
          n = i1;
          i1 = i6;
          i4 = i7;
          break;
          i5 = i4;
          i4 = n;
          break label637;
          if (i8 - i3 < 8)
          {
            i7 = 1;
            i6 = n;
            n = i3;
            i2 = i1;
            i3 = i6;
            i1 = i7;
          }
          else
          {
            localStringBuffer.append((char)a((boolean[])localObject, i3, 8));
            i6 = i2;
            i2 = i1;
            i1 = n;
            n = i3 + 8;
            i3 = i1;
            i1 = i6;
            continue;
            i7 = a((boolean[])localObject, i3, i6);
            i6 += i3;
            switch (n)
            {
            default: 
              paramaf = "";
              if (paramaf.startsWith("CTRL_"))
              {
                i3 = paramaf.charAt(5);
                n = 0;
                switch (i3)
                {
                }
              }
              break;
            case 0: 
            case 1: 
            case 2: 
            case 4: 
            case 3: 
              for (;;)
              {
                label875:
                i3 = n;
                if (paramaf.charAt(6) != 'S') {
                  break label1079;
                }
                i7 = 1;
                i3 = n;
                n = i6;
                i1 = i2;
                i2 = i7;
                break;
                paramaf = e[i7];
                break label875;
                paramaf = f[i7];
                break label875;
                paramaf = g[i7];
                break label875;
                paramaf = h[i7];
                break label875;
                paramaf = i[i7];
                break label875;
                n = 0;
                continue;
                n = 1;
                continue;
                n = 4;
                continue;
                n = 2;
                continue;
                n = 3;
                continue;
                n = 5;
              }
            }
            localStringBuffer.append(paramaf);
            i3 = n;
            label1079:
            n = i6;
            i6 = i2;
            i2 = i1;
            i1 = i6;
          }
        }
      }
      return new ap(null, localStringBuffer.toString(), null, null);
      label1111:
      int i6 = i1;
      int i7 = i5;
      i5 = i4;
      i1 = i2;
      i2 = i3;
      i3 = n;
      n = i2;
      i4 = i7;
      i2 = i6;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */