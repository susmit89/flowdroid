package RLSDK;

import java.util.Hashtable;

public final class br
  extends bu
{
  static final int[][] a;
  private static final int[] b = { 6, 8, 10, 12, 14, 16, 20, 24, 44 };
  private static final int[] d = { 1, 1, 1, 1 };
  private static final int[] e = { 1, 1, 3 };
  private int c = -1;
  
  static
  {
    int[] arrayOfInt1 = { 1, 1, 3, 3, 1 };
    int[] arrayOfInt2 = { 3, 1, 1, 1, 3 };
    int[] arrayOfInt3 = { 3, 3, 1, 1, 1 };
    int[] arrayOfInt4 = { 1, 1, 3, 1, 3 };
    int[] arrayOfInt5 = { 3, 1, 3, 1, 1 };
    int[] arrayOfInt6 = { 1, 1, 1, 3, 3 };
    a = new int[][] { arrayOfInt1, arrayOfInt2, { 1, 3, 1, 1, 3 }, arrayOfInt3, arrayOfInt4, arrayOfInt5, { 1, 3, 3, 1, 1 }, arrayOfInt6, { 3, 1, 1, 3, 1 }, { 1, 3, 1, 3, 1 } };
  }
  
  private static int a(aj paramaj)
    throws y
  {
    int j = paramaj.b;
    int i = 0;
    while ((i < j) && (!paramaj.a(i))) {
      i += 1;
    }
    if (i == j) {
      throw y.a();
    }
    return i;
  }
  
  private static int a(int[] paramArrayOfInt)
    throws y
  {
    int j = 107;
    int k = -1;
    int n = a.length;
    int i = 0;
    if (i < n)
    {
      int m = a(paramArrayOfInt, a[i], 204);
      if (m >= j) {
        break label61;
      }
      k = i;
      j = m;
    }
    label61:
    for (;;)
    {
      i += 1;
      break;
      if (k >= 0) {
        return k;
      }
      throw y.a();
    }
  }
  
  private void a(aj paramaj, int paramInt)
    throws y
  {
    int i = this.c * 10;
    paramInt -= 1;
    while ((i > 0) && (paramInt >= 0) && (!paramaj.a(paramInt)))
    {
      i -= 1;
      paramInt -= 1;
    }
    if (i != 0) {
      throw y.a();
    }
  }
  
  private static void a(aj paramaj, int paramInt1, int paramInt2, StringBuffer paramStringBuffer)
    throws y
  {
    int[] arrayOfInt1 = new int[10];
    int[] arrayOfInt2 = new int[5];
    int[] arrayOfInt3 = new int[5];
    while (paramInt1 < paramInt2)
    {
      a(paramaj, paramInt1, arrayOfInt1);
      int i = 0;
      while (i < 5)
      {
        int j = i << 1;
        arrayOfInt2[i] = arrayOfInt1[j];
        arrayOfInt3[i] = arrayOfInt1[(j + 1)];
        i += 1;
      }
      paramStringBuffer.append((char)(a(arrayOfInt2) + 48));
      paramStringBuffer.append((char)(a(arrayOfInt3) + 48));
      i = 0;
      while (i < arrayOfInt1.length)
      {
        paramInt1 += arrayOfInt1[i];
        i += 1;
      }
    }
  }
  
  private int[] b(aj paramaj)
    throws y
  {
    paramaj.a();
    try
    {
      int[] arrayOfInt = c(paramaj, a(paramaj), e);
      a(paramaj, arrayOfInt[0]);
      int i = arrayOfInt[0];
      arrayOfInt[0] = (paramaj.b - arrayOfInt[1]);
      arrayOfInt[1] = (paramaj.b - i);
      return arrayOfInt;
    }
    finally
    {
      paramaj.a();
    }
  }
  
  private static int[] c(aj paramaj, int paramInt, int[] paramArrayOfInt)
    throws y
  {
    int i1 = paramArrayOfInt.length;
    int[] arrayOfInt = new int[i1];
    int i2 = paramaj.b;
    int i = paramInt;
    int m = 0;
    int k = 0;
    int j = paramInt;
    paramInt = i;
    if (j < i2)
    {
      if ((paramaj.a(j) ^ k))
      {
        arrayOfInt[m] += 1;
        i = k;
        k = paramInt;
      }
      for (;;)
      {
        j += 1;
        paramInt = k;
        k = i;
        break;
        if (m == i1 - 1)
        {
          if (a(arrayOfInt, paramArrayOfInt, 204) < 107) {
            return new int[] { paramInt, j };
          }
          i = paramInt + (arrayOfInt[0] + arrayOfInt[1]);
          paramInt = 2;
          while (paramInt < i1)
          {
            arrayOfInt[(paramInt - 2)] = arrayOfInt[paramInt];
            paramInt += 1;
          }
          arrayOfInt[(i1 - 2)] = 0;
          arrayOfInt[(i1 - 1)] = 0;
        }
        for (paramInt = m - 1;; paramInt = m)
        {
          arrayOfInt[paramInt] = 1;
          if (k != 0) {
            break label214;
          }
          n = 1;
          k = i;
          m = paramInt;
          i = n;
          break;
          m += 1;
          i = paramInt;
        }
        label214:
        int n = 0;
        k = i;
        m = paramInt;
        i = n;
      }
    }
    throw y.a();
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws v, y
  {
    int[] arrayOfInt = c(paramaj, a(paramaj), d);
    this.c = (arrayOfInt[1] - arrayOfInt[0] >> 2);
    a(paramaj, arrayOfInt[0]);
    Object localObject1 = b(paramaj);
    Object localObject2 = new StringBuffer(20);
    a(paramaj, arrayOfInt[1], localObject1[0], (StringBuffer)localObject2);
    localObject2 = ((StringBuffer)localObject2).toString();
    if (paramHashtable != null) {}
    for (paramaj = (int[])paramHashtable.get(u.f);; paramaj = null)
    {
      paramHashtable = paramaj;
      if (paramaj == null) {
        paramHashtable = b;
      }
      int j = ((String)localObject2).length();
      int i = 0;
      if (i < paramHashtable.length) {
        if (j != paramHashtable[i]) {}
      }
      for (i = 1;; i = 0)
      {
        if (i == 0)
        {
          throw v.a();
          i += 1;
          break;
        }
        paramaj = new ad(arrayOfInt[1], paramInt);
        paramHashtable = new ad(localObject1[0], paramInt);
        localObject1 = q.i;
        return new ab((String)localObject2, null, new ad[] { paramaj, paramHashtable }, (q)localObject1);
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/br.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */