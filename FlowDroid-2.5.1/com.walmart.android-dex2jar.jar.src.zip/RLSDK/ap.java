package RLSDK;

import java.util.Vector;

public final class ap
{
  private final byte[] a;
  private final String b;
  private final Vector c;
  private final String d;
  
  public ap(byte[] paramArrayOfByte, String paramString1, Vector paramVector, String paramString2)
  {
    if ((paramArrayOfByte == null) && (paramString1 == null)) {
      throw new IllegalArgumentException();
    }
    this.a = paramArrayOfByte;
    this.b = paramString1;
    this.c = paramVector;
    this.d = paramString2;
  }
  
  public final byte[] a()
  {
    return this.a;
  }
  
  public final String b()
  {
    return this.b;
  }
  
  public final Vector c()
  {
    return this.c;
  }
  
  public final String d()
  {
    return this.d;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */