package RLSDK;

final class ch
  extends cm
{
  ch(aj paramaj)
  {
    super(paramaj);
  }
  
  protected final int a(int paramInt)
  {
    return paramInt;
  }
  
  protected final void a(StringBuffer paramStringBuffer, int paramInt)
  {
    paramStringBuffer.append("(3103)");
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */