package RLSDK;

final class cn
  extends co
{
  cn(aj paramaj)
  {
    super(paramaj);
  }
  
  public final String a()
    throws y
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("(01)");
    int i = localStringBuffer.length();
    localStringBuffer.append(this.b.a(4, 4));
    a(localStringBuffer, 8, i);
    return this.b.a(localStringBuffer, 48);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */