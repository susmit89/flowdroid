package RLSDK;

final class cu
  extends cx
{
  private final char b;
  
  cu(int paramInt, char paramChar)
  {
    super(paramInt);
    this.b = paramChar;
  }
  
  final char a()
  {
    return this.b;
  }
  
  final boolean b()
  {
    return this.b == '$';
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */