package RLSDK;

public class at
  extends r
{
  private byte[] a = null;
  private int[] b = null;
  
  public at(w paramw)
  {
    super(paramw);
  }
  
  private static int a(int[] paramArrayOfInt)
    throws y
  {
    int i2 = paramArrayOfInt.length;
    int j = 0;
    int m = 0;
    int i = 0;
    int i1;
    for (int n = 0; j < i2; n = i1)
    {
      k = m;
      if (paramArrayOfInt[j] > m)
      {
        k = paramArrayOfInt[j];
        i = j;
      }
      i1 = n;
      if (paramArrayOfInt[j] > n) {
        i1 = paramArrayOfInt[j];
      }
      j += 1;
      m = k;
    }
    int k = 0;
    j = 0;
    m = 0;
    if (k < i2)
    {
      i1 = k - i;
      i1 *= paramArrayOfInt[k] * i1;
      if (i1 <= m) {
        break label247;
      }
      m = k;
    }
    for (j = i1;; j = i1)
    {
      k += 1;
      i1 = j;
      j = m;
      m = i1;
      break;
      if (i > j)
      {
        i1 = j;
        m = i;
      }
      for (;;)
      {
        if (m - i1 <= i2 >> 4) {
          throw y.a();
        }
        j = m - 1;
        k = -1;
        i = m - 1;
        if (i > i1)
        {
          i2 = i - i1;
          i2 = i2 * i2 * (m - i) * (n - paramArrayOfInt[i]);
          if (i2 <= k) {
            break label227;
          }
          k = i;
          j = i2;
        }
        for (;;)
        {
          i -= 1;
          i2 = k;
          k = j;
          j = i2;
          break;
          return j << 3;
          label227:
          i2 = j;
          j = k;
          k = i2;
        }
        m = j;
        i1 = i;
      }
      label247:
      i1 = m;
      m = j;
    }
  }
  
  private void a(int paramInt)
  {
    if ((this.a == null) || (this.a.length < paramInt)) {
      this.a = new byte[paramInt];
    }
    if (this.b == null) {
      this.b = new int[32];
    }
    for (;;)
    {
      return;
      paramInt = 0;
      while (paramInt < 32)
      {
        this.b[paramInt] = 0;
        paramInt += 1;
      }
    }
  }
  
  public final aj a(int paramInt, aj paramaj)
    throws y
  {
    int k = 1;
    Object localObject = a();
    int m = ((w)localObject).b();
    aj localaj;
    if ((paramaj == null) || (paramaj.b < m))
    {
      localaj = new aj(m);
      a(m);
      paramaj = ((w)localObject).a(paramInt, this.a);
      localObject = this.b;
      paramInt = 0;
    }
    while (paramInt < m)
    {
      i = (paramaj[paramInt] & 0xFF) >> 3;
      localObject[i] += 1;
      paramInt += 1;
      continue;
      j = paramaj.a.length;
      i = 0;
      for (;;)
      {
        localaj = paramaj;
        if (i >= j) {
          break;
        }
        paramaj.a[i] = 0;
        i += 1;
      }
    }
    int n = a((int[])localObject);
    int j = paramaj[0] & 0xFF;
    paramInt = paramaj[1] & 0xFF;
    int i = k;
    while (i < m - 1)
    {
      k = paramaj[(i + 1)] & 0xFF;
      if ((paramInt << 2) - j - k >> 1 < n) {
        localaj.b(i);
      }
      i += 1;
      j = paramInt;
      paramInt = k;
    }
    return localaj;
  }
  
  public ak b()
    throws y
  {
    Object localObject = a();
    int k = ((w)localObject).b();
    int m = ((w)localObject).c();
    ak localak = new ak(k, m);
    a(k);
    int[] arrayOfInt = this.b;
    int i = 1;
    int j;
    while (i < 5)
    {
      byte[] arrayOfByte = ((w)localObject).a(m * i / 5, this.a);
      n = (k << 2) / 5;
      j = k / 5;
      while (j < n)
      {
        int i1 = (arrayOfByte[j] & 0xFF) >> 3;
        arrayOfInt[i1] += 1;
        j += 1;
      }
      i += 1;
    }
    int n = a(arrayOfInt);
    localObject = ((w)localObject).a();
    i = 0;
    while (i < m)
    {
      j = 0;
      while (j < k)
      {
        if ((localObject[(i * k + j)] & 0xFF) < n) {
          localak.b(j, i);
        }
        j += 1;
      }
      i += 1;
    }
    return localak;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */