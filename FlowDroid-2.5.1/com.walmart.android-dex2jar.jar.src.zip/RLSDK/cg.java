package RLSDK;

import java.util.Hashtable;
import java.util.Vector;

public final class cg
  extends bz
{
  private static final int[] g = { 7, 5, 4, 3, 1 };
  private static final int[] h = { 4, 20, 52, 104, 204 };
  private static final int[] i = { 0, 348, 1388, 2948, 3988 };
  private static final int[][] j = { { 1, 8, 4, 1 }, { 3, 6, 4, 1 }, { 3, 4, 6, 1 }, { 3, 2, 8, 1 }, { 2, 6, 5, 1 }, { 2, 2, 9, 1 } };
  private static final int[][] k;
  private static final int[][] l;
  private static final int m = localObject[(localObject.length - 1)].length;
  private final Vector n = new Vector(11);
  private final int[] o = new int[2];
  private final int[] p = new int[m];
  
  static
  {
    Object localObject = { 20, 60, 180, 118, 143, 7, 21, 63 };
    int[] arrayOfInt1 = { 189, 145, 13, 39, 117, 140, 209, 205 };
    int[] arrayOfInt2 = { 193, 157, 49, 147, 19, 57, 171, 91 };
    int[] arrayOfInt3 = { 62, 186, 136, 197, 169, 85, 44, 132 };
    int[] arrayOfInt4 = { 185, 133, 188, 142, 4, 12, 36, 108 };
    int[] arrayOfInt5 = { 113, 128, 173, 97, 80, 29, 87, 50 };
    int[] arrayOfInt6 = { 46, 138, 203, 187, 139, 206, 196, 166 };
    int[] arrayOfInt7 = { 76, 17, 51, 153, 37, 111, 122, 155 };
    int[] arrayOfInt8 = { 43, 129, 176, 106, 107, 110, 119, 146 };
    int[] arrayOfInt9 = { 16, 48, 144, 10, 30, 90, 59, 177 };
    int[] arrayOfInt10 = { 109, 116, 137, 200, 178, 112, 125, 164 };
    int[] arrayOfInt11 = { 70, 210, 208, 202, 184, 130, 179, 115 };
    int[] arrayOfInt12 = { 148, 22, 66, 198, 172, 94, 71, 2 };
    int[] arrayOfInt13 = { 6, 18, 54, 162, 64, 192, 154, 40 };
    int[] arrayOfInt14 = { 120, 149, 25, 75, 14, 42, 126, 167 };
    int[] arrayOfInt15 = { 79, 26, 78, 23, 69, 207, 199, 175 };
    int[] arrayOfInt16 = { 103, 98, 83, 38, 114, 131, 182, 124 };
    int[] arrayOfInt17 = { 161, 61, 183, 127, 170, 88, 53, 159 };
    int[] arrayOfInt18 = { 55, 165, 73, 8, 24, 72, 5, 15 };
    k = new int[][] { { 1, 3, 9, 27, 81, 32, 96, 77 }, localObject, arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, { 150, 28, 84, 41, 123, 158, 52, 156 }, arrayOfInt6, arrayOfInt7, arrayOfInt8, arrayOfInt9, arrayOfInt10, arrayOfInt11, { 134, 191, 151, 31, 93, 68, 204, 190 }, arrayOfInt12, arrayOfInt13, arrayOfInt14, arrayOfInt15, arrayOfInt16, arrayOfInt17, arrayOfInt18, { 45, 135, 194, 160, 58, 174, 100, 89 } };
    localObject = new int[10][];
    localObject[0] = { 0, 0 };
    localObject[1] = { 0, 1, 1 };
    localObject[2] = { 0, 2, 1, 3 };
    localObject[3] = { 0, 4, 1, 3, 2 };
    localObject[4] = { 0, 4, 1, 3, 3, 5 };
    localObject[5] = { 0, 4, 1, 3, 4, 5, 5 };
    localObject[6] = { 0, 0, 1, 1, 2, 2, 3, 3 };
    localObject[7] = { 0, 0, 1, 1, 2, 2, 3, 4, 4 };
    localObject[8] = { 0, 0, 1, 1, 2, 2, 3, 4, 5, 5 };
    localObject[9] = { 0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5 };
    l = (int[][])localObject;
  }
  
  private ca a(aj paramaj, cb paramcb, boolean paramBoolean1, boolean paramBoolean2)
    throws y
  {
    int[] arrayOfInt1 = this.b;
    arrayOfInt1[0] = 0;
    arrayOfInt1[1] = 0;
    arrayOfInt1[2] = 0;
    arrayOfInt1[3] = 0;
    arrayOfInt1[4] = 0;
    arrayOfInt1[5] = 0;
    arrayOfInt1[6] = 0;
    arrayOfInt1[7] = 0;
    int[] arrayOfInt2;
    float[] arrayOfFloat2;
    label102:
    float f2;
    int i1;
    if (paramBoolean2)
    {
      b(paramaj, paramcb.b()[0], arrayOfInt1);
      float f1 = a(arrayOfInt1) / 17.0F;
      paramaj = this.e;
      arrayOfInt2 = this.f;
      float[] arrayOfFloat1 = this.c;
      arrayOfFloat2 = this.d;
      i2 = 0;
      if (i2 >= arrayOfInt1.length) {
        break label287;
      }
      f2 = 1.0F * arrayOfInt1[i2] / f1;
      i3 = (int)(0.5F + f2);
      if (i3 > 0) {
        break label248;
      }
      i1 = 1;
      label139:
      i3 = i2 >> 1;
      if ((i2 & 0x1) != 0) {
        break label266;
      }
      paramaj[i3] = i1;
      arrayOfFloat1[i3] = (f2 - i1);
    }
    for (;;)
    {
      i2 += 1;
      break label102;
      a(paramaj, paramcb.b()[1] + 1, arrayOfInt1);
      i2 = 0;
      i1 = arrayOfInt1.length - 1;
      while (i2 < i1)
      {
        i3 = arrayOfInt1[i2];
        arrayOfInt1[i2] = arrayOfInt1[i1];
        arrayOfInt1[i1] = i3;
        i2 += 1;
        i1 -= 1;
      }
      break;
      label248:
      i1 = i3;
      if (i3 <= 8) {
        break label139;
      }
      i1 = 8;
      break label139;
      label266:
      arrayOfInt2[i3] = i1;
      arrayOfFloat2[i3] = (f2 - i1);
    }
    label287:
    int i8 = a(this.e);
    int i9 = a(this.f);
    int i10 = i8 + i9 - 17;
    label336:
    label352:
    int i7;
    if ((i8 & 0x1) == 1)
    {
      i6 = 1;
      if ((i9 & 0x1) != 0) {
        break label394;
      }
      i5 = 1;
      i2 = 0;
      i3 = 0;
      if (i8 <= 13) {
        break label400;
      }
      i1 = 1;
      i4 = 0;
      i7 = 0;
      if (i9 <= 13) {
        break label420;
      }
      i3 = 1;
    }
    for (;;)
    {
      if (i10 == 1) {
        if (i6 != 0)
        {
          if (i5 != 0)
          {
            throw y.a();
            i6 = 0;
            break;
            label394:
            i5 = 0;
            break label336;
            label400:
            i1 = i3;
            if (i8 >= 4) {
              break label352;
            }
            i2 = 1;
            i1 = i3;
            break label352;
            label420:
            i3 = i7;
            if (i9 >= 4) {
              continue;
            }
            i4 = 1;
            i3 = i7;
            continue;
          }
          i1 = 1;
        }
      }
    }
    while (i2 != 0) {
      if (i1 != 0)
      {
        throw y.a();
        if (i5 == 0) {
          throw y.a();
        }
        i3 = 1;
        continue;
        if (i10 == -1)
        {
          if (i6 != 0)
          {
            if (i5 != 0) {
              throw y.a();
            }
            i2 = 1;
          }
          else
          {
            if (i5 == 0) {
              throw y.a();
            }
            i4 = 1;
          }
        }
        else if (i10 == 0)
        {
          if (i6 != 0)
          {
            if (i5 == 0) {
              throw y.a();
            }
            if (i8 < i9)
            {
              i2 = 1;
              i3 = 1;
            }
            else
            {
              i1 = 1;
              i4 = 1;
            }
          }
          else if (i5 != 0)
          {
            throw y.a();
          }
        }
        else {
          throw y.a();
        }
      }
      else
      {
        a(this.e, this.c);
      }
    }
    if (i1 != 0) {
      b(this.e, this.c);
    }
    if (i4 != 0)
    {
      if (i3 != 0) {
        throw y.a();
      }
      a(this.f, this.c);
    }
    if (i3 != 0) {
      b(this.f, this.d);
    }
    int i3 = paramcb.a();
    if (paramBoolean1)
    {
      i1 = 0;
      if (!paramBoolean2) {
        break label761;
      }
    }
    label761:
    for (int i2 = 0;; i2 = 1)
    {
      i6 = i2 + (i3 * 4 + i1) - 1;
      i1 = paramaj.length;
      i2 = 0;
      i3 = i1 - 1;
      for (i1 = 0; i3 >= 0; i1 = i4)
      {
        i4 = i1;
        if (a(paramcb, paramBoolean1, paramBoolean2)) {
          i4 = i1 + k[i6][(i3 * 2)] * paramaj[i3];
        }
        i1 = paramaj[i3];
        i3 -= 1;
        i2 = i1 + i2;
      }
      i1 = 2;
      break;
    }
    i3 = 0;
    int i4 = arrayOfInt2.length - 1;
    while (i4 >= 0)
    {
      i5 = i3;
      if (a(paramcb, paramBoolean1, paramBoolean2)) {
        i5 = i3 + k[i6][(i4 * 2 + 1)] * arrayOfInt2[i4];
      }
      i4 -= 1;
      i3 = i5;
    }
    if (((i2 & 0x1) != 0) || (i2 > 13) || (i2 < 4)) {
      throw y.a();
    }
    i2 = (13 - i2) / 2;
    int i5 = g[i2];
    i4 = ce.a(paramaj, i5, true);
    i5 = ce.a(arrayOfInt2, 9 - i5, false);
    int i6 = h[i2];
    return new ca(i[i2] + (i4 * i6 + i5), i1 + i3);
  }
  
  private cb a(aj paramaj, int paramInt, boolean paramBoolean)
  {
    int i1;
    int i3;
    int i2;
    if (paramBoolean)
    {
      i1 = this.o[0] - 1;
      while ((i1 >= 0) && (!paramaj.a(i1))) {
        i1 -= 1;
      }
      i1 += 1;
      i3 = this.o[0] - i1;
      i2 = this.o[1];
    }
    for (;;)
    {
      paramaj = this.a;
      int i4 = paramaj.length - 1;
      while (i4 > 0)
      {
        paramaj[i4] = paramaj[(i4 - 1)];
        i4 -= 1;
      }
      i4 = this.o[0];
      i1 = this.o[1] + 1;
      while ((paramaj.a(i1)) && (i1 < paramaj.b)) {
        i1 += 1;
      }
      i3 = this.o[1];
      i2 = i1;
      i3 = i1 - i3;
      i1 = i4;
    }
    paramaj[0] = i3;
    try
    {
      i3 = a(paramaj, j);
      return new cb(i3, new int[] { i1, i2 }, i1, i2, paramInt);
    }
    catch (y paramaj) {}
    return null;
  }
  
  private cf a(aj paramaj, Vector paramVector, int paramInt)
    throws y
  {
    boolean bool1;
    int i4;
    int i1;
    if (paramVector.size() % 2 == 0)
    {
      bool1 = true;
      i4 = 1;
      i1 = -1;
    }
    for (;;)
    {
      Object localObject = this.a;
      localObject[0] = 0;
      localObject[1] = 0;
      localObject[2] = 0;
      localObject[3] = 0;
      int i10 = paramaj.b;
      label59:
      int i6;
      if (i1 >= 0)
      {
        i2 = i1;
        if (paramVector.size() % 2 == 0) {
          break label154;
        }
        i6 = 1;
        label71:
        i3 = 0;
        label74:
        i5 = i3;
        if (i2 >= i10) {
          break label166;
        }
        if (paramaj.a(i2)) {
          break label160;
        }
      }
      label154:
      label160:
      for (int i3 = 1;; i3 = 0)
      {
        i5 = i3;
        if (i3 == 0) {
          break label166;
        }
        i2 += 1;
        break label74;
        bool1 = false;
        break;
        if (paramVector.isEmpty())
        {
          i2 = 0;
          break label59;
        }
        i2 = ((cf)paramVector.lastElement()).d().b()[1];
        break label59;
        i6 = 0;
        break label71;
      }
      label166:
      i3 = i2;
      int i8 = 0;
      int i7 = i5;
      int i5 = i3;
      boolean bool2;
      if (i5 < i10)
      {
        if ((paramaj.a(i5) ^ i7))
        {
          localObject[i8] += 1;
          i3 = i7;
          i7 = i2;
        }
        for (;;)
        {
          i5 += 1;
          i2 = i7;
          i7 = i3;
          break;
          if (i8 == 3)
          {
            if (i6 != 0) {
              c((int[])localObject);
            }
            if (b((int[])localObject))
            {
              this.o[0] = i2;
              this.o[1] = i5;
              localObject = a(paramaj, paramInt, bool1);
              if (localObject != null) {
                break label535;
              }
              i1 = this.o[0];
              bool2 = paramaj.a(i1);
              while ((i1 < paramaj.b) && (paramaj.a(i1) == bool2)) {
                i1 += 1;
              }
            }
            if (i6 != 0) {
              c((int[])localObject);
            }
            i3 = i2 + (localObject[0] + localObject[1]);
            localObject[0] = localObject[2];
            localObject[1] = localObject[3];
            localObject[2] = 0;
            localObject[3] = 0;
          }
          for (i2 = i8 - 1;; i2 = i8)
          {
            localObject[i2] = 1;
            if (i7 != 0) {
              break label439;
            }
            i9 = 1;
            i7 = i3;
            i8 = i2;
            i3 = i9;
            break;
            i8 += 1;
            i3 = i2;
          }
          label439:
          int i9 = 0;
          i7 = i3;
          i8 = i2;
          i3 = i9;
        }
      }
      throw y.a();
      if (!bool2) {
        bool2 = true;
      }
      while ((i1 < paramaj.b) && (paramaj.a(i1) == bool2))
      {
        i1 += 1;
        continue;
        bool2 = false;
      }
      int i2 = i4;
      while (i2 == 0)
      {
        i4 = paramVector.size() + 1;
        if (i4 > this.p.length)
        {
          throw y.a();
          label535:
          i2 = 0;
        }
        else
        {
          paramInt = 0;
          while (paramInt < paramVector.size())
          {
            this.p[paramInt] = ((cf)paramVector.elementAt(paramInt)).d().a();
            paramInt += 1;
          }
          this.p[(i4 - 1)] = ((cb)localObject).a();
          paramInt = 0;
          for (;;)
          {
            if (paramInt < l.length)
            {
              paramVector = l[paramInt];
              if (paramVector.length >= i4)
              {
                i3 = 1;
                i1 = 0;
                label621:
                i2 = i3;
                if (i1 < i4)
                {
                  if (this.p[i1] != paramVector[i1]) {
                    i2 = 0;
                  }
                }
                else
                {
                  if (i2 == 0) {
                    break label715;
                  }
                  if (i4 != paramVector.length) {
                    break label709;
                  }
                  bool2 = true;
                  label664:
                  paramVector = a(paramaj, (cb)localObject, bool1, true);
                }
              }
            }
            try
            {
              paramaj = a(paramaj, (cb)localObject, bool1, false);
              return new cf(paramVector, paramaj, (cb)localObject, bool2);
              i1 += 1;
              break label621;
              label709:
              bool2 = false;
              break label664;
              label715:
              paramInt += 1;
              continue;
              throw y.a();
            }
            catch (y paramaj)
            {
              while (bool2) {
                paramaj = null;
              }
              throw paramaj;
            }
          }
        }
      }
      i4 = i2;
    }
  }
  
  private static boolean a(cb paramcb, boolean paramBoolean1, boolean paramBoolean2)
  {
    return (paramcb.a() != 0) || (!paramBoolean1) || (!paramBoolean2);
  }
  
  private static void c(int[] paramArrayOfInt)
  {
    int i2 = paramArrayOfInt.length;
    int i1 = 0;
    while (i1 < i2 / 2)
    {
      int i3 = paramArrayOfInt[i1];
      paramArrayOfInt[i1] = paramArrayOfInt[(i2 - i1 - 1)];
      paramArrayOfInt[(i2 - i1 - 1)] = i3;
      i1 += 1;
    }
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y
  {
    a();
    do
    {
      paramHashtable = a(paramaj, this.n, paramInt);
      this.n.addElement(paramHashtable);
    } while (!paramHashtable.a());
    cf localcf = (cf)this.n.elementAt(0);
    Object localObject1 = localcf.b();
    int i1 = localcf.c().b();
    int i3 = 1;
    int i2 = 2;
    int i4;
    while (i3 < this.n.size())
    {
      localcf = (cf)this.n.elementAt(i3);
      i4 = i1 + localcf.b().b();
      int i5 = i2 + 1;
      i2 = i5;
      i1 = i4;
      if (localcf.c() != null)
      {
        i1 = i4 + localcf.c().b();
        i2 = i5 + 1;
      }
      i3 += 1;
    }
    if (i1 % 211 + (i2 - 4) * 211 == ((ca)localObject1).a())
    {
      i1 = 1;
      label181:
      if (i1 == 0) {
        break label295;
      }
      paramaj = this.n;
      paramHashtable = this.n;
      paramInt = (paramHashtable.size() << 1) - 1;
      if (((cf)paramHashtable.lastElement()).c() != null) {
        break label551;
      }
      paramInt -= 1;
    }
    label295:
    label551:
    for (;;)
    {
      paramaj = new aj(paramInt * 12);
      i2 = ((cf)paramHashtable.elementAt(0)).c().a();
      paramInt = 0;
      i1 = 11;
      for (;;)
      {
        if (i1 >= 0)
        {
          if ((1 << i1 & i2) != 0) {
            paramaj.b(paramInt);
          }
          paramInt += 1;
          i1 -= 1;
          continue;
          i1 = 0;
          break label181;
          if (!paramHashtable.e()) {
            break;
          }
          throw y.a();
        }
      }
      i2 = 1;
      while (i2 < paramHashtable.size())
      {
        localObject1 = (cf)paramHashtable.elementAt(i2);
        i3 = ((cf)localObject1).b().a();
        i1 = 11;
        while (i1 >= 0)
        {
          if ((1 << i1 & i3) != 0) {
            paramaj.b(paramInt);
          }
          paramInt += 1;
          i1 -= 1;
        }
        if (((cf)localObject1).c() != null)
        {
          i4 = ((cf)localObject1).c().a();
          i3 = 11;
          for (;;)
          {
            i1 = paramInt;
            if (i3 < 0) {
              break;
            }
            if ((1 << i3 & i4) != 0) {
              paramaj.b(paramInt);
            }
            paramInt += 1;
            i3 -= 1;
          }
        }
        i1 = paramInt;
        i2 += 1;
        paramInt = i1;
      }
      paramaj = cq.a(paramaj).a();
      localObject1 = ((cf)paramHashtable.elementAt(0)).d().c();
      Object localObject2 = ((cf)paramHashtable.lastElement()).d().c();
      paramHashtable = localObject1[0];
      localObject1 = localObject1[1];
      localcf = localObject2[0];
      localObject2 = localObject2[1];
      q localq = q.m;
      return new ab(paramaj, null, new ad[] { paramHashtable, localObject1, localcf, localObject2 }, localq);
    }
  }
  
  public final void a()
  {
    this.n.setSize(0);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */