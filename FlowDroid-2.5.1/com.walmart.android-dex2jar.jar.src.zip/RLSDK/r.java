package RLSDK;

public abstract class r
{
  private final w a;
  
  protected r(w paramw)
  {
    if (paramw == null) {
      throw new IllegalArgumentException("Source must be non-null.");
    }
    this.a = paramw;
  }
  
  public abstract aj a(int paramInt, aj paramaj)
    throws y;
  
  public final w a()
  {
    return this.a;
  }
  
  public abstract ak b()
    throws y;
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */