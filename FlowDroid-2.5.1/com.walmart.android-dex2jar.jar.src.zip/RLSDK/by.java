package RLSDK;

public final class by
  extends bx
{
  private static final int[] a = { 1, 1, 1, 1, 1, 1 };
  private static final int[][] f;
  private final int[] g = new int[4];
  
  static
  {
    int[] arrayOfInt = { 7, 11, 13, 14, 19, 25, 28, 21, 22, 26 };
    f = new int[][] { { 56, 52, 50, 49, 44, 38, 35, 42, 41, 37 }, arrayOfInt };
  }
  
  protected final int a(aj paramaj, int[] paramArrayOfInt, StringBuffer paramStringBuffer)
    throws y
  {
    int[] arrayOfInt = this.g;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    arrayOfInt[2] = 0;
    arrayOfInt[3] = 0;
    int n = paramaj.b;
    int j = paramArrayOfInt[1];
    int k = 0;
    int i = 0;
    int m;
    if ((k < 6) && (j < n))
    {
      int i1 = a(paramaj, arrayOfInt, j, e);
      paramStringBuffer.append((char)(i1 % 10 + 48));
      m = 0;
      while (m < arrayOfInt.length)
      {
        j += arrayOfInt[m];
        m += 1;
      }
      if (i1 < 10) {
        break label222;
      }
      i = 1 << 5 - k | i;
    }
    label222:
    for (;;)
    {
      k += 1;
      break;
      k = 0;
      while (k <= 1)
      {
        m = 0;
        while (m < 10)
        {
          if (i == f[k][m])
          {
            paramStringBuffer.insert(0, (char)(k + 48));
            paramStringBuffer.append((char)(m + 48));
            return j;
          }
          m += 1;
        }
        k += 1;
      }
      throw y.a();
    }
  }
  
  protected final boolean a(String paramString)
    throws v, t
  {
    char[] arrayOfChar = new char[6];
    paramString.getChars(1, 7, arrayOfChar, 0);
    StringBuffer localStringBuffer = new StringBuffer(12);
    localStringBuffer.append(paramString.charAt(0));
    char c = arrayOfChar[5];
    switch (c)
    {
    default: 
      localStringBuffer.append(arrayOfChar, 0, 5);
      localStringBuffer.append("0000");
      localStringBuffer.append(c);
    }
    for (;;)
    {
      localStringBuffer.append(paramString.charAt(7));
      return super.a(localStringBuffer.toString());
      localStringBuffer.append(arrayOfChar, 0, 2);
      localStringBuffer.append(c);
      localStringBuffer.append("0000");
      localStringBuffer.append(arrayOfChar, 2, 3);
      continue;
      localStringBuffer.append(arrayOfChar, 0, 3);
      localStringBuffer.append("00000");
      localStringBuffer.append(arrayOfChar, 3, 2);
      continue;
      localStringBuffer.append(arrayOfChar, 0, 4);
      localStringBuffer.append("00000");
      localStringBuffer.append(arrayOfChar[4]);
    }
  }
  
  protected final int[] a(aj paramaj, int paramInt)
    throws y
  {
    return a(paramaj, paramInt, true, a);
  }
  
  final q b()
  {
    return q.o;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/by.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */