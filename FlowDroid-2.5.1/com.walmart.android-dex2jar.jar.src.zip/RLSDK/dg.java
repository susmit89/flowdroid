package RLSDK;

final class dg
{
  private final ak a;
  private do b;
  private dm c;
  
  dg(ak paramak)
    throws v
  {
    int i = paramak.b;
    if ((i < 21) || ((i & 0x3) != 1)) {
      throw v.a();
    }
    this.a = paramak;
  }
  
  private int a(int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.a.a(paramInt1, paramInt2)) {
      return paramInt3 << 1 | 0x1;
    }
    return paramInt3 << 1;
  }
  
  final dm a()
    throws v
  {
    int k = 0;
    if (this.c != null) {
      return this.c;
    }
    int i = 0;
    int j = 0;
    while (i < 6)
    {
      j = a(i, 8, j);
      i += 1;
    }
    j = a(8, 7, a(8, 8, a(7, 8, j)));
    i = 5;
    while (i >= 0)
    {
      j = a(8, i, j);
      i -= 1;
    }
    int n = this.a.b;
    int m = n - 1;
    i = k;
    k = m;
    while (k >= n - 7)
    {
      i = a(8, k, i);
      k -= 1;
    }
    m = n - 8;
    k = i;
    i = m;
    while (i < n)
    {
      k = a(i, 8, k);
      i += 1;
    }
    this.c = dm.b(j, k);
    if (this.c != null) {
      return this.c;
    }
    throw v.a();
  }
  
  final do b()
    throws v
  {
    int m = 0;
    if (this.b != null) {
      return this.b;
    }
    int n = this.a.b;
    int i = n - 17 >> 2;
    if (i <= 6) {
      return do.b(i);
    }
    int i1 = n - 11;
    i = 5;
    int j = 0;
    int k;
    while (i >= 0)
    {
      k = n - 9;
      while (k >= i1)
      {
        j = a(k, i, j);
        k -= 1;
      }
      i -= 1;
    }
    this.b = do.c(j);
    if ((this.b != null) && (this.b.d() == n)) {
      return this.b;
    }
    i = 5;
    j = m;
    while (i >= 0)
    {
      k = n - 9;
      while (k >= i1)
      {
        j = a(i, k, j);
        k -= 1;
      }
      i -= 1;
    }
    this.b = do.c(j);
    if ((this.b != null) && (this.b.d() == n)) {
      return this.b;
    }
    throw v.a();
  }
  
  final byte[] c()
    throws v
  {
    Object localObject = a();
    do localdo = b();
    localObject = di.a(((dm)localObject).b());
    int i7 = this.a.b;
    ((di)localObject).a(this.a, i7);
    localObject = localdo.e();
    byte[] arrayOfByte = new byte[localdo.c()];
    int i = i7 - 1;
    int j = 0;
    int k = 0;
    int i4 = 0;
    int n = 1;
    while (i > 0)
    {
      int i1 = i;
      if (i == 6) {
        i1 = i - 1;
      }
      i = 0;
      while (i < i7)
      {
        if (n != 0) {}
        int m;
        int i6;
        for (int i2 = i7 - 1 - i;; i2 = i)
        {
          int i3 = 0;
          m = k;
          i6 = j;
          while (i3 < 2)
          {
            k = i6;
            j = m;
            int i5 = i4;
            if (!((ak)localObject).a(i1 - i3, i2))
            {
              i6 += 1;
              j = m << 1;
              m = j;
              if (this.a.a(i1 - i3, i2)) {
                m = j | 0x1;
              }
              k = i6;
              j = m;
              i5 = i4;
              if (i6 == 8)
              {
                arrayOfByte[i4] = ((byte)m);
                j = 0;
                i5 = i4 + 1;
                k = 0;
              }
            }
            i3 += 1;
            i6 = k;
            m = j;
            i4 = i5;
          }
        }
        i += 1;
        j = i6;
        k = m;
      }
      i = i1 - 2;
      n ^= 0x1;
    }
    if (i4 != localdo.c()) {
      throw v.a();
    }
    return arrayOfByte;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */