package RLSDK;

import android.app.Application;
import android.content.Context;
import android.graphics.Point;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.view.Display;
import android.view.WindowManager;
import java.io.IOException;

public class i
  extends h
{
  Camera.CameraInfo info = new Camera.CameraInfo();
  int openedCameraIndex;
  int selectedCameraIndex = 0;
  
  protected i(Application paramApplication)
  {
    super(paramApplication);
  }
  
  protected void determineOrientation()
  {
    int k = 0;
    Camera.getCameraInfo(this.openedCameraIndex, this.info);
    Display localDisplay = ((WindowManager)this.mContext.getSystemService("window")).getDefaultDisplay();
    int i;
    int m;
    label105:
    int j;
    switch (localDisplay.getRotation())
    {
    default: 
      i = 0;
      if (this.info.orientation == 0)
      {
        Point localPoint = this.configManager.a();
        if (localPoint.x <= localPoint.y) {
          break label257;
        }
        m = 1;
        if (localDisplay.getWidth() <= localDisplay.getHeight()) {
          break label263;
        }
        j = 1;
        label120:
        if ((i != 90) && (i != 270)) {
          break label280;
        }
        if (j != 0) {
          break;
        }
      }
      break;
    }
    label257:
    label263:
    label268:
    label280:
    for (k = 1;; k = j)
    {
      if (m != k) {
        if (this.info.facing != 1) {
          break label268;
        }
      }
      for (this.info.orientation = 270;; this.info.orientation = 90)
      {
        this.relativeCameraOrientation = (this.info.orientation - i);
        if (this.info.facing == 1) {
          this.relativeCameraOrientation = (-this.info.orientation - i);
        }
        this.relativeCameraOrientation = ((this.relativeCameraOrientation + 360) % 360);
        this.camera.setDisplayOrientation(this.relativeCameraOrientation);
        return;
        i = 0;
        break;
        i = 90;
        break;
        i = 180;
        break;
        i = 270;
        break;
        m = 0;
        break label105;
        j = 0;
        break label120;
      }
    }
  }
  
  protected int getOpenedCameraIndex()
  {
    return this.openedCameraIndex;
  }
  
  public int getSelectedCameraIndex()
  {
    return this.selectedCameraIndex;
  }
  
  protected boolean isCameraFrontFacing()
  {
    Camera.getCameraInfo(this.openedCameraIndex, this.info);
    return this.info.facing == 1;
  }
  
  protected void openCamera()
    throws IOException
  {
    try
    {
      this.camera = Camera.open(this.selectedCameraIndex);
      this.openedCameraIndex = this.selectedCameraIndex;
      if (this.camera == null) {
        throw new IOException();
      }
    }
    catch (RuntimeException localRuntimeException)
    {
      for (;;)
      {
        try
        {
          this.camera = Camera.open(0);
          this.openedCameraIndex = 0;
        }
        catch (Exception localException) {}
      }
    }
  }
  
  public void setSelectedCameraIndex(int paramInt)
  {
    if (paramInt < Camera.getNumberOfCameras()) {
      this.selectedCameraIndex = paramInt;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */