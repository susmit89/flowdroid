package RLSDK;

abstract class cm
  extends cp
{
  cm(aj paramaj)
  {
    super(paramaj);
  }
  
  public final String a()
    throws y
  {
    if (this.a.b != 60) {
      throw y.a();
    }
    StringBuffer localStringBuffer = new StringBuffer();
    b(localStringBuffer, 5);
    b(localStringBuffer, 45, 15);
    return localStringBuffer.toString();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */