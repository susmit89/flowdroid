package RLSDK;

final class cl
  extends cp
{
  private final String c;
  private final String d;
  
  cl(aj paramaj, String paramString1, String paramString2)
  {
    super(paramaj);
    this.c = paramString2;
    this.d = paramString1;
  }
  
  protected final int a(int paramInt)
  {
    return paramInt % 100000;
  }
  
  public final String a()
    throws y
  {
    if (this.a.b != 84) {
      throw y.a();
    }
    StringBuffer localStringBuffer = new StringBuffer();
    b(localStringBuffer, 8);
    b(localStringBuffer, 48, 20);
    int j = this.b.a(68, 16);
    if (j != 38400)
    {
      localStringBuffer.append('(');
      localStringBuffer.append(this.c);
      localStringBuffer.append(')');
      int i = j % 32;
      int k = j / 32;
      j = k % 12 + 1;
      k /= 12;
      if (k / 10 == 0) {
        localStringBuffer.append('0');
      }
      localStringBuffer.append(k);
      if (j / 10 == 0) {
        localStringBuffer.append('0');
      }
      localStringBuffer.append(j);
      if (i / 10 == 0) {
        localStringBuffer.append('0');
      }
      localStringBuffer.append(i);
    }
    return localStringBuffer.toString();
  }
  
  protected final void a(StringBuffer paramStringBuffer, int paramInt)
  {
    paramInt /= 100000;
    paramStringBuffer.append('(');
    paramStringBuffer.append(this.d);
    paramStringBuffer.append(paramInt);
    paramStringBuffer.append(')');
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */