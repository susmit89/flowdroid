package RLSDK;

import java.util.Hashtable;

final class bw
{
  private static final int[] a = { 1, 1, 2 };
  private static final int[] b = { 24, 20, 18, 17, 12, 6, 3, 10, 9, 5 };
  private final int[] c = new int[4];
  private final StringBuffer d = new StringBuffer();
  
  final ab a(int paramInt1, aj paramaj, int paramInt2)
    throws y
  {
    Object localObject3 = bx.a(paramaj, paramInt2, false, a);
    Object localObject1 = this.d;
    ((StringBuffer)localObject1).setLength(0);
    Object localObject2 = this.c;
    localObject2[0] = 0;
    localObject2[1] = 0;
    localObject2[2] = 0;
    localObject2[3] = 0;
    int m = paramaj.b;
    paramInt2 = localObject3[1];
    int i = 0;
    int k = 0;
    int j;
    if ((k < 5) && (paramInt2 < m))
    {
      int n = bx.a(paramaj, (int[])localObject2, paramInt2, bx.e);
      ((StringBuffer)localObject1).append((char)(n % 10 + 48));
      j = 0;
      while (j < localObject2.length)
      {
        paramInt2 += localObject2[j];
        j += 1;
      }
      if (n < 10) {
        break label774;
      }
      i |= 1 << 4 - k;
    }
    label583:
    label733:
    label774:
    for (;;)
    {
      j = paramInt2;
      if (k != 4)
      {
        j = paramInt2;
        for (;;)
        {
          paramInt2 = j;
          if (j >= m) {
            break;
          }
          paramInt2 = j;
          if (paramaj.a(j)) {
            break;
          }
          j += 1;
        }
        for (;;)
        {
          j = paramInt2;
          if (paramInt2 >= m) {
            break;
          }
          j = paramInt2;
          if (!paramaj.a(paramInt2)) {
            break;
          }
          paramInt2 += 1;
        }
      }
      k += 1;
      paramInt2 = j;
      break;
      if (((StringBuffer)localObject1).length() != 5) {
        throw y.a();
      }
      j = 0;
      while (j < 10)
      {
        if (i == b[j])
        {
          paramaj = ((StringBuffer)localObject1).toString();
          m = paramaj.length();
          k = 0;
          i = m - 2;
          while (i >= 0)
          {
            k += paramaj.charAt(i) - '0';
            i -= 2;
          }
        }
        j += 1;
      }
      throw y.a();
      k *= 3;
      i = m - 1;
      while (i >= 0)
      {
        k += paramaj.charAt(i) - '0';
        i -= 2;
      }
      if (k * 3 % 10 != j) {
        throw y.a();
      }
      String str = ((StringBuffer)localObject1).toString();
      switch (str.length())
      {
      case 3: 
      case 4: 
      default: 
        paramaj = null;
      }
      for (;;)
      {
        i = localObject3[0];
        localObject1 = new ad((localObject3[1] + i) / 2.0F, paramInt1);
        localObject2 = new ad(paramInt2, paramInt1);
        localObject3 = q.p;
        localObject1 = new ab(str, null, new ad[] { localObject1, localObject2 }, (q)localObject3);
        if (paramaj != null) {
          ((ab)localObject1).a(paramaj);
        }
        return (ab)localObject1;
        localObject1 = ac.e;
        paramaj = Integer.valueOf(str);
        if (paramaj == null)
        {
          paramaj = null;
          continue;
          localObject2 = ac.f;
          switch (str.charAt(0))
          {
          default: 
            paramaj = "";
            j = Integer.parseInt(str.substring(1));
            i = j / 100;
            j %= 100;
            if (j >= 10) {
              break;
            }
          }
          for (localObject1 = "0" + j;; localObject1 = String.valueOf(j))
          {
            paramaj = paramaj + String.valueOf(i) + '.' + (String)localObject1;
            for (;;)
            {
              localObject1 = localObject2;
              break;
              paramaj = "£";
              break label583;
              paramaj = "$";
              break label583;
              if ("90000".equals(str))
              {
                paramaj = null;
              }
              else if ("99991".equals(str))
              {
                paramaj = "0.00";
              }
              else
              {
                if (!"99990".equals(str)) {
                  break label733;
                }
                paramaj = "Used";
              }
            }
            paramaj = "";
            break label583;
          }
        }
        else
        {
          localObject2 = new Hashtable(1);
          ((Hashtable)localObject2).put(localObject1, paramaj);
          paramaj = (aj)localObject2;
        }
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */