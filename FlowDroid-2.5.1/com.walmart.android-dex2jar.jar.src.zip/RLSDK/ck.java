package RLSDK;

final class ck
  extends co
{
  ck(aj paramaj)
  {
    super(paramaj);
  }
  
  public final String a()
    throws y
  {
    if (this.a.b < 48) {
      throw y.a();
    }
    StringBuffer localStringBuffer = new StringBuffer();
    b(localStringBuffer, 8);
    int i = this.b.a(48, 2);
    localStringBuffer.append("(393");
    localStringBuffer.append(i);
    localStringBuffer.append(')');
    i = this.b.a(50, 10);
    if (i / 100 == 0) {
      localStringBuffer.append('0');
    }
    if (i / 10 == 0) {
      localStringBuffer.append('0');
    }
    localStringBuffer.append(i);
    localStringBuffer.append(this.b.a(60, null).a());
    return localStringBuffer.toString();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ck.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */