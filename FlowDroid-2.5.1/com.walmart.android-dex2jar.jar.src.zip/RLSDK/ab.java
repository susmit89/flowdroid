package RLSDK;

import java.util.Enumeration;
import java.util.Hashtable;

public final class ab
{
  private final String a;
  private final byte[] b;
  private ad[] c;
  private final q d;
  private Hashtable e;
  private final long f;
  
  public ab(String paramString, byte[] paramArrayOfByte, ad[] paramArrayOfad, q paramq)
  {
    this(paramString, paramArrayOfByte, paramArrayOfad, paramq, System.currentTimeMillis());
  }
  
  private ab(String paramString, byte[] paramArrayOfByte, ad[] paramArrayOfad, q paramq, long paramLong)
  {
    if ((paramString == null) && (paramArrayOfByte == null)) {
      throw new IllegalArgumentException("Text and bytes are null");
    }
    this.a = paramString;
    this.b = paramArrayOfByte;
    this.c = paramArrayOfad;
    this.d = paramq;
    this.e = null;
    this.f = paramLong;
  }
  
  public final String a()
  {
    return this.a;
  }
  
  public final void a(ac paramac, Object paramObject)
  {
    if (this.e == null) {
      this.e = new Hashtable(3);
    }
    this.e.put(paramac, paramObject);
  }
  
  public final void a(Hashtable paramHashtable)
  {
    if (paramHashtable != null)
    {
      if (this.e != null) {
        break label17;
      }
      this.e = paramHashtable;
    }
    for (;;)
    {
      return;
      label17:
      Enumeration localEnumeration = paramHashtable.keys();
      while (localEnumeration.hasMoreElements())
      {
        ac localac = (ac)localEnumeration.nextElement();
        Object localObject = paramHashtable.get(localac);
        this.e.put(localac, localObject);
      }
    }
  }
  
  public final void a(ad[] paramArrayOfad)
  {
    if (this.c == null) {
      this.c = paramArrayOfad;
    }
    while ((paramArrayOfad == null) || (paramArrayOfad.length <= 0)) {
      return;
    }
    ad[] arrayOfad = new ad[this.c.length + paramArrayOfad.length];
    System.arraycopy(this.c, 0, arrayOfad, 0, this.c.length);
    System.arraycopy(paramArrayOfad, 0, arrayOfad, this.c.length, paramArrayOfad.length);
    this.c = arrayOfad;
  }
  
  public final ad[] b()
  {
    return this.c;
  }
  
  public final q c()
  {
    return this.d;
  }
  
  public final Hashtable d()
  {
    return this.e;
  }
  
  public final String toString()
  {
    if (this.a == null) {
      return "[" + this.b.length + " bytes]";
    }
    return this.a;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */