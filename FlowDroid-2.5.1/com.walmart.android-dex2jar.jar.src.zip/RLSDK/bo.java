package RLSDK;

public final class bo
  extends bx
{
  static final int[] a = { 0, 11, 13, 14, 19, 25, 28, 21, 22, 26 };
  private final int[] f = new int[4];
  
  protected final int a(aj paramaj, int[] paramArrayOfInt, StringBuffer paramStringBuffer)
    throws y
  {
    int[] arrayOfInt = this.f;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    arrayOfInt[2] = 0;
    arrayOfInt[3] = 0;
    int n = paramaj.b;
    int j = paramArrayOfInt[1];
    int k = 0;
    int i = 0;
    if ((k < 6) && (j < n))
    {
      int i1 = a(paramaj, arrayOfInt, j, e);
      paramStringBuffer.append((char)(i1 % 10 + 48));
      int m = 0;
      while (m < arrayOfInt.length)
      {
        j += arrayOfInt[m];
        m += 1;
      }
      if (i1 < 10) {
        break label280;
      }
      i = 1 << 5 - k | i;
    }
    label277:
    label280:
    for (;;)
    {
      k += 1;
      break;
      k = 0;
      if (k < 10) {
        if (i == a[k])
        {
          paramStringBuffer.insert(0, (char)(k + 48));
          i = a(paramaj, j, true, c)[1];
          j = 0;
        }
      }
      for (;;)
      {
        if ((j >= 6) || (i >= n)) {
          break label277;
        }
        paramStringBuffer.append((char)(a(paramaj, arrayOfInt, i, d) + 48));
        k = 0;
        for (;;)
        {
          if (k < arrayOfInt.length)
          {
            i += arrayOfInt[k];
            k += 1;
            continue;
            k += 1;
            break;
            throw y.a();
          }
        }
        j += 1;
      }
      return i;
    }
  }
  
  final q b()
  {
    return q.h;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */