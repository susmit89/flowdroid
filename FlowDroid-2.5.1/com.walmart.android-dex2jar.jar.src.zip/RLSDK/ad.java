package RLSDK;

public class ad
{
  private final float a;
  private final float b;
  
  public ad(float paramFloat1, float paramFloat2)
  {
    this.a = paramFloat1;
    this.b = paramFloat2;
  }
  
  public static float a(ad paramad1, ad paramad2)
  {
    float f1 = paramad1.a - paramad2.a;
    float f2 = paramad1.b - paramad2.b;
    return (float)Math.sqrt(f1 * f1 + f2 * f2);
  }
  
  public static void a(ad[] paramArrayOfad)
  {
    float f1 = a(paramArrayOfad[0], paramArrayOfad[1]);
    float f2 = a(paramArrayOfad[1], paramArrayOfad[2]);
    float f3 = a(paramArrayOfad[0], paramArrayOfad[2]);
    ad localad;
    Object localObject2;
    Object localObject1;
    if ((f2 >= f1) && (f2 >= f3))
    {
      localad = paramArrayOfad[0];
      localObject2 = paramArrayOfad[1];
      localObject1 = paramArrayOfad[2];
      f1 = localad.a;
      f2 = localad.b;
      f3 = ((ad)localObject1).a;
      float f4 = ((ad)localObject2).b;
      float f5 = ((ad)localObject1).b;
      if ((f3 - f1) * (f4 - f2) - (((ad)localObject2).a - f1) * (f5 - f2) >= 0.0F) {
        break label179;
      }
    }
    for (;;)
    {
      paramArrayOfad[0] = localObject1;
      paramArrayOfad[1] = localad;
      paramArrayOfad[2] = localObject2;
      return;
      if ((f3 >= f2) && (f3 >= f1))
      {
        localad = paramArrayOfad[1];
        localObject2 = paramArrayOfad[0];
        localObject1 = paramArrayOfad[2];
        break;
      }
      localad = paramArrayOfad[2];
      localObject2 = paramArrayOfad[0];
      localObject1 = paramArrayOfad[1];
      break;
      label179:
      Object localObject3 = localObject1;
      localObject1 = localObject2;
      localObject2 = localObject3;
    }
  }
  
  public final float a()
  {
    return this.a;
  }
  
  public final float b()
  {
    return this.b;
  }
  
  public boolean equals(Object paramObject)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if ((paramObject instanceof ad))
    {
      paramObject = (ad)paramObject;
      bool1 = bool2;
      if (this.a == ((ad)paramObject).a)
      {
        bool1 = bool2;
        if (this.b == ((ad)paramObject).b) {
          bool1 = true;
        }
      }
    }
    return bool1;
  }
  
  public int hashCode()
  {
    return Float.floatToIntBits(this.a) * 31 + Float.floatToIntBits(this.b);
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer(25);
    localStringBuffer.append('(');
    localStringBuffer.append(this.a);
    localStringBuffer.append(',');
    localStringBuffer.append(this.b);
    localStringBuffer.append(')');
    return localStringBuffer.toString();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */