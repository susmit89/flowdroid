package RLSDK;

public final class t
  extends aa
{
  private static final t a = new t();
  
  public static t a()
  {
    return a;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */