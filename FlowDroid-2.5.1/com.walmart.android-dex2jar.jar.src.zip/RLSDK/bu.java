package RLSDK;

import java.util.Enumeration;
import java.util.Hashtable;

public abstract class bu
  implements z
{
  protected static int a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
  {
    int n = paramArrayOfInt1.length;
    int j = 0;
    int k = 0;
    int i = 0;
    while (j < n)
    {
      i += paramArrayOfInt1[j];
      k += paramArrayOfInt2[j];
      j += 1;
    }
    if (i < k) {}
    label143:
    for (;;)
    {
      return Integer.MAX_VALUE;
      int i1 = (i << 8) / k;
      j = 0;
      k = 0;
      if (j >= n) {
        break;
      }
      int m = paramArrayOfInt1[j] << 8;
      int i2 = paramArrayOfInt2[j] * i1;
      if (m > i2) {
        m -= i2;
      }
      for (;;)
      {
        if (m > paramInt * i1 >> 8) {
          break label143;
        }
        k += m;
        j += 1;
        break;
        m = i2 - m;
      }
    }
    return k / i;
  }
  
  protected static void a(aj paramaj, int paramInt, int[] paramArrayOfInt)
    throws y
  {
    int m = paramArrayOfInt.length;
    int i = 0;
    while (i < m)
    {
      paramArrayOfInt[i] = 0;
      i += 1;
    }
    int n = paramaj.b;
    if (paramInt >= n) {
      throw y.a();
    }
    if (!paramaj.a(paramInt)) {}
    int j;
    for (i = 1;; i = 0)
    {
      k = 0;
      j = paramInt;
      paramInt = k;
      for (;;)
      {
        if (j >= n) {
          break label137;
        }
        if (!(paramaj.a(j) ^ i)) {
          break;
        }
        paramArrayOfInt[paramInt] += 1;
        j += 1;
      }
    }
    int k = paramInt + 1;
    paramInt = k;
    if (k != m)
    {
      paramArrayOfInt[k] = 1;
      if (i == 0) {}
      for (paramInt = 1;; paramInt = 0)
      {
        i = paramInt;
        paramInt = k;
        break;
      }
    }
    label137:
    if ((paramInt != m) && ((paramInt != m - 1) || (j != n))) {
      throw y.a();
    }
  }
  
  private ab b(s params, Hashtable paramHashtable)
    throws y
  {
    int i1 = params.a();
    int m = params.b();
    Object localObject1 = new aj(i1);
    int i;
    if ((paramHashtable != null) && (paramHashtable.containsKey(u.d))) {
      i = 1;
    }
    for (;;)
    {
      int j;
      label47:
      label65:
      int n;
      int k;
      if (i != 0)
      {
        j = 8;
        int i2 = Math.max(1, m >> j);
        if (i == 0) {
          break label262;
        }
        i = m;
        j = 0;
        if (j >= i) {
          break label424;
        }
        n = j + 1 >> 1;
        if ((j & 0x1) != 0) {
          break label268;
        }
        k = 1;
        label92:
        if (k == 0) {
          break label274;
        }
        k = n;
        label101:
        n = (m >> 1) + k * i2;
        if ((n < 0) || (n >= m)) {
          break label424;
        }
      }
      try
      {
        Object localObject2 = params.a(n, (aj)localObject1);
        localObject1 = localObject2;
        k = 0;
        for (;;)
        {
          localObject3 = localObject1;
          localObject2 = paramHashtable;
          if (k >= 2) {
            break label408;
          }
          localObject2 = paramHashtable;
          if (k == 1)
          {
            ((aj)localObject1).a();
            localObject2 = paramHashtable;
            if (paramHashtable != null)
            {
              localObject2 = paramHashtable;
              if (paramHashtable.containsKey(u.h))
              {
                localObject2 = new Hashtable();
                localObject3 = paramHashtable.keys();
                for (;;)
                {
                  if (((Enumeration)localObject3).hasMoreElements())
                  {
                    Object localObject4 = ((Enumeration)localObject3).nextElement();
                    if (!localObject4.equals(u.h))
                    {
                      ((Hashtable)localObject2).put(localObject4, paramHashtable.get(localObject4));
                      continue;
                      i = 0;
                      break;
                      j = 5;
                      break label47;
                      label262:
                      i = 15;
                      break label65;
                      label268:
                      k = 0;
                      break label92;
                      label274:
                      k = -n;
                      break label101;
                    }
                  }
                }
              }
            }
          }
          try
          {
            paramHashtable = a(n, (aj)localObject1, (Hashtable)localObject2);
            if (k == 1)
            {
              paramHashtable.a(ac.b, new Integer(180));
              localObject3 = paramHashtable.b();
              localObject3[0] = new ad(i1 - localObject3[0].a() - 1.0F, localObject3[0].b());
              localObject3[1] = new ad(i1 - localObject3[1].a() - 1.0F, localObject3[1].b());
            }
            return paramHashtable;
          }
          catch (aa paramHashtable)
          {
            k += 1;
            paramHashtable = (Hashtable)localObject2;
          }
        }
      }
      catch (y localy)
      {
        Hashtable localHashtable = paramHashtable;
        Object localObject3 = localObject1;
        label408:
        j += 1;
        localObject1 = localObject3;
        paramHashtable = localHashtable;
      }
    }
    label424:
    throw y.a();
  }
  
  protected static void b(aj paramaj, int paramInt, int[] paramArrayOfInt)
    throws y
  {
    int i = paramArrayOfInt.length;
    boolean bool = paramaj.a(paramInt);
    while ((paramInt > 0) && (i >= 0))
    {
      int j = paramInt - 1;
      paramInt = j;
      if (paramaj.a(j) != bool)
      {
        i -= 1;
        if (!bool)
        {
          bool = true;
          paramInt = j;
        }
        else
        {
          bool = false;
          paramInt = j;
        }
      }
    }
    if (i >= 0) {
      throw y.a();
    }
    a(paramaj, paramInt + 1, paramArrayOfInt);
  }
  
  public abstract ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y, t, v;
  
  public ab a(s params, Hashtable paramHashtable)
    throws y, v
  {
    try
    {
      ab localab = b(params, paramHashtable);
      return localab;
    }
    catch (y localy)
    {
      if (paramHashtable == null) {
        break label41;
      }
    }
    if (paramHashtable.containsKey(u.d)) {}
    label41:
    for (int i = 1;; i = 0)
    {
      if (i != 0) {
        params.d();
      }
      throw localy;
    }
  }
  
  public void a() {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */