package RLSDK;

import java.util.Hashtable;

public abstract class bx
  extends bu
{
  static final int[] b = { 1, 1, 1 };
  static final int[] c = { 1, 1, 1, 1, 1 };
  static final int[][] d;
  static final int[][] e;
  private final StringBuffer a = new StringBuffer(20);
  private final bw f = new bw();
  private final bq g = new bq();
  
  static
  {
    int[] arrayOfInt1 = { 3, 2, 1, 1 };
    int[] arrayOfInt2 = { 1, 2, 3, 1 };
    d = new int[][] { arrayOfInt1, { 2, 2, 2, 1 }, { 2, 1, 2, 2 }, { 1, 4, 1, 1 }, { 1, 1, 3, 2 }, arrayOfInt2, { 1, 1, 1, 4 }, { 1, 3, 1, 2 }, { 1, 2, 1, 3 }, { 3, 1, 1, 2 } };
    e = new int[20][];
    int i = 0;
    while (i < 10)
    {
      e[i] = d[i];
      i += 1;
    }
    i = 10;
    while (i < 20)
    {
      arrayOfInt1 = d[(i - 10)];
      arrayOfInt2 = new int[arrayOfInt1.length];
      int j = 0;
      while (j < arrayOfInt1.length)
      {
        arrayOfInt2[j] = arrayOfInt1[(arrayOfInt1.length - j - 1)];
        j += 1;
      }
      e[i] = arrayOfInt2;
      i += 1;
    }
  }
  
  static int a(aj paramaj, int[] paramArrayOfInt, int paramInt, int[][] paramArrayOfInt1)
    throws y
  {
    a(paramaj, paramInt, paramArrayOfInt);
    int i = 107;
    int j = -1;
    int m = paramArrayOfInt1.length;
    paramInt = 0;
    if (paramInt < m)
    {
      int k = a(paramArrayOfInt, paramArrayOfInt1[paramInt], 179);
      if (k >= i) {
        break label70;
      }
      j = paramInt;
      i = k;
    }
    label70:
    for (;;)
    {
      paramInt += 1;
      break;
      if (j >= 0) {
        return j;
      }
      throw y.a();
    }
  }
  
  static int[] a(aj paramaj)
    throws y
  {
    int i = 0;
    Object localObject = null;
    boolean bool = false;
    while (!bool)
    {
      int[] arrayOfInt = a(paramaj, i, false, b);
      int k = arrayOfInt[0];
      int j = arrayOfInt[1];
      int m = k - (j - k);
      i = j;
      localObject = arrayOfInt;
      if (m >= 0)
      {
        bool = paramaj.a(m, k);
        i = j;
        localObject = arrayOfInt;
      }
    }
    return (int[])localObject;
  }
  
  static int[] a(aj paramaj, int paramInt, boolean paramBoolean, int[] paramArrayOfInt)
    throws y
  {
    int m = paramArrayOfInt.length;
    int[] arrayOfInt = new int[m];
    int n = paramaj.b;
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramInt < n)
    {
      if (!paramaj.a(paramInt)) {}
      for (bool1 = true;; bool1 = false)
      {
        bool2 = bool1;
        if (paramBoolean == bool1) {
          break label63;
        }
        paramInt += 1;
        break;
      }
    }
    label63:
    int j = paramInt;
    int i = 0;
    paramBoolean = bool2;
    if (j < n)
    {
      int k;
      if ((paramaj.a(j) ^ paramBoolean))
      {
        arrayOfInt[i] += 1;
        k = i;
        i = paramInt;
      }
      for (;;)
      {
        j += 1;
        paramInt = i;
        i = k;
        break;
        if (i == m - 1)
        {
          if (a(arrayOfInt, paramArrayOfInt, 179) < 107) {
            return new int[] { paramInt, j };
          }
          k = paramInt + (arrayOfInt[0] + arrayOfInt[1]);
          paramInt = 2;
          while (paramInt < m)
          {
            arrayOfInt[(paramInt - 2)] = arrayOfInt[paramInt];
            paramInt += 1;
          }
          arrayOfInt[(m - 2)] = 0;
          arrayOfInt[(m - 1)] = 0;
          paramInt = i - 1;
          i = k;
        }
        for (;;)
        {
          arrayOfInt[paramInt] = 1;
          if (paramBoolean) {
            break label256;
          }
          paramBoolean = true;
          k = paramInt;
          break;
          k = i + 1;
          i = paramInt;
          paramInt = k;
        }
        label256:
        paramBoolean = false;
        k = paramInt;
      }
    }
    throw y.a();
  }
  
  protected abstract int a(aj paramaj, int[] paramArrayOfInt, StringBuffer paramStringBuffer)
    throws y;
  
  public ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y, t, v
  {
    return a(paramInt, paramaj, a(paramaj), paramHashtable);
  }
  
  public ab a(int paramInt, aj paramaj, int[] paramArrayOfInt, Hashtable paramHashtable)
    throws y, t, v
  {
    if (paramHashtable == null) {}
    int[] arrayOfInt;
    for (paramHashtable = null;; paramHashtable = (ae)paramHashtable.get(u.h))
    {
      if (paramHashtable != null) {
        paramHashtable.a(new ad((paramArrayOfInt[0] + paramArrayOfInt[1]) / 2.0F, paramInt));
      }
      localObject = this.a;
      ((StringBuffer)localObject).setLength(0);
      int i = a(paramaj, paramArrayOfInt, (StringBuffer)localObject);
      if (paramHashtable != null) {
        paramHashtable.a(new ad(i, paramInt));
      }
      arrayOfInt = a(paramaj, i);
      if (paramHashtable != null) {
        paramHashtable.a(new ad((arrayOfInt[0] + arrayOfInt[1]) / 2.0F, paramInt));
      }
      i = arrayOfInt[1];
      int j = i - arrayOfInt[0] + i;
      if ((j < paramaj.b) && (paramaj.a(i, j))) {
        break;
      }
      throw y.a();
    }
    paramHashtable = ((StringBuffer)localObject).toString();
    if (!a(paramHashtable)) {
      throw t.a();
    }
    float f1 = (paramArrayOfInt[1] + paramArrayOfInt[0]) / 2.0F;
    float f2 = (arrayOfInt[1] + arrayOfInt[0]) / 2.0F;
    Object localObject = b();
    paramArrayOfInt = new ab(paramHashtable, null, new ad[] { new ad(f1, paramInt), new ad(f2, paramInt) }, (q)localObject);
    try
    {
      paramaj = this.f.a(paramInt, paramaj, arrayOfInt[1]);
      paramArrayOfInt.a(paramaj.d());
      paramArrayOfInt.a(paramaj.b());
      if ((q.h.equals(localObject)) || (q.n.equals(localObject)))
      {
        paramaj = this.g.a(paramHashtable);
        if (paramaj != null) {
          paramArrayOfInt.a(ac.g, paramaj);
        }
      }
      return paramArrayOfInt;
    }
    catch (aa paramaj)
    {
      for (;;) {}
    }
  }
  
  boolean a(String paramString)
    throws t, v
  {
    boolean bool2 = false;
    int k = paramString.length();
    boolean bool1 = bool2;
    if (k != 0)
    {
      int i = k - 2;
      int j = 0;
      while (i >= 0)
      {
        int m = paramString.charAt(i) - '0';
        if ((m < 0) || (m > 9)) {
          throw v.a();
        }
        j += m;
        i -= 2;
      }
      j *= 3;
      i = k - 1;
      while (i >= 0)
      {
        k = paramString.charAt(i) - '0';
        if ((k < 0) || (k > 9)) {
          throw v.a();
        }
        j += k;
        i -= 2;
      }
      bool1 = bool2;
      if (j % 10 == 0) {
        bool1 = true;
      }
    }
    return bool1;
  }
  
  int[] a(aj paramaj, int paramInt)
    throws y
  {
    return a(paramaj, paramInt, false, b);
  }
  
  abstract q b();
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */