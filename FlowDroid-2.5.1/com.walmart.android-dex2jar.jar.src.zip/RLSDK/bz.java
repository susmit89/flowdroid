package RLSDK;

public abstract class bz
  extends bu
{
  protected final int[] a = new int[4];
  protected final int[] b = new int[8];
  protected final float[] c = new float[4];
  protected final float[] d = new float[4];
  protected final int[] e = new int[this.b.length / 2];
  protected final int[] f = new int[this.b.length / 2];
  
  protected static int a(int[] paramArrayOfInt)
  {
    int i = 0;
    int j = 0;
    while (i < paramArrayOfInt.length)
    {
      j += paramArrayOfInt[i];
      i += 1;
    }
    return j;
  }
  
  protected static int a(int[] paramArrayOfInt, int[][] paramArrayOfInt1)
    throws y
  {
    int i = 0;
    while (i < paramArrayOfInt1.length)
    {
      if (a(paramArrayOfInt, paramArrayOfInt1[i], 102) < 51) {
        return i;
      }
      i += 1;
    }
    throw y.a();
  }
  
  protected static void a(int[] paramArrayOfInt, float[] paramArrayOfFloat)
  {
    int j = 0;
    float f1 = paramArrayOfFloat[0];
    int i = 1;
    while (i < paramArrayOfInt.length)
    {
      float f2 = f1;
      if (paramArrayOfFloat[i] > f1)
      {
        f2 = paramArrayOfFloat[i];
        j = i;
      }
      i += 1;
      f1 = f2;
    }
    paramArrayOfInt[j] += 1;
  }
  
  protected static void b(int[] paramArrayOfInt, float[] paramArrayOfFloat)
  {
    int j = 0;
    float f1 = paramArrayOfFloat[0];
    int i = 1;
    while (i < paramArrayOfInt.length)
    {
      float f2 = f1;
      if (paramArrayOfFloat[i] < f1)
      {
        f2 = paramArrayOfFloat[i];
        j = i;
      }
      i += 1;
      f1 = f2;
    }
    paramArrayOfInt[j] -= 1;
  }
  
  protected static boolean b(int[] paramArrayOfInt)
  {
    boolean bool2 = false;
    int i = paramArrayOfInt[0] + paramArrayOfInt[1];
    int j = paramArrayOfInt[2];
    int k = paramArrayOfInt[3];
    float f1 = i / (j + i + k);
    boolean bool1 = bool2;
    if (f1 >= 0.7916667F)
    {
      bool1 = bool2;
      if (f1 <= 0.89285713F)
      {
        i = Integer.MAX_VALUE;
        int m = Integer.MIN_VALUE;
        j = 0;
        while (j < paramArrayOfInt.length)
        {
          int n = paramArrayOfInt[j];
          k = m;
          if (n > m) {
            k = n;
          }
          int i1 = i;
          if (n < i) {
            i1 = n;
          }
          j += 1;
          m = k;
          i = i1;
        }
        bool1 = bool2;
        if (m < i * 10) {
          bool1 = true;
        }
      }
    }
    return bool1;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */