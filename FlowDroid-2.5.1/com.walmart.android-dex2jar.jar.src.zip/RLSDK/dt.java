package RLSDK;

import java.util.Hashtable;
import java.util.Vector;

public final class dt
{
  private final ak a;
  private final Vector b;
  private boolean c;
  private final int[] d;
  private final ae e;
  
  public dt(ak paramak, ae paramae)
  {
    this.a = paramak;
    this.b = new Vector();
    this.d = new int[5];
    this.e = paramae;
  }
  
  private static float a(int[] paramArrayOfInt, int paramInt)
  {
    return paramInt - paramArrayOfInt[4] - paramArrayOfInt[3] - paramArrayOfInt[2] / 2.0F;
  }
  
  private static boolean a(int[] paramArrayOfInt)
  {
    int i = 0;
    int j = 0;
    int k;
    if (i < 5)
    {
      k = paramArrayOfInt[i];
      if (k != 0) {}
    }
    do
    {
      do
      {
        return false;
        j += k;
        i += 1;
        break;
      } while (j < 7);
      i = (j << 8) / 7;
      j = i / 2;
    } while ((Math.abs(i - (paramArrayOfInt[0] << 8)) >= j) || (Math.abs(i - (paramArrayOfInt[1] << 8)) >= j) || (Math.abs(i * 3 - (paramArrayOfInt[2] << 8)) >= j * 3) || (Math.abs(i - (paramArrayOfInt[3] << 8)) >= j) || (Math.abs(i - (paramArrayOfInt[4] << 8)) >= j));
    return true;
  }
  
  private boolean a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int k = paramArrayOfInt[0] + paramArrayOfInt[1] + paramArrayOfInt[2] + paramArrayOfInt[3] + paramArrayOfInt[4];
    int j = (int)a(paramArrayOfInt, paramInt2);
    int m = paramArrayOfInt[2];
    Object localObject = this.a;
    int n = ((ak)localObject).b;
    int[] arrayOfInt = a();
    paramInt2 = paramInt1;
    while ((paramInt2 >= 0) && (((ak)localObject).a(j, paramInt2)))
    {
      arrayOfInt[2] += 1;
      paramInt2 -= 1;
    }
    int i = paramInt2;
    float f1;
    if (paramInt2 < 0) {
      f1 = NaN.0F;
    }
    float f2;
    float f3;
    for (;;)
    {
      if (!Float.isNaN(f1))
      {
        i = (int)f1;
        m = paramArrayOfInt[2];
        paramArrayOfInt = this.a;
        n = paramArrayOfInt.a;
        localObject = a();
        paramInt1 = j;
        for (;;)
        {
          if ((paramInt1 >= 0) && (paramArrayOfInt.a(paramInt1, i)))
          {
            localObject[2] += 1;
            paramInt1 -= 1;
            continue;
            while ((i >= 0) && (!((ak)localObject).a(j, i)) && (arrayOfInt[1] <= m))
            {
              arrayOfInt[1] += 1;
              i -= 1;
            }
            if ((i < 0) || (arrayOfInt[1] > m))
            {
              f1 = NaN.0F;
              break;
            }
            while ((i >= 0) && (((ak)localObject).a(j, i)) && (arrayOfInt[0] <= m))
            {
              arrayOfInt[0] += 1;
              i -= 1;
            }
            if (arrayOfInt[0] > m)
            {
              f1 = NaN.0F;
              break;
            }
            paramInt1 += 1;
            while ((paramInt1 < n) && (((ak)localObject).a(j, paramInt1)))
            {
              arrayOfInt[2] += 1;
              paramInt1 += 1;
            }
            paramInt2 = paramInt1;
            if (paramInt1 == n)
            {
              f1 = NaN.0F;
              break;
            }
            while ((paramInt2 < n) && (!((ak)localObject).a(j, paramInt2)) && (arrayOfInt[3] < m))
            {
              arrayOfInt[3] += 1;
              paramInt2 += 1;
            }
            if ((paramInt2 == n) || (arrayOfInt[3] >= m))
            {
              f1 = NaN.0F;
              break;
            }
            while ((paramInt2 < n) && (((ak)localObject).a(j, paramInt2)) && (arrayOfInt[4] < m))
            {
              arrayOfInt[4] += 1;
              paramInt2 += 1;
            }
            if (arrayOfInt[4] >= m)
            {
              f1 = NaN.0F;
              break;
            }
            if (Math.abs(arrayOfInt[0] + arrayOfInt[1] + arrayOfInt[2] + arrayOfInt[3] + arrayOfInt[4] - k) * 5 >= k * 2)
            {
              f1 = NaN.0F;
              break;
            }
            if (a(arrayOfInt))
            {
              f1 = a(arrayOfInt, paramInt2);
              break;
            }
            f1 = NaN.0F;
            break;
          }
        }
        paramInt2 = paramInt1;
        if (paramInt1 < 0)
        {
          f2 = NaN.0F;
          if (Float.isNaN(f2)) {
            break label1028;
          }
          f3 = k / 7.0F;
          paramInt2 = this.b.size();
          paramInt1 = 0;
          label579:
          if (paramInt1 >= paramInt2) {
            break label1030;
          }
          paramArrayOfInt = (ds)this.b.elementAt(paramInt1);
          if (!paramArrayOfInt.a(f3, f1, f2)) {
            break label1021;
          }
          paramArrayOfInt.e();
        }
      }
    }
    label1021:
    label1028:
    label1030:
    for (paramInt1 = 1;; paramInt1 = 0)
    {
      if (paramInt1 == 0)
      {
        paramArrayOfInt = new ds(f2, f1, f3);
        this.b.addElement(paramArrayOfInt);
        if (this.e != null) {
          this.e.a(paramArrayOfInt);
        }
      }
      return true;
      while ((paramInt2 >= 0) && (!paramArrayOfInt.a(paramInt2, i)) && (localObject[1] <= m))
      {
        localObject[1] += 1;
        paramInt2 -= 1;
      }
      if ((paramInt2 < 0) || (localObject[1] > m))
      {
        f2 = NaN.0F;
        break;
      }
      while ((paramInt2 >= 0) && (paramArrayOfInt.a(paramInt2, i)) && (localObject[0] <= m))
      {
        localObject[0] += 1;
        paramInt2 -= 1;
      }
      if (localObject[0] > m)
      {
        f2 = NaN.0F;
        break;
      }
      paramInt1 = j + 1;
      while ((paramInt1 < n) && (paramArrayOfInt.a(paramInt1, i)))
      {
        localObject[2] += 1;
        paramInt1 += 1;
      }
      paramInt2 = paramInt1;
      if (paramInt1 == n)
      {
        f2 = NaN.0F;
        break;
      }
      while ((paramInt2 < n) && (!paramArrayOfInt.a(paramInt2, i)) && (localObject[3] < m))
      {
        localObject[3] += 1;
        paramInt2 += 1;
      }
      if ((paramInt2 == n) || (localObject[3] >= m))
      {
        f2 = NaN.0F;
        break;
      }
      while ((paramInt2 < n) && (paramArrayOfInt.a(paramInt2, i)) && (localObject[4] < m))
      {
        localObject[4] += 1;
        paramInt2 += 1;
      }
      if (localObject[4] >= m)
      {
        f2 = NaN.0F;
        break;
      }
      if (Math.abs(localObject[0] + localObject[1] + localObject[2] + localObject[3] + localObject[4] - k) * 5 >= k)
      {
        f2 = NaN.0F;
        break;
      }
      if (a((int[])localObject))
      {
        f2 = a((int[])localObject, paramInt2);
        break;
      }
      f2 = NaN.0F;
      break;
      paramInt1 += 1;
      break label579;
      return false;
    }
  }
  
  private int[] a()
  {
    this.d[0] = 0;
    this.d[1] = 0;
    this.d[2] = 0;
    this.d[3] = 0;
    this.d[4] = 0;
    return this.d;
  }
  
  private boolean b()
  {
    int k = this.b.size();
    int j = 0;
    float f1 = 0.0F;
    int i = 0;
    if (j < k)
    {
      ds localds = (ds)this.b.elementAt(j);
      if (localds.d() < 2) {
        break label145;
      }
      f1 = localds.c() + f1;
      i += 1;
    }
    label145:
    for (;;)
    {
      j += 1;
      break;
      if (i < 3) {
        return false;
      }
      float f3 = f1 / k;
      float f2 = 0.0F;
      i = 0;
      while (i < k)
      {
        float f4 = Math.abs(((ds)this.b.elementAt(i)).c() - f3);
        i += 1;
        f2 = f4 + f2;
      }
      return f2 <= 0.05F * f1;
    }
  }
  
  final du a(Hashtable paramHashtable)
    throws y
  {
    int i1;
    int i2;
    int j;
    if ((paramHashtable != null) && (paramHashtable.containsKey(u.d)))
    {
      i = 1;
      i1 = this.a.b;
      i2 = this.a.a;
      j = i1 * 3 / 228;
      if ((j >= 3) && (i == 0)) {
        break label981;
      }
    }
    label120:
    label175:
    label237:
    label271:
    label291:
    label374:
    label416:
    label456:
    label496:
    label517:
    label978:
    label981:
    for (int i = 3;; i = j)
    {
      boolean bool1 = false;
      int[] arrayOfInt = new int[5];
      int k = i - 1;
      int m = i;
      ds localds;
      if ((k < i1) && (!bool1))
      {
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        arrayOfInt[2] = 0;
        arrayOfInt[3] = 0;
        arrayOfInt[4] = 0;
        i = 0;
        j = 0;
        if (j < i2)
        {
          if (this.a.a(j, k))
          {
            int n = i;
            if ((i & 0x1) == 1) {
              n = i + 1;
            }
            arrayOfInt[n] += 1;
            i = n;
          }
          for (;;)
          {
            j += 1;
            break label120;
            i = 0;
            break;
            if ((i & 0x1) != 0) {
              break label517;
            }
            if (i != 4) {
              break label496;
            }
            if (!a(arrayOfInt)) {
              break label456;
            }
            if (!a(arrayOfInt, k, j)) {
              break label416;
            }
            if (!this.c) {
              break label271;
            }
            bool1 = b();
            arrayOfInt[0] = 0;
            arrayOfInt[1] = 0;
            arrayOfInt[2] = 0;
            arrayOfInt[3] = 0;
            arrayOfInt[4] = 0;
            i = 0;
            m = 2;
          }
          m = this.b.size();
          if (m > 1)
          {
            paramHashtable = null;
            i = 0;
            if (i < m)
            {
              localds = (ds)this.b.elementAt(i);
              if (localds.d() < 2) {
                break label978;
              }
              if (paramHashtable == null) {
                paramHashtable = localds;
              }
            }
          }
        }
      }
      for (;;)
      {
        i += 1;
        break label291;
        this.c = true;
        i = (int)(Math.abs(paramHashtable.a() - localds.a()) - Math.abs(paramHashtable.b() - localds.b())) / 2;
        if (i > arrayOfInt[2])
        {
          i = k + (i - arrayOfInt[2] - 2);
          j = i2 - 1;
        }
        for (;;)
        {
          k = i;
          break label237;
          i = 0;
          break label374;
          arrayOfInt[0] = arrayOfInt[2];
          arrayOfInt[1] = arrayOfInt[3];
          arrayOfInt[2] = arrayOfInt[4];
          arrayOfInt[3] = 1;
          arrayOfInt[4] = 0;
          i = 3;
          break label175;
          arrayOfInt[0] = arrayOfInt[2];
          arrayOfInt[1] = arrayOfInt[3];
          arrayOfInt[2] = arrayOfInt[4];
          arrayOfInt[3] = 1;
          arrayOfInt[4] = 0;
          i = 3;
          break label175;
          i += 1;
          arrayOfInt[i] += 1;
          break label175;
          arrayOfInt[i] += 1;
          break label175;
          i = m;
          boolean bool2 = bool1;
          if (a(arrayOfInt))
          {
            i = m;
            bool2 = bool1;
            if (a(arrayOfInt, k, i2))
            {
              j = arrayOfInt[0];
              i = j;
              bool2 = bool1;
              if (this.c)
              {
                bool2 = b();
                i = j;
              }
            }
          }
          k += i;
          m = i;
          bool1 = bool2;
          break;
          j = this.b.size();
          if (j < 3) {
            throw y.a();
          }
          float f1;
          if (j > 3)
          {
            float f2 = 0.0F;
            f1 = 0.0F;
            i = 0;
            while (i < j)
            {
              float f3 = ((ds)this.b.elementAt(i)).c();
              f2 += f3;
              f1 += f3 * f3;
              i += 1;
            }
            f2 /= j;
            f1 = (float)Math.sqrt(f1 / j - f2 * f2);
            an.a(this.b, new b(f2, (byte)0));
            f1 = Math.max(0.2F * f2, f1);
            for (i = 0; (i < this.b.size()) && (this.b.size() > 3); i = j + 1)
            {
              j = i;
              if (Math.abs(((ds)this.b.elementAt(i)).c() - f2) > f1)
              {
                this.b.removeElementAt(i);
                j = i - 1;
              }
            }
          }
          if (this.b.size() > 3)
          {
            f1 = 0.0F;
            i = 0;
            while (i < this.b.size())
            {
              f1 += ((ds)this.b.elementAt(i)).c();
              i += 1;
            }
            f1 /= this.b.size();
            an.a(this.b, new a(f1, (byte)0));
            this.b.setSize(3);
          }
          paramHashtable = new ds[3];
          paramHashtable[0] = ((ds)this.b.elementAt(0));
          paramHashtable[1] = ((ds)this.b.elementAt(1));
          paramHashtable[2] = ((ds)this.b.elementAt(2));
          ad.a(paramHashtable);
          return new du(paramHashtable);
          i = k;
        }
      }
    }
  }
  
  private static final class a
    implements ao
  {
    private final float a;
    
    private a(float paramFloat)
    {
      this.a = paramFloat;
    }
    
    public final int a(Object paramObject1, Object paramObject2)
    {
      if (((ds)paramObject2).d() == ((ds)paramObject1).d())
      {
        float f1 = Math.abs(((ds)paramObject2).c() - this.a);
        float f2 = Math.abs(((ds)paramObject1).c() - this.a);
        if (f1 < f2) {
          return 1;
        }
        if (f1 == f2) {
          return 0;
        }
        return -1;
      }
      return ((ds)paramObject2).d() - ((ds)paramObject1).d();
    }
  }
  
  private static final class b
    implements ao
  {
    private final float a;
    
    private b(float paramFloat)
    {
      this.a = paramFloat;
    }
    
    public final int a(Object paramObject1, Object paramObject2)
    {
      float f1 = Math.abs(((ds)paramObject2).c() - this.a);
      float f2 = Math.abs(((ds)paramObject1).c() - this.a);
      if (f1 < f2) {
        return -1;
      }
      if (f1 == f2) {
        return 0;
      }
      return 1;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */