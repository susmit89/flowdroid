package RLSDK;

public abstract class cq
{
  protected final aj a;
  protected final cz b;
  
  cq(aj paramaj)
  {
    this.a = paramaj;
    this.b = new cz(paramaj);
  }
  
  public static cq a(aj paramaj)
  {
    if (paramaj.a(1)) {
      return new cn(paramaj);
    }
    if (!paramaj.a(2)) {
      return new cr(paramaj);
    }
    switch (cz.a(paramaj, 1, 4))
    {
    default: 
      switch (cz.a(paramaj, 1, 5))
      {
      default: 
        switch (cz.a(paramaj, 1, 7))
        {
        default: 
          throw new IllegalStateException("unknown decoder: " + paramaj);
        }
        break;
      }
    case 4: 
      return new ch(paramaj);
    }
    return new ci(paramaj);
    return new cj(paramaj);
    return new ck(paramaj);
    return new cl(paramaj, "310", "11");
    return new cl(paramaj, "320", "11");
    return new cl(paramaj, "310", "13");
    return new cl(paramaj, "320", "13");
    return new cl(paramaj, "310", "15");
    return new cl(paramaj, "320", "15");
    return new cl(paramaj, "310", "17");
    return new cl(paramaj, "320", "17");
  }
  
  public abstract String a()
    throws y;
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */