package RLSDK;

public final class u
{
  public static final u a = new u();
  public static final u b = new u();
  public static final u c = new u();
  public static final u d = new u();
  public static final u e = new u();
  public static final u f = new u();
  public static final u g = new u();
  public static final u h = new u();
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */