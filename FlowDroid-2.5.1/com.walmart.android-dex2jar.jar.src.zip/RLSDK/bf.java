package RLSDK;

final class bf
{
  private final int a;
  private final byte[] b;
  
  private bf(int paramInt, byte[] paramArrayOfByte)
  {
    this.a = paramInt;
    this.b = paramArrayOfByte;
  }
  
  static bf[] a(byte[] paramArrayOfByte, bi parambi)
  {
    bi.b localb = parambi.g();
    bi.a[] arrayOfa = localb.b();
    int i = 0;
    int j = 0;
    while (i < arrayOfa.length)
    {
      j += arrayOfa[i].a();
      i += 1;
    }
    bf[] arrayOfbf = new bf[j];
    j = 0;
    i = 0;
    int m;
    while (j < arrayOfa.length)
    {
      bi.a locala = arrayOfa[j];
      k = 0;
      while (k < locala.a())
      {
        m = locala.b();
        arrayOfbf[i] = new bf(m, new byte[localb.a() + m]);
        k += 1;
        i += 1;
      }
      j += 1;
    }
    int i1 = arrayOfbf[0].b.length - localb.a();
    int k = 0;
    j = 0;
    while (k < i1 - 1)
    {
      m = 0;
      while (m < i)
      {
        arrayOfbf[m].b[k] = paramArrayOfByte[j];
        m += 1;
        j += 1;
      }
      k += 1;
    }
    if (parambi.a() == 24)
    {
      m = 1;
      if (m == 0) {
        break label268;
      }
    }
    int n;
    label268:
    for (k = 8;; k = i)
    {
      n = 0;
      while (n < k)
      {
        arrayOfbf[n].b[(i1 - 1)] = paramArrayOfByte[j];
        n += 1;
        j += 1;
      }
      m = 0;
      break;
    }
    int i2 = arrayOfbf[0].b.length;
    k = j;
    j = i1;
    while (j < i2)
    {
      n = 0;
      if (n < i)
      {
        if ((m != 0) && (n > 7)) {}
        for (i1 = j - 1;; i1 = j)
        {
          arrayOfbf[n].b[i1] = paramArrayOfByte[k];
          k += 1;
          n += 1;
          break;
        }
      }
      j += 1;
    }
    if (k != paramArrayOfByte.length) {
      throw new IllegalArgumentException();
    }
    return arrayOfbf;
  }
  
  final int a()
  {
    return this.a;
  }
  
  final byte[] b()
  {
    return this.b;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */