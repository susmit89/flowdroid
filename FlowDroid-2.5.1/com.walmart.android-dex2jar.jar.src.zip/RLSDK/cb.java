package RLSDK;

public final class cb
{
  private final int a;
  private final int[] b;
  private final ad[] c;
  
  public cb(int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3, int paramInt4)
  {
    this.a = paramInt1;
    this.b = paramArrayOfInt;
    this.c = new ad[] { new ad(paramInt2, paramInt4), new ad(paramInt3, paramInt4) };
  }
  
  public final int a()
  {
    return this.a;
  }
  
  public final int[] b()
  {
    return this.b;
  }
  
  public final ad[] c()
  {
    return this.c;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */