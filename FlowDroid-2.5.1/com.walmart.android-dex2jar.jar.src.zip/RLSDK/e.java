package RLSDK;

import java.io.IOException;

public final class e
  extends IOException
{
  public e(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */