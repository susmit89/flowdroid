package RLSDK;

abstract class di
{
  private static final di[] a = { new a(0), new b(0), new c(0), new d(0), new e(0), new f(0), new g(0), new h(0) };
  
  static di a(int paramInt)
  {
    if ((paramInt < 0) || (paramInt > 7)) {
      throw new IllegalArgumentException();
    }
    return a[paramInt];
  }
  
  final void a(ak paramak, int paramInt)
  {
    int i = 0;
    while (i < paramInt)
    {
      int j = 0;
      while (j < paramInt)
      {
        if (a(i, j))
        {
          int k = paramak.c * i + (j >> 5);
          int[] arrayOfInt = paramak.d;
          arrayOfInt[k] ^= 1 << (j & 0x1F);
        }
        j += 1;
      }
      i += 1;
    }
  }
  
  abstract boolean a(int paramInt1, int paramInt2);
  
  private static final class a
    extends di
  {
    private a()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      return (paramInt1 + paramInt2 & 0x1) == 0;
    }
  }
  
  private static final class b
    extends di
  {
    private b()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      return (paramInt1 & 0x1) == 0;
    }
  }
  
  private static final class c
    extends di
  {
    private c()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      return paramInt2 % 3 == 0;
    }
  }
  
  private static final class d
    extends di
  {
    private d()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      return (paramInt1 + paramInt2) % 3 == 0;
    }
  }
  
  private static final class e
    extends di
  {
    private e()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      return ((paramInt1 >>> 1) + paramInt2 / 3 & 0x1) == 0;
    }
  }
  
  private static final class f
    extends di
  {
    private f()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      paramInt1 *= paramInt2;
      return paramInt1 % 3 + (paramInt1 & 0x1) == 0;
    }
  }
  
  private static final class g
    extends di
  {
    private g()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      paramInt1 *= paramInt2;
      return (paramInt1 % 3 + (paramInt1 & 0x1) & 0x1) == 0;
    }
  }
  
  private static final class h
    extends di
  {
    private h()
    {
      super();
    }
    
    final boolean a(int paramInt1, int paramInt2)
    {
      return ((paramInt1 + paramInt2 & 0x1) + paramInt1 * paramInt2 % 3 & 0x1) == 0;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/di.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */