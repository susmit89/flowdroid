package RLSDK;

public final class v
  extends aa
{
  private static final v a = new v();
  
  public static v a()
  {
    return a;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */