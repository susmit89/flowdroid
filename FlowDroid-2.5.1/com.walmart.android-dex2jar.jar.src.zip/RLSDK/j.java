package RLSDK;

import android.app.Application;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.Camera;
import android.hardware.Camera.Area;
import android.hardware.Camera.Parameters;
import java.util.ArrayList;
import java.util.List;

public class j
  extends i
{
  protected j(Application paramApplication)
  {
    super(paramApplication);
  }
  
  public void onTapEvent(int paramInt1, int paramInt2)
  {
    if (this.camera == null) {}
    Object localObject1;
    do
    {
      return;
      localObject1 = this.camera.getParameters();
    } while (((Camera.Parameters)localObject1).getMaxNumFocusAreas() <= 0);
    Object localObject3 = new Matrix();
    this.cameraToPreviewMatrix.invert((Matrix)localObject3);
    Object localObject2 = new RectF(paramInt1, paramInt2, paramInt1 + 1, paramInt2 + 1);
    ((Matrix)localObject3).mapRect((RectF)localObject2);
    localObject3 = this.configManager.a();
    paramInt1 = (int)(((RectF)localObject2).left * 2000.0F / ((Point)localObject3).x) - 1000;
    paramInt2 = (int)(((RectF)localObject2).top * 2000.0F / ((Point)localObject3).y) - 1000;
    localObject2 = new Rect(paramInt1 - 50, paramInt2 - 50, paramInt1 + 50, paramInt2 + 50);
    if (((Rect)localObject2).intersect(64536, 64536, 1000, 1000))
    {
      localObject2 = new Camera.Area((Rect)localObject2, 1000);
      localObject3 = new ArrayList();
      ((List)localObject3).add(localObject2);
      ((Camera.Parameters)localObject1).setFocusAreas((List)localObject3);
    }
    try
    {
      this.camera.setParameters((Camera.Parameters)localObject1);
      localObject1 = TAG;
      new StringBuilder("Focusing on point ").append(paramInt1).append(",").append(paramInt2).append(" in camera.area coords.").toString();
      return;
    }
    catch (RuntimeException localRuntimeException)
    {
      for (;;) {}
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */