package RLSDK;

import android.os.Handler;
import android.os.Message;
import com.ebay.redlasersdk.BarcodeResult;
import com.ebay.redlasersdk.recognizers.BarcodeResultInternal;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

final class m
  extends Handler
{
  private static byte[] g = null;
  private boolean a = false;
  private HashSet<BarcodeResultInternal> b = new HashSet();
  private HashSet<BarcodeResultInternal> c = new HashSet();
  private boolean d = false;
  private int e = 0;
  private BarcodeResultInternal f = null;
  
  private void a(int paramInt)
  {
    if (paramInt > 80) {}
    for (;;)
    {
      try
      {
        this.e += 2;
        if (this.e > 30) {
          this.e = 30;
        }
        if (this.b.size() > 0) {
          this.e = 0;
        }
        return;
      }
      finally {}
      this.e -= 1;
      if (this.e < 0) {
        this.e = 0;
      }
    }
  }
  
  private void a(BarcodeResultInternal paramBarcodeResultInternal)
  {
    label131:
    for (;;)
    {
      try
      {
        if (paramBarcodeResultInternal.isPartialBarcode)
        {
          int i = 0;
          Iterator localIterator = this.b.iterator();
          if (localIterator.hasNext())
          {
            BarcodeResultInternal localBarcodeResultInternal = (BarcodeResultInternal)localIterator.next();
            if (localBarcodeResultInternal.barcodeType != paramBarcodeResultInternal.barcodeType) {
              break label131;
            }
            boolean bool = localBarcodeResultInternal.barcodeString.startsWith(paramBarcodeResultInternal.barcodeString);
            if (!bool) {
              break label131;
            }
            i = 1;
            continue;
          }
          if (i == 0) {}
        }
        else
        {
          return;
        }
        if (this.f == null)
        {
          this.f = paramBarcodeResultInternal;
          continue;
        }
        if (paramBarcodeResultInternal.barcodeString.length() <= this.f.barcodeString.length()) {
          continue;
        }
      }
      finally {}
      this.f = paramBarcodeResultInternal;
    }
  }
  
  private void a(boolean paramBoolean)
  {
    try
    {
      this.d = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  final HashMap<String, Object> a()
  {
    HashSet localHashSet2;
    try
    {
      HashMap localHashMap = new HashMap();
      HashSet localHashSet1 = new HashSet();
      localHashSet2 = new HashSet();
      Iterator localIterator = this.b.iterator();
      while (localIterator.hasNext())
      {
        BarcodeResultInternal localBarcodeResultInternal = new BarcodeResultInternal((BarcodeResultInternal)localIterator.next());
        localHashSet1.add(localBarcodeResultInternal);
        if (this.c.contains(localBarcodeResultInternal)) {
          localHashSet2.add(localBarcodeResultInternal);
        }
      }
      localHashMap1.put("FoundBarcodes", localHashSet1);
    }
    finally {}
    localHashMap1.put("NewFoundBarcodes", localHashSet2);
    localHashMap1.put("InRange", Boolean.valueOf(this.d));
    if (this.f != null)
    {
      localHashMap1.put("PartialBarcode", new BarcodeResultInternal(this.f));
      localHashMap1.put("Guidance", Integer.valueOf(2));
      if (g == null) {
        break label218;
      }
      localHashMap1.put("CameraSnapshot", g);
      g = null;
    }
    for (;;)
    {
      this.c.clear();
      return localHashMap1;
      if (this.e <= 15) {
        break;
      }
      localHashMap1.put("Guidance", Integer.valueOf(1));
      break;
      label218:
      localHashMap1.remove("CameraSnapshot");
    }
  }
  
  final void a(byte[] paramArrayOfByte)
  {
    try
    {
      g = paramArrayOfByte;
      return;
    }
    finally
    {
      paramArrayOfByte = finally;
      throw paramArrayOfByte;
    }
  }
  
  final void a(BarcodeResultInternal[] paramArrayOfBarcodeResultInternal)
  {
    if (paramArrayOfBarcodeResultInternal == null) {}
    int i;
    Object localObject2;
    for (;;)
    {
      return;
      i = 0;
      try
      {
        if (i < paramArrayOfBarcodeResultInternal.length)
        {
          if (this.b.contains(paramArrayOfBarcodeResultInternal[i]))
          {
            localObject1 = this.b.iterator();
            while (((Iterator)localObject1).hasNext())
            {
              localObject2 = (BarcodeResultInternal)((Iterator)localObject1).next();
              if (paramArrayOfBarcodeResultInternal[i].equals(localObject2))
              {
                ((BarcodeResultInternal)localObject2).barcodeLocation = paramArrayOfBarcodeResultInternal[i].barcodeLocation;
                ((BarcodeResultInternal)localObject2).mostRecentScanTime = new Date();
                ((BarcodeResultInternal)localObject2).recognizeCount += paramArrayOfBarcodeResultInternal[i].recognizeCount;
                ((BarcodeResultInternal)localObject2).recognizedBy |= paramArrayOfBarcodeResultInternal[i].recognizedBy;
              }
            }
          }
          paramArrayOfBarcodeResultInternal[i].mostRecentScanTime = new Date();
        }
      }
      finally {}
    }
    this.b.add(paramArrayOfBarcodeResultInternal[i]);
    this.c.add(paramArrayOfBarcodeResultInternal[i]);
    new StringBuilder("Recognized ").append(paramArrayOfBarcodeResultInternal[i].barcodeString).toString();
    c.a(paramArrayOfBarcodeResultInternal[i]);
    if ((this.f != null) && (paramArrayOfBarcodeResultInternal[i].barcodeType == this.f.barcodeType) && (paramArrayOfBarcodeResultInternal[i].barcodeString.startsWith(this.f.barcodeString))) {
      this.f = null;
    }
    Object localObject1 = paramArrayOfBarcodeResultInternal[i].associatedBarcode;
    int j;
    if (localObject1 != null)
    {
      j = 0;
      if (j >= paramArrayOfBarcodeResultInternal.length) {
        break label369;
      }
      if (localObject1 != paramArrayOfBarcodeResultInternal[j].uniqueID) {}
    }
    label369:
    for (localObject1 = paramArrayOfBarcodeResultInternal[j];; localObject1 = null)
    {
      localObject2 = this.b.iterator();
      for (;;)
      {
        if (((Iterator)localObject2).hasNext())
        {
          BarcodeResultInternal localBarcodeResultInternal = (BarcodeResultInternal)((Iterator)localObject2).next();
          if ((localBarcodeResultInternal.barcodeType == ((BarcodeResult)localObject1).barcodeType) && (localBarcodeResultInternal.barcodeString.equals(((BarcodeResult)localObject1).barcodeString)))
          {
            paramArrayOfBarcodeResultInternal[i].AssociateWith(localBarcodeResultInternal);
            continue;
            j += 1;
            break;
          }
        }
      }
      i += 1;
      break;
    }
  }
  
  final void b()
  {
    this.a = true;
  }
  
  public final void handleMessage(Message paramMessage)
  {
    if (!this.a) {}
    switch (paramMessage.what)
    {
    default: 
      return;
    case 7877121: 
      paramMessage = (d.a)paramMessage.obj;
      g.get().addCallbackBuffer(paramMessage.a);
      return;
    case 7877122: 
      a((BarcodeResultInternal[])paramMessage.obj);
      return;
    case 7877123: 
      a((BarcodeResultInternal)paramMessage.obj);
      return;
    case 7751744: 
      a(true);
      return;
    case 7751745: 
      a(false);
      return;
    }
    a(((Integer)paramMessage.obj).intValue());
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */