package RLSDK;

import java.util.Hashtable;

public final class bd
  implements z
{
  private static final ad[] a = new ad[0];
  private final bh b = new bh();
  
  public final ab a(s params, Hashtable paramHashtable)
    throws y, t, v
  {
    if ((paramHashtable != null) && (paramHashtable.containsKey(u.b)))
    {
      params = params.c();
      paramHashtable = params.a();
      int[] arrayOfInt = params.b();
      if ((paramHashtable == null) || (arrayOfInt == null)) {
        throw y.a();
      }
      int j = params.a;
      int i = paramHashtable[0];
      int k = paramHashtable[1];
      while ((i < j) && (params.a(i, k))) {
        i += 1;
      }
      if (i == j) {
        throw y.a();
      }
      k = i - paramHashtable[0];
      if (k == 0) {
        throw y.a();
      }
      int m = paramHashtable[1];
      i = arrayOfInt[1];
      int n = paramHashtable[0];
      int i1 = (arrayOfInt[0] - n + 1) / k;
      int i2 = (i - m + 1) / k;
      if ((i1 == 0) || (i2 == 0)) {
        throw y.a();
      }
      int i3 = k >> 1;
      paramHashtable = new ak(i1, i2);
      i = 0;
      while (i < i2)
      {
        j = 0;
        while (j < i1)
        {
          if (params.a(j * k + (i3 + n), m + i3 + i * k)) {
            paramHashtable.b(j, i);
          }
          j += 1;
        }
        i += 1;
      }
      params = this.b.a(paramHashtable);
    }
    for (paramHashtable = a;; paramHashtable = paramHashtable.e())
    {
      paramHashtable = new ab(params.b(), params.a(), paramHashtable, q.f);
      if (params.c() != null) {
        paramHashtable.a(ac.c, params.c());
      }
      if (params.d() != null) {
        paramHashtable.a(ac.d, params.d().toString());
      }
      return paramHashtable;
      paramHashtable = new bj(params.c()).a();
      params = this.b.a(paramHashtable.d());
    }
  }
  
  public final void a() {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */