package RLSDK;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;

public final class a
{
  private Context a;
  
  public a(Context paramContext)
  {
    this.a = paramContext;
  }
  
  public static String a(InputStream paramInputStream)
  {
    StringWriter localStringWriter;
    if (paramInputStream != null)
    {
      localStringWriter = new StringWriter();
      char[] arrayOfChar = new char['Ѐ'];
      try
      {
        paramInputStream = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
        for (;;)
        {
          int i = paramInputStream.read(arrayOfChar);
          if (i == -1) {
            break;
          }
          localStringWriter.write(arrayOfChar, 0, i);
        }
        return null;
      }
      catch (Exception paramInputStream)
      {
        paramInputStream.getMessage();
      }
    }
    paramInputStream = localStringWriter.toString();
    return paramInputStream;
  }
  
  public final InputStream a(String paramString)
    throws MalformedURLException, IOException
  {
    int k = 0;
    Object localObject = (ConnectivityManager)this.a.getSystemService("connectivity");
    int j = k;
    int i;
    if (localObject != null)
    {
      localObject = ((ConnectivityManager)localObject).getAllNetworkInfo();
      j = k;
      if (localObject != null) {
        i = 0;
      }
    }
    for (;;)
    {
      j = k;
      if (i < localObject.length)
      {
        if (localObject[i].getState() == NetworkInfo.State.CONNECTED) {
          j = 1;
        }
      }
      else {
        if (j == 0) {
          break;
        }
      }
      try
      {
        localObject = (InputStream)new URL(paramString).getContent();
        return (InputStream)localObject;
      }
      catch (IOException localIOException)
      {
        new StringBuilder("IOException reading from ").append(paramString).toString();
      }
      i += 1;
    }
    return null;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */