package RLSDK;

import java.util.Hashtable;

public final class ag
  implements z
{
  public final ab a(s params, Hashtable paramHashtable)
    throws y, v
  {
    af localaf = new ai(params.c()).a();
    params = localaf.e();
    if ((paramHashtable != null) && (localaf.e() != null))
    {
      paramHashtable = (ae)paramHashtable.get(u.h);
      if (paramHashtable != null)
      {
        int i = 0;
        while (i < localaf.e().length)
        {
          paramHashtable.a(localaf.e()[i]);
          i += 1;
        }
      }
    }
    paramHashtable = new ah().a(localaf);
    params = new ab(paramHashtable.b(), paramHashtable.a(), params, q.a);
    if (paramHashtable.c() != null) {
      params.a(ac.c, paramHashtable.c());
    }
    if (paramHashtable.d() != null) {
      params.a(ac.d, paramHashtable.d().toString());
    }
    return params;
  }
  
  public final void a() {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */