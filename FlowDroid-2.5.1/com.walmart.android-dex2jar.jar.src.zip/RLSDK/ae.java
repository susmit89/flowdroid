package RLSDK;

public abstract interface ae
{
  public abstract void a(ad paramad);
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */