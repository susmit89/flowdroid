package RLSDK;

final class cv
  extends cx
{
  private final String b;
  private final int c;
  private final boolean d;
  
  cv(int paramInt, String paramString)
  {
    super(paramInt);
    this.b = paramString;
    this.d = false;
    this.c = 0;
  }
  
  cv(int paramInt1, String paramString, int paramInt2)
  {
    super(paramInt1);
    this.d = true;
    this.c = paramInt2;
    this.b = paramString;
  }
  
  final String a()
  {
    return this.b;
  }
  
  final boolean b()
  {
    return this.d;
  }
  
  final int c()
  {
    return this.c;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */