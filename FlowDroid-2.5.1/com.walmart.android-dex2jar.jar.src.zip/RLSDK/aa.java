package RLSDK;

public abstract class aa
  extends Exception
{
  public final Throwable fillInStackTrace()
  {
    return null;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */