package RLSDK;

final class cs
{
  private final cv a;
  private final boolean b;
  
  cs()
  {
    this.b = true;
    this.a = null;
  }
  
  cs(byte paramByte)
  {
    this.b = false;
    this.a = null;
  }
  
  cs(cv paramcv)
  {
    this.b = true;
    this.a = paramcv;
  }
  
  final cv a()
  {
    return this.a;
  }
  
  final boolean b()
  {
    return this.b;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */