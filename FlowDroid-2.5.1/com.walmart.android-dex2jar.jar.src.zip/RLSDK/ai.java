package RLSDK;

public final class ai
{
  private final ak a;
  private boolean b;
  private int c;
  private int d;
  private int e;
  private int f;
  
  public ai(ak paramak)
  {
    this.a = paramak;
  }
  
  private int a(a parama1, a parama2)
  {
    float f3 = b(parama1, parama2);
    float f4 = (parama2.a - parama1.a) / f3;
    float f5 = (parama2.b - parama1.b) / f3;
    float f1 = parama1.a;
    float f2 = parama1.b;
    boolean bool = this.a.a(parama1.a, parama1.b);
    int j = 0;
    int i = 0;
    while (i < f3)
    {
      f1 += f4;
      f2 += f5;
      int k = j;
      if (this.a.a((int)(0.5F + f1), (int)(0.5F + f2)) != bool) {
        k = j + 1;
      }
      i += 1;
      j = k;
    }
    f1 = j / f3;
    if ((f1 > 0.1D) && (f1 < 0.9D)) {
      return 0;
    }
    if (f1 <= 0.1D)
    {
      if (bool) {
        return 1;
      }
      return -1;
    }
    if (bool) {
      return -1;
    }
    return 1;
  }
  
  private a a(a parama, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    int j = parama.a + paramInt1;
    int i = parama.b + paramInt2;
    while ((a(j, i)) && (this.a.a(j, i) == paramBoolean))
    {
      j += paramInt1;
      i += paramInt2;
    }
    int k = j - paramInt1;
    j = i - paramInt2;
    i = k;
    while ((a(i, j)) && (this.a.a(i, j) == paramBoolean)) {
      i += paramInt1;
    }
    i -= paramInt1;
    paramInt1 = j;
    while ((a(i, paramInt1)) && (this.a.a(i, paramInt1) == paramBoolean)) {
      paramInt1 += paramInt2;
    }
    return new a(i, paramInt1 - paramInt2, (byte)0);
  }
  
  private boolean a(int paramInt1, int paramInt2)
  {
    return (paramInt1 >= 0) && (paramInt1 < this.a.a) && (paramInt2 > 0) && (paramInt2 < this.a.b);
  }
  
  private boolean[] a(a parama1, a parama2, int paramInt)
  {
    boolean[] arrayOfBoolean = new boolean[paramInt];
    float f1 = b(parama1, parama2);
    float f2 = f1 / (paramInt - 1);
    float f3 = (parama2.a - parama1.a) * f2 / f1;
    float f4 = f2 * (parama2.b - parama1.b) / f1;
    f2 = parama1.a;
    f1 = parama1.b;
    int i = 0;
    while (i < paramInt)
    {
      arrayOfBoolean[i] = this.a.a((int)(f2 + 0.5F), (int)(f1 + 0.5F));
      f2 += f3;
      f1 += f4;
      i += 1;
    }
    return arrayOfBoolean;
  }
  
  private static float b(a parama1, a parama2)
  {
    return (float)Math.sqrt((parama1.a - parama2.a) * (parama1.a - parama2.a) + (parama1.b - parama2.b) * (parama1.b - parama2.b));
  }
  
  private a b()
  {
    try
    {
      localObject = new ay(this.a).a();
      localad5 = localObject[0];
      localad4 = localObject[1];
      localad3 = localObject[2];
      localObject = localObject[3];
    }
    catch (y localy1)
    {
      for (;;)
      {
        Object localObject;
        float f1;
        i = this.a.a / 2;
        j = this.a.b / 2;
        localad5 = a(new a(i + 7, j - 7, (byte)0), false, 1, -1).a();
        localad4 = a(new a(i + 7, j + 7, (byte)0), false, 1, 1).a();
        localad3 = a(new a(i - 7, j + 7, (byte)0), false, -1, 1).a();
        localad1 = a(new a(i - 7, j - 7, (byte)0), false, -1, -1).a();
      }
    }
    i = (int)((localad5.a() + ((ad)localObject).a() + localad4.a() + localad3.a()) / 4.0F + 0.5F);
    f1 = localad5.b();
    j = (int)((((ad)localObject).b() + f1 + localad4.b() + localad3.b()) / 4.0F + 0.5F);
    try
    {
      localObject = new ay(this.a, i, j).a();
      localad5 = localObject[0];
      localad4 = localObject[1];
      localad3 = localObject[2];
      localObject = localObject[3];
    }
    catch (y localy2)
    {
      for (;;)
      {
        ad localad1;
        localad5 = a(new a(i + 7, j - 7, (byte)0), false, 1, -1).a();
        localad4 = a(new a(i + 7, j + 7, (byte)0), false, 1, 1).a();
        localad3 = a(new a(i - 7, j + 7, (byte)0), false, -1, 1).a();
        ad localad2 = a(new a(i - 7, j - 7, (byte)0), false, -1, -1).a();
      }
    }
    i = (int)((localad5.a() + ((ad)localObject).a() + localad4.a() + localad3.a()) / 4.0F + 0.5F);
    f1 = localad5.b();
    return new a(i, (int)((((ad)localObject).b() + f1 + localad4.b() + localad3.b()) / 4.0F + 0.5F), (byte)0);
  }
  
  public final af a()
    throws y
  {
    Object localObject1 = b();
    boolean bool = true;
    this.e = 1;
    Object localObject2 = localObject1;
    Object localObject3 = localObject1;
    Object localObject4 = localObject1;
    float f1;
    if (this.e < 9)
    {
      localObject5 = a((a)localObject4, bool, 1, -1);
      localObject6 = a((a)localObject3, bool, 1, 1);
      a locala1 = a((a)localObject2, bool, -1, 1);
      a locala2 = a((a)localObject1, bool, -1, -1);
      a locala4;
      a locala5;
      a locala6;
      if (this.e > 2)
      {
        f1 = b(locala2, (a)localObject5) * this.e / (b((a)localObject1, (a)localObject4) * (this.e + 2));
        if ((f1 < 0.75D) || (f1 > 1.25D)) {
          break label375;
        }
        a locala3 = new a(((a)localObject5).a - 3, ((a)localObject5).b + 3, (byte)0);
        locala4 = new a(((a)localObject6).a - 3, ((a)localObject6).b - 3, (byte)0);
        locala5 = new a(locala1.a + 3, locala1.b - 3, (byte)0);
        locala6 = new a(locala2.a + 3, locala2.b + 3, (byte)0);
        i = a(locala6, locala3);
        if (i == 0) {
          break label364;
        }
        j = a(locala3, locala4);
        if ((j != i) || (j == 0))
        {
          i = 0;
          label271:
          if (i == 0) {
            break label375;
          }
        }
      }
      else
      {
        if (bool) {
          break label369;
        }
      }
      label364:
      label369:
      for (bool = true;; bool = false)
      {
        this.e += 1;
        localObject1 = locala2;
        localObject2 = locala1;
        localObject3 = localObject6;
        localObject4 = localObject5;
        break;
        j = a(locala4, locala5);
        if ((j != i) || (j == 0))
        {
          i = 0;
          break label271;
        }
        j = a(locala5, locala6);
        if ((j == i) && (j != 0))
        {
          i = 1;
          break label271;
        }
        i = 0;
        break label271;
      }
    }
    label375:
    if ((this.e != 5) && (this.e != 7)) {
      throw y.a();
    }
    if (this.e == 5) {}
    int m;
    float f2;
    int i3;
    int i2;
    int n;
    int i1;
    for (bool = true;; bool = false)
    {
      this.b = bool;
      f1 = 1.5F / (this.e * 2 - 3);
      k = ((a)localObject4).a - ((a)localObject2).a;
      m = ((a)localObject4).b - ((a)localObject2).b;
      i = (int)(((a)localObject2).a - k * f1 + 0.5F);
      j = (int)(((a)localObject2).b - m * f1 + 0.5F);
      f2 = ((a)localObject4).a;
      k = (int)(k * f1 + f2 + 0.5F);
      f2 = ((a)localObject4).b;
      m = (int)(m * f1 + f2 + 0.5F);
      i3 = ((a)localObject3).a - ((a)localObject1).a;
      i2 = ((a)localObject3).b - ((a)localObject1).b;
      n = (int)(((a)localObject1).a - i3 * f1 + 0.5F);
      i1 = (int)(((a)localObject1).b - i2 * f1 + 0.5F);
      f2 = ((a)localObject3).a;
      i3 = (int)(i3 * f1 + f2 + 0.5F);
      f2 = ((a)localObject3).b;
      i2 = (int)(f1 * i2 + f2 + 0.5F);
      if ((a(k, m)) && (a(i3, i2)) && (a(i, j)) && (a(n, i1))) {
        break;
      }
      throw y.a();
    }
    localObject1 = new a(k, m, (byte)0);
    localObject2 = new a(i3, i2, (byte)0);
    localObject4 = new a(i, j, (byte)0);
    Object localObject5 = new a(n, i1, (byte)0);
    localObject3 = new a[4];
    localObject3[0] = localObject1;
    localObject3[1] = localObject2;
    localObject3[2] = localObject4;
    localObject3[3] = localObject5;
    localObject1 = a(localObject3[0], localObject3[1], this.e * 2 + 1);
    localObject2 = a(localObject3[1], localObject3[2], this.e * 2 + 1);
    localObject5 = a(localObject3[2], localObject3[3], this.e * 2 + 1);
    Object localObject6 = a(localObject3[3], localObject3[0], this.e * 2 + 1);
    if ((localObject1[0] != 0) && (localObject1[(this.e * 2)] != 0)) {
      this.f = 0;
    }
    while (this.b)
    {
      localObject4 = new boolean[28];
      i = 0;
      for (;;)
      {
        if (i < 7)
        {
          localObject4[i] = localObject1[(i + 2)];
          localObject4[(i + 7)] = localObject2[(i + 2)];
          localObject4[(i + 14)] = localObject5[(i + 2)];
          localObject4[(i + 21)] = localObject6[(i + 2)];
          i += 1;
          continue;
          if ((localObject2[0] != 0) && (localObject2[(this.e * 2)] != 0))
          {
            this.f = 1;
            break;
          }
          if ((localObject5[0] != 0) && (localObject5[(this.e * 2)] != 0))
          {
            this.f = 2;
            break;
          }
          if ((localObject6[0] != 0) && (localObject6[(this.e * 2)] != 0))
          {
            this.f = 3;
            break;
          }
          throw y.a();
        }
      }
      localObject2 = new boolean[28];
      i = 0;
      for (;;)
      {
        localObject1 = localObject2;
        if (i >= 28) {
          break;
        }
        localObject2[i] = localObject4[((this.f * 7 + i) % 28)];
        i += 1;
      }
    }
    localObject4 = new boolean[40];
    int i = 0;
    while (i < 11)
    {
      if (i < 5)
      {
        localObject4[i] = localObject1[(i + 2)];
        localObject4[(i + 10)] = localObject2[(i + 2)];
        localObject4[(i + 20)] = localObject5[(i + 2)];
        localObject4[(i + 30)] = localObject6[(i + 2)];
      }
      if (i > 5)
      {
        localObject4[(i - 1)] = localObject1[(i + 2)];
        localObject4[(i + 10 - 1)] = localObject2[(i + 2)];
        localObject4[(i + 20 - 1)] = localObject5[(i + 2)];
        localObject4[(i + 30 - 1)] = localObject6[(i + 2)];
      }
      i += 1;
    }
    localObject2 = new boolean[40];
    i = 0;
    for (;;)
    {
      localObject1 = localObject2;
      if (i >= 40) {
        break;
      }
      localObject2[i] = localObject4[((this.f * 10 + i) % 40)];
      i += 1;
    }
    if (this.b)
    {
      j = 7;
      i = 2;
      localObject2 = new int[j];
      k = 0;
    }
    for (;;)
    {
      if (k >= j) {
        break label1368;
      }
      n = 1;
      m = 1;
      for (;;)
      {
        if (m <= 4)
        {
          if (localObject1[(k * 4 + 4 - m)] != 0) {
            localObject2[k] += n;
          }
          n <<= 1;
          m += 1;
          continue;
          j = 10;
          i = 4;
          break;
        }
      }
      k += 1;
    }
    for (;;)
    {
      try
      {
        label1368:
        new bb(az.d).a((int[])localObject2, j - i);
        j = 0;
        if (j >= i) {
          break;
        }
        m = 1;
        k = 1;
        if (k > 4) {
          break label1465;
        }
        if ((localObject2[j] & m) == m)
        {
          bool = true;
          localObject1[(j * 4 + 4 - k)] = bool;
          m <<= 1;
          k += 1;
          continue;
        }
        bool = false;
      }
      catch (bc localbc)
      {
        throw y.a();
      }
      continue;
      label1465:
      j += 1;
    }
    if (this.b) {
      i = 2;
    }
    for (int j = 6;; j = 11)
    {
      k = 0;
      while (k < i)
      {
        this.c <<= 1;
        if (localbc[k] != 0) {
          this.c += 1;
        }
        k += 1;
      }
      i = 5;
    }
    int k = i;
    while (k < i + j)
    {
      this.d <<= 1;
      if (localbc[k] != 0) {
        this.d += 1;
      }
      k += 1;
    }
    this.c += 1;
    this.d += 1;
    j = this.c;
    if (this.c > 4)
    {
      i = 1;
      f1 = (i + j * 2 + (this.c - 4) / 8) / (2.0F * this.e);
      j = localObject3[0].a - localObject3[2].a;
      if (j <= 0) {
        break label1989;
      }
      i = 1;
      label1677:
      m = j + i;
      j = localObject3[0].b - localObject3[2].b;
      if (j <= 0) {
        break label1994;
      }
      i = 1;
      label1707:
      i += j;
      j = (int)(localObject3[2].a - m * f1 + 0.5F);
      k = (int)(localObject3[2].b - i * f1 + 0.5F);
      f2 = localObject3[0].a;
      m = (int)(m * f1 + f2 + 0.5F);
      f2 = localObject3[0].b;
      n = (int)(i * f1 + f2 + 0.5F);
      i1 = localObject3[1].a - localObject3[3].a;
      if (i1 <= 0) {
        break label1999;
      }
      i = 1;
      label1818:
      i1 += i;
      i2 = localObject3[1].b - localObject3[3].b;
      if (i2 <= 0) {
        break label2004;
      }
    }
    label1989:
    label1994:
    label1999:
    label2004:
    for (i = 1;; i = -1)
    {
      i3 = i + i2;
      i = (int)(localObject3[3].a - i1 * f1 + 0.5F);
      i2 = (int)(localObject3[3].b - i3 * f1 + 0.5F);
      f2 = localObject3[1].a;
      i1 = (int)(i1 * f1 + f2 + 0.5F);
      f2 = localObject3[1].b;
      i3 = (int)(i3 * f1 + f2 + 0.5F);
      if ((a(m, n)) && (a(i1, i3)) && (a(j, k)) && (a(i, i2))) {
        break label2009;
      }
      throw y.a();
      i = 0;
      break;
      i = -1;
      break label1677;
      i = -1;
      break label1707;
      i = -1;
      break label1818;
    }
    label2009:
    ad[] arrayOfad = new ad[4];
    arrayOfad[0] = new ad(m, n);
    arrayOfad[1] = new ad(i1, i3);
    arrayOfad[2] = new ad(j, k);
    arrayOfad[3] = new ad(i, i2);
    localObject2 = this.a;
    localObject3 = arrayOfad[(this.f % 4)];
    localObject4 = arrayOfad[((this.f + 3) % 4)];
    localObject5 = arrayOfad[((this.f + 2) % 4)];
    localObject6 = arrayOfad[((this.f + 1) % 4)];
    if (this.b) {
      i = this.c * 4 + 11;
    }
    for (;;)
    {
      return new af(au.a().a((ak)localObject2, i, i, 0.5F, 0.5F, i - 0.5F, 0.5F, i - 0.5F, i - 0.5F, 0.5F, i - 0.5F, ((ad)localObject3).a(), ((ad)localObject3).b(), ((ad)localObject6).a(), ((ad)localObject6).b(), ((ad)localObject5).a(), ((ad)localObject5).b(), ((ad)localObject4).a(), ((ad)localObject4).b()), arrayOfad, this.b, this.d, this.c);
      if (this.c <= 4) {
        i = this.c * 4 + 15;
      } else {
        i = this.c * 4 + ((this.c - 4) / 8 + 1) * 2 + 15;
      }
    }
  }
  
  private static final class a
  {
    public final int a;
    public final int b;
    
    private a(int paramInt1, int paramInt2)
    {
      this.a = paramInt1;
      this.b = paramInt2;
    }
    
    public final ad a()
    {
      return new ad(this.a, this.b);
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */