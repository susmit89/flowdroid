package RLSDK;

public final class dd
{
  public static ap a(ak paramak)
    throws v
  {
    Object localObject = new db(paramak);
    paramak = ((db)localObject).a();
    if ((paramak == null) || (paramak.length == 0)) {
      throw v.a();
    }
    int i = 1 << ((db)localObject).c() + 1;
    localObject = ((db)localObject).b();
    if (((localObject != null) && (localObject.length > i / 2 + 3)) || (i < 0) || (i > 512)) {
      throw v.a();
    }
    if ((localObject != null) && (localObject.length > 3)) {
      throw v.a();
    }
    if (paramak.length < 4) {
      throw v.a();
    }
    int j = paramak[0];
    if (j > paramak.length) {
      throw v.a();
    }
    if (j == 0)
    {
      if (i < paramak.length) {
        paramak[0] = (paramak.length - i);
      }
    }
    else {
      return dc.a(paramak);
    }
    throw v.a();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */