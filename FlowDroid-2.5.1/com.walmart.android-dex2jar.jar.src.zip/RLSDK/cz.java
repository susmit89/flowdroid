package RLSDK;

final class cz
{
  private final aj a;
  private final ct b = new ct();
  private final StringBuffer c = new StringBuffer();
  
  cz(aj paramaj)
  {
    this.a = paramaj;
  }
  
  static int a(aj paramaj, int paramInt1, int paramInt2)
  {
    int j = 0;
    if (paramInt2 > 32) {
      throw new IllegalArgumentException("extractNumberValueFromBitArray can't handle more than 32 bits");
    }
    int i = 0;
    while (i < paramInt2)
    {
      int k = j;
      if (paramaj.a(paramInt1 + i)) {
        k = j | 1 << paramInt2 - i - 1;
      }
      i += 1;
      j = k;
    }
    return j;
  }
  
  private cs a()
  {
    int i;
    Object localObject;
    for (;;)
    {
      j = this.b.a;
      boolean bool;
      if (j + 7 > this.a.b) {
        if (j + 4 <= this.a.b)
        {
          bool = true;
          if (!bool) {
            break;
          }
          i = this.b.a;
          if (i + 7 <= this.a.b) {
            break label230;
          }
          i = a(i, 4);
          if (i != 0) {
            break label206;
          }
          localObject = new cw(this.a.b, 10, 10);
          label94:
          this.b.a = ((cw)localObject).e();
          if (!((cw)localObject).c()) {
            break label299;
          }
          if (!((cw)localObject).d()) {
            break label268;
          }
        }
      }
      label192:
      label206:
      label230:
      label268:
      for (localObject = new cv(this.b.a, this.c.toString());; localObject = new cv(this.b.a, this.c.toString(), ((cw)localObject).b()))
      {
        return new cs((cv)localObject);
        bool = false;
        break;
        i = j;
        for (;;)
        {
          if (i >= j + 3) {
            break label192;
          }
          if (this.a.a(i))
          {
            bool = true;
            break;
          }
          i += 1;
        }
        bool = this.a.a(j + 3);
        break;
        localObject = new cw(this.a.b, i - 1, 10);
        break label94;
        j = a(i, 7);
        localObject = new cw(i + 7, (j - 8) / 11, (j - 8) % 11);
        break label94;
      }
      label299:
      this.c.append(((cw)localObject).a());
      if (((cw)localObject).d()) {
        return new cs(new cv(this.b.a, this.c.toString()));
      }
      this.c.append(((cw)localObject).b());
    }
    int j = this.b.a;
    if (j + 1 > this.a.b) {
      i = 0;
    }
    for (;;)
    {
      if (i != 0)
      {
        this.b.d();
        localObject = this.b;
        ((ct)localObject).a += 4;
      }
      return new cs((byte)0);
      i = 0;
      for (;;)
      {
        if ((i >= 4) || (i + j >= this.a.b)) {
          break label471;
        }
        if (this.a.a(j + i))
        {
          i = 0;
          break;
        }
        i += 1;
      }
      label471:
      i = 1;
    }
  }
  
  private boolean a(int paramInt)
  {
    if (paramInt + 1 > this.a.b) {}
    int i;
    do
    {
      return false;
      i = 0;
      if ((i >= 5) || (i + paramInt >= this.a.b)) {
        break label75;
      }
      if (i != 2) {
        break;
      }
    } while (!this.a.a(paramInt + 2));
    while (!this.a.a(paramInt + i))
    {
      i += 1;
      break;
    }
    return false;
    label75:
    return true;
  }
  
  private cs b()
  {
    Object localObject;
    for (;;)
    {
      int i = this.b.a;
      int j;
      if (i + 5 <= this.a.b)
      {
        j = a(i, 5);
        if ((j >= 5) && (j < 16))
        {
          i = 1;
          if (i == 0) {
            break;
          }
          i = this.b.a;
          j = a(i, 5);
          if (j != 15) {
            break label211;
          }
          localObject = new cu(i + 5, '$');
        }
      }
      for (;;)
      {
        this.b.a = ((cu)localObject).e();
        if (!((cu)localObject).b()) {
          break label801;
        }
        return new cs(new cv(this.b.a, this.c.toString()));
        if (i + 7 <= this.a.b)
        {
          j = a(i, 7);
          if ((j >= 64) && (j < 116))
          {
            i = 1;
            break;
          }
          if (i + 8 <= this.a.b)
          {
            i = a(i, 8);
            if ((i >= 232) && (i < 253))
            {
              i = 1;
              break;
            }
          }
        }
        i = 0;
        break;
        label211:
        if ((j >= 5) && (j < 15))
        {
          localObject = new cu(i + 5, (char)(j + 48 - 5));
        }
        else
        {
          j = a(i, 7);
          if ((j >= 64) && (j < 90))
          {
            localObject = new cu(i + 7, (char)(j + 1));
          }
          else if ((j >= 90) && (j < 116))
          {
            localObject = new cu(i + 7, (char)(j + 7));
          }
          else
          {
            j = a(i, 8);
            switch (j)
            {
            default: 
              throw new RuntimeException("Decoding invalid ISO/IEC 646 value: " + j);
            case 232: 
              localObject = new cu(i + 8, '!');
              break;
            case 233: 
              localObject = new cu(i + 8, '"');
              break;
            case 234: 
              localObject = new cu(i + 8, '%');
              break;
            case 235: 
              localObject = new cu(i + 8, '&');
              break;
            case 236: 
              localObject = new cu(i + 8, '\'');
              break;
            case 237: 
              localObject = new cu(i + 8, '(');
              break;
            case 238: 
              localObject = new cu(i + 8, ')');
              break;
            case 239: 
              localObject = new cu(i + 8, '*');
              break;
            case 240: 
              localObject = new cu(i + 8, '+');
              break;
            case 241: 
              localObject = new cu(i + 8, ',');
              break;
            case 242: 
              localObject = new cu(i + 8, '-');
              break;
            case 243: 
              localObject = new cu(i + 8, '.');
              break;
            case 244: 
              localObject = new cu(i + 8, '/');
              break;
            case 245: 
              localObject = new cu(i + 8, ':');
              break;
            case 246: 
              localObject = new cu(i + 8, ';');
              break;
            case 247: 
              localObject = new cu(i + 8, '<');
              break;
            case 248: 
              localObject = new cu(i + 8, '=');
              break;
            case 249: 
              localObject = new cu(i + 8, '>');
              break;
            case 250: 
              localObject = new cu(i + 8, '?');
              break;
            case 251: 
              localObject = new cu(i + 8, '_');
              break;
            case 252: 
              localObject = new cu(i + 8, ' ');
            }
          }
        }
      }
      label801:
      this.c.append(((cu)localObject).a());
    }
    if (b(this.b.a))
    {
      localObject = this.b;
      ((ct)localObject).a += 3;
      this.b.c();
    }
    while (!a(this.b.a)) {
      return new cs((byte)0);
    }
    if (this.b.a + 5 < this.a.b) {
      localObject = this.b;
    }
    for (((ct)localObject).a += 5;; this.b.a = this.a.b)
    {
      this.b.d();
      break;
    }
  }
  
  private boolean b(int paramInt)
  {
    if (paramInt + 3 > this.a.b) {
      return false;
    }
    int i = paramInt;
    for (;;)
    {
      if (i >= paramInt + 3) {
        break label42;
      }
      if (this.a.a(i)) {
        break;
      }
      i += 1;
    }
    label42:
    return true;
  }
  
  final int a(int paramInt1, int paramInt2)
  {
    return a(this.a, paramInt1, paramInt2);
  }
  
  final cv a(int paramInt, String paramString)
  {
    this.c.setLength(0);
    if (paramString != null) {
      this.c.append(paramString);
    }
    this.b.a = paramInt;
    label47:
    label91:
    label131:
    label184:
    label297:
    label522:
    label537:
    label698:
    label701:
    for (;;)
    {
      int i = this.b.a;
      int j;
      boolean bool;
      if (this.b.a())
      {
        paramInt = this.b.a;
        if (paramInt + 5 <= this.a.b)
        {
          j = a(paramInt, 5);
          if ((j >= 5) && (j < 16))
          {
            paramInt = 1;
            if (paramInt == 0) {
              break label537;
            }
            paramInt = this.b.a;
            j = a(paramInt, 5);
            if (j != 15) {
              break label297;
            }
            paramString = new cu(paramInt + 5, '$');
            this.b.a = paramString.e();
            if (!paramString.b()) {
              break label522;
            }
            paramString = new cs(new cv(this.b.a, this.c.toString()));
            bool = paramString.b();
            if (i == this.b.a) {
              break label698;
            }
          }
        }
      }
      for (paramInt = 1;; paramInt = 0)
      {
        if (((paramInt != 0) || (bool)) && (!bool)) {
          break label701;
        }
        paramString = paramString.a();
        if ((paramString == null) || (!paramString.b())) {
          break label703;
        }
        return new cv(this.b.a, this.c.toString(), paramString.c());
        if (paramInt + 6 <= this.a.b)
        {
          paramInt = a(paramInt, 6);
          if ((paramInt >= 16) && (paramInt < 63))
          {
            paramInt = 1;
            break label91;
          }
        }
        paramInt = 0;
        break label91;
        if ((j >= 5) && (j < 15))
        {
          paramString = new cu(paramInt + 5, (char)(j + 48 - 5));
          break label131;
        }
        j = a(paramInt, 6);
        if ((j >= 32) && (j < 58))
        {
          paramString = new cu(paramInt + 6, (char)(j + 33));
          break label131;
        }
        switch (j)
        {
        default: 
          throw new RuntimeException("Decoding invalid alphanumeric value: " + j);
        case 58: 
          paramString = new cu(paramInt + 6, '*');
          break;
        case 59: 
          paramString = new cu(paramInt + 6, ',');
          break;
        case 60: 
          paramString = new cu(paramInt + 6, '-');
          break;
        case 61: 
          paramString = new cu(paramInt + 6, '.');
          break;
        case 62: 
          paramString = new cu(paramInt + 6, '/');
          break;
          this.c.append(paramString.a());
          break label47;
          if (b(this.b.a))
          {
            paramString = this.b;
            paramString.a += 3;
            this.b.c();
          }
          while (!a(this.b.a))
          {
            paramString = new cs((byte)0);
            break;
          }
          if (this.b.a + 5 < this.a.b) {
            paramString = this.b;
          }
          for (paramString.a += 5;; this.b.a = this.a.b)
          {
            this.b.e();
            break;
          }
          if (this.b.b())
          {
            paramString = b();
            bool = paramString.b();
            break label184;
          }
          paramString = a();
          bool = paramString.b();
          break label184;
        }
      }
    }
    label703:
    return new cv(this.b.a, this.c.toString());
  }
  
  final String a(StringBuffer paramStringBuffer, int paramInt)
    throws y
  {
    String str = null;
    cv localcv = a(paramInt, str);
    paramStringBuffer.append(cy.a(localcv.a()));
    if (localcv.b()) {}
    for (str = String.valueOf(localcv.c());; str = null)
    {
      if (paramInt == localcv.e()) {
        break label63;
      }
      paramInt = localcv.e();
      break;
    }
    label63:
    return paramStringBuffer.toString();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */