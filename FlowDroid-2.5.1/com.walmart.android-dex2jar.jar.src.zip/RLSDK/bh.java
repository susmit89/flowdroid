package RLSDK;

public final class bh
{
  private final bb a = new bb(az.f);
  
  public final ap a(ak paramak)
    throws v, t
  {
    paramak = new be(paramak);
    Object localObject = paramak.a();
    paramak = bf.a(paramak.b(), (bi)localObject);
    int k = paramak.length;
    int i = 0;
    int j = 0;
    while (i < k)
    {
      j += paramak[i].a();
      i += 1;
    }
    localObject = new byte[j];
    i = 0;
    while (i < k)
    {
      int[] arrayOfInt = paramak[i];
      byte[] arrayOfByte = arrayOfInt.b();
      int m = arrayOfInt.a();
      int n = arrayOfByte.length;
      arrayOfInt = new int[n];
      j = 0;
      while (j < n)
      {
        arrayOfByte[j] &= 0xFF;
        j += 1;
      }
      j = arrayOfByte.length;
      try
      {
        this.a.a(arrayOfInt, j - m);
        j = 0;
        while (j < m)
        {
          arrayOfByte[j] = ((byte)arrayOfInt[j]);
          j += 1;
        }
        j = 0;
      }
      catch (bc paramak)
      {
        throw t.a();
      }
      while (j < m)
      {
        localObject[(j * k + i)] = arrayOfByte[j];
        j += 1;
      }
      i += 1;
    }
    return bg.a((byte[])localObject);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */