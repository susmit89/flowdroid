package RLSDK;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.util.Log;
import com.ebay.redlasersdk.BarcodeResult;
import com.ebay.redlasersdk.recognizers.BarcodeResultInternal;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

public final class c
{
  static c a = c.d;
  static SharedPreferences b;
  static String c;
  static String d;
  static String e;
  private static Context f;
  private static boolean g = false;
  private static boolean h = true;
  private static boolean i = true;
  private static final byte[] j = { 48, -126, 2, 34, 48, 13, 6, 9, 42, -122, 72, -122, -9, 13, 1, 1, 1, 5, 0, 3, -126, 2, 15, 0, 48, -126, 2, 10, 2, -126, 2, 1, 0, -85, 46, -20, -35, 65, -66, -62, 21, -51, 105, -53, 4, -121, 71, -101, -76, -93, -38, 93, 100, -128, -51, 44, 101, -35, 9, 15, -125, 48, 59, 73, -12, 21, 112, 84, -89, 117, 85, -90, 8, -66, -27, 50, -36, 93, 92, -95, -25, 117, -62, 127, 0, -81, -123, -119, -49, -23, -35, -17, 83, 79, 21, -40, 20, 81, 11, -122, -19, 127, 106, 102, -127, -2, -47, -25, -25, 65, 56, -125, -83, -106, 11, 76, 120, -97, 17, 44, -118, -15, -114, -110, -108, 111, 88, -93, 18, 72, 41, 59, -17, 70, 112, -64, -121, -11, 18, -32, -46, -125, 102, 41, -25, 53, -117, -86, 16, 123, 64, -82, 83, 90, -35, 65, -23, 37, 72, -43, -3, -51, 80, -125, 10, 117, -65, -70, 75, -22, -19, -114, 13, 20, -17, 105, 28, -97, 111, 15, 95, -55, 17, -84, -12, -50, 118, -70, 57, 123, -124, 96, 47, -82, -105, -102, -64, 84, -55, 67, 110, -75, -56, -117, -124, 59, -24, 40, -6, 93, -108, 53, 118, 123, -9, -90, -66, -81, -11, 42, 107, -31, 11, 62, -63, 55, -111, -6, 79, 115, 121, 23, -13, 76, 93, 109, -8, -37, 31, 26, 26, 79, -56, -84, -72, -15, -48, 20, 127, -112, -47, 119, 122, 103, -31, -44, 12, 97, -31, -52, 120, -32, -62, 117, 87, 7, -29, -54, -5, -8, 89, -4, 65, 5, 61, 92, -114, 51, -34, -28, -111, -35, -57, -8, 125, -19, -12, 45, -89, -128, 115, -92, 63, 113, -21, -61, -89, -46, -86, 29, 52, -10, 85, 51, -58, 42, 8, 27, -113, 39, 112, -53, -36, 92, 104, 66, 23, -4, 110, 113, -37, 67, -9, -77, -5, -41, -93, -69, 16, -64, 58, 101, 120, -34, 58, -73, 93, -114, -52, 109, 19, -58, -101, 37, 75, -14, -104, -119, -114, 90, -12, 0, 118, -65, 14, -49, 27, 20, 111, -73, -92, 41, 85, -124, -95, -61, -15, -110, 89, 76, -22, 8, 26, 33, -64, -49, 82, -116, 22, -61, 48, 48, 41, 35, -79, 100, 114, 39, -66, 31, -10, -67, 64, -6, 23, -80, -66, 66, -99, 4, 80, -33, -19, 112, 33, 7, 94, -69, 53, 78, 53, 10, -113, 119, -30, 35, 32, -2, 125, 80, 122, -18, 126, -101, 96, 99, 85, -67, -73, -49, 113, -72, 13, -87, 63, 57, -13, -87, -125, -119, -96, -52, 85, -46, -22, -39, 103, -127, 39, 100, 9, 71, -46, -54, -1, 89, -109, -64, -58, -127, 89, -124, -21, 40, -29, -59, 0, -122, 92, 123, -81, 68, -90, 68, 13, 124, 17, -56, 102, 77, -124, 25, 42, 13, 30, -123, -102, 20, 30, -36, 92, 76, -15, 88, 96, 92, 40, 32, -95, 17, 25, 112, -114, 112, 4, 36, 2, -16, -72, 119, 1, -7, 43, -127, -4, 5, -11, -102, 110, -79, -25, -3, 83, 93, -37, -13, 16, -77, 69, 74, -64, 58, 62, -101, -90, -74, -21, -97, 25, 103, 123, 48, 80, 54, 103, 2, 3, 1, 0, 1 };
  
  public static c a()
  {
    return a;
  }
  
  private static String a(Context paramContext, String paramString)
  {
    try
    {
      paramContext = new BufferedReader(new InputStreamReader(paramContext.getAssets().open(paramString)));
      paramString = new StringBuilder();
      for (;;)
      {
        String str = paramContext.readLine();
        if (str == null) {
          break;
        }
        paramString.append(str).append("\n");
      }
      paramContext.close();
    }
    catch (IOException paramContext)
    {
      Log.e("StatusManager", "Problem reading license file", paramContext);
      return null;
    }
    paramContext = paramString.toString();
    return paramContext;
  }
  
  private static ArrayList<String> a(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    for (;;)
    {
      try
      {
        localObject = XmlPullParserFactory.newInstance();
        ((XmlPullParserFactory)localObject).setNamespaceAware(true);
        localObject = ((XmlPullParserFactory)localObject).newPullParser();
        ((XmlPullParser)localObject).setInput(new StringReader(paramString));
        i8 = ((XmlPullParser)localObject).getEventType();
        i2 = 0;
        i3 = 0;
        n = 0;
        i4 = 0;
        i1 = 0;
      }
      catch (Exception paramString)
      {
        Object localObject;
        boolean bool;
        Log.e("StatusManager", "Logic error in license XML parser", paramString);
        return localArrayList;
      }
      int i8 = ((XmlPullParser)localObject).next();
      int i1 = i5;
      int i2 = i6;
      int i3 = m;
      int n = k;
      int i4 = i7;
      break label450;
      paramString = ((XmlPullParser)localObject).getName();
      if (paramString.equalsIgnoreCase("key")) {
        n = 1;
      }
      int i5 = i1;
      int i6 = i2;
      int m = i3;
      int k = n;
      int i7 = i4;
      if (paramString.equalsIgnoreCase("string"))
      {
        m = 1;
        i5 = i1;
        i6 = i2;
        k = n;
        i7 = i4;
        continue;
        paramString = ((XmlPullParser)localObject).getText();
        if (n != 0)
        {
          if (paramString.equalsIgnoreCase("Android"))
          {
            i6 = 1;
            k = 0;
            i5 = i1;
            m = i3;
            i7 = i4;
            continue;
          }
          if ((i2 != 0) && (paramString.equalsIgnoreCase("Root Class Names")))
          {
            i5 = 1;
            k = 0;
            i6 = i2;
            m = i3;
            i7 = i4;
          }
        }
        else
        {
          i5 = i1;
          i6 = i2;
          m = i3;
          k = n;
          i7 = i4;
          if (i3 == 0) {
            continue;
          }
          if ((i2 != 0) && (i1 != 0))
          {
            localArrayList.add(paramString);
            m = 0;
            i5 = i1;
            i6 = i2;
            k = n;
            i7 = i4;
            continue;
            bool = ((XmlPullParser)localObject).getName().equalsIgnoreCase("array");
            i5 = i1;
            i6 = i2;
            m = i3;
            k = n;
            i7 = i4;
            if (!bool) {
              continue;
            }
            i5 = i1;
            i6 = i2;
            m = i3;
            k = n;
            i7 = i4;
            if (i2 == 0) {
              continue;
            }
            i5 = i1;
            i6 = i2;
            m = i3;
            k = n;
            i7 = i4;
            if (i1 == 0) {
              continue;
            }
            i7 = 1;
            i5 = i1;
            i6 = i2;
            m = i3;
            k = n;
            continue;
          }
          m = 0;
          i5 = i1;
          i6 = i2;
          k = n;
          i7 = i4;
          continue;
        }
        k = 0;
        i5 = i1;
        i6 = i2;
        m = i3;
        i7 = i4;
        continue;
        label450:
        if ((i4 == 0) && (i8 != 1))
        {
          i5 = i1;
          i6 = i2;
          m = i3;
          k = n;
          i7 = i4;
          switch (i8)
          {
          }
          i5 = i1;
          i6 = i2;
          m = i3;
          k = n;
          i7 = i4;
        }
      }
    }
  }
  
  public static void a(Context paramContext)
  {
    if (paramContext == null) {
      try
      {
        throw new IllegalArgumentException();
      }
      finally {}
    }
    Object localObject1;
    if (!g)
    {
      f = paramContext;
      localObject1 = paramContext.getApplicationContext();
      p.a(paramContext.getContentResolver());
      c = ((Context)localObject1).getPackageName();
    }
    try
    {
      d = ((Context)localObject1).getPackageManager().getPackageInfo(c, 0).versionName;
      b = ((Context)localObject1).getSharedPreferences("com.ebay.redlasersdk.network.preferences", 0);
      localObject1 = a((Context)localObject1, "RedLaser_License.xml");
      a = c.a;
      if ((localObject1 != null) && (((String)localObject1).length() > 0))
      {
        k = ((String)localObject1).indexOf("-----BEGIN SIGNATURE-----");
        int m = ((String)localObject1).indexOf("-----END SIGNATURE-----");
        if ((k == -1) || (m == -1)) {
          break label344;
        }
        paramContext = ((String)localObject1).substring(k + 25, m);
      }
    }
    catch (Exception paramContext)
    {
      try
      {
        int k;
        paramContext = n.a(paramContext);
        localObject1 = ((String)localObject1).substring(0, k);
        Object localObject2 = new X509EncodedKeySpec(j);
        localObject2 = KeyFactory.getInstance("RSA").generatePublic((KeySpec)localObject2);
        Signature localSignature = Signature.getInstance("SHA1withRSA");
        localSignature.initVerify((PublicKey)localObject2);
        localSignature.update(((String)localObject1).getBytes());
        if (localSignature.verify(paramContext))
        {
          if (a((String)localObject1).contains(c)) {}
          for (a = c.b;; a = c.e)
          {
            e = c;
            if (a.compareTo(c.a) == 0) {
              e = "psdk";
            }
            if (b.getString("disableCapture", "NO").equalsIgnoreCase("YES")) {
              a = c.c;
            }
            if (i)
            {
              new a((byte)0).execute(null);
              b.a("ANDROIDSDK.APP_LAUNCH", null);
            }
            g = true;
            return;
            paramContext = paramContext;
            d = null;
            break;
          }
        }
      }
      catch (NoSuchAlgorithmException paramContext)
      {
        for (;;)
        {
          Log.e("StatusManager", "Logic error in license decryption", paramContext);
          a = c.e;
          continue;
          a = c.e;
        }
      }
      catch (InvalidKeySpecException paramContext)
      {
        for (;;)
        {
          Log.e("StatusManager", "Logic error in license decryption", paramContext);
        }
      }
      catch (InvalidKeyException paramContext)
      {
        for (;;)
        {
          Log.e("StatusManager", "Logic error in license decryption", paramContext);
        }
      }
      catch (Exception paramContext)
      {
        for (;;)
        {
          label344:
          a = c.e;
        }
      }
    }
  }
  
  public static void a(BarcodeResultInternal paramBarcodeResultInternal)
  {
    if (paramBarcodeResultInternal == null) {
      Log.e("StatusManager", "Null list of barcodes sent to logScans");
    }
    while (!h) {
      return;
    }
    new b((byte)0).execute(new BarcodeResult[] { paramBarcodeResultInternal });
    HashMap localHashMap = new HashMap();
    localHashMap.put("type", paramBarcodeResultInternal.getBarcodeTrackingType());
    localHashMap.put("barcode", paramBarcodeResultInternal.barcodeString);
    b.a("ANDRSDK.BARCODE_SCANNED", localHashMap);
  }
  
  private static final class a
    extends AsyncTask<Void, Void, String>
  {
    /* Error */
    private static String a()
    {
      // Byte code:
      //   0: new 26	java/lang/StringBuilder
      //   3: dup
      //   4: invokespecial 27	java/lang/StringBuilder:<init>	()V
      //   7: astore_0
      //   8: aload_0
      //   9: ldc 29
      //   11: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   14: pop
      //   15: aload_0
      //   16: new 26	java/lang/StringBuilder
      //   19: dup
      //   20: ldc 35
      //   22: invokespecial 38	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   25: getstatic 43	RLSDK/o:a	Ljava/lang/String;
      //   28: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   31: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   34: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   37: pop
      //   38: aload_0
      //   39: new 26	java/lang/StringBuilder
      //   42: dup
      //   43: ldc 48
      //   45: invokespecial 38	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   48: invokestatic 52	RLSDK/p:a	()Ljava/lang/String;
      //   51: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   54: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   57: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   60: pop
      //   61: aload_0
      //   62: new 26	java/lang/StringBuilder
      //   65: dup
      //   66: ldc 54
      //   68: invokespecial 38	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   71: getstatic 57	RLSDK/c:e	Ljava/lang/String;
      //   74: ldc 59
      //   76: invokestatic 65	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   79: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   82: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   85: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   88: pop
      //   89: aload_0
      //   90: ldc 67
      //   92: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   95: pop
      //   96: aload_0
      //   97: new 26	java/lang/StringBuilder
      //   100: dup
      //   101: ldc 69
      //   103: invokespecial 38	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   106: getstatic 74	android/os/Build$VERSION:RELEASE	Ljava/lang/String;
      //   109: ldc 59
      //   111: invokestatic 65	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   114: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   117: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   120: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   123: pop
      //   124: aload_0
      //   125: new 26	java/lang/StringBuilder
      //   128: dup
      //   129: ldc 76
      //   131: invokespecial 38	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   134: getstatic 81	android/os/Build:MODEL	Ljava/lang/String;
      //   137: ldc 59
      //   139: invokestatic 65	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   142: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   145: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   148: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   151: pop
      //   152: aload_0
      //   153: new 26	java/lang/StringBuilder
      //   156: dup
      //   157: ldc 83
      //   159: invokespecial 38	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   162: invokestatic 89	java/util/Locale:getDefault	()Ljava/util/Locale;
      //   165: invokevirtual 90	java/util/Locale:toString	()Ljava/lang/String;
      //   168: ldc 59
      //   170: invokestatic 65	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   173: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   176: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   179: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   182: pop
      //   183: getstatic 93	RLSDK/c:d	Ljava/lang/String;
      //   186: ifnull +31 -> 217
      //   189: aload_0
      //   190: new 26	java/lang/StringBuilder
      //   193: dup
      //   194: ldc 95
      //   196: invokespecial 38	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   199: getstatic 93	RLSDK/c:d	Ljava/lang/String;
      //   202: ldc 59
      //   204: invokestatic 65	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   207: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   210: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   213: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   216: pop
      //   217: aload_0
      //   218: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   221: astore_0
      //   222: new 97	RLSDK/a
      //   225: dup
      //   226: invokestatic 101	RLSDK/c:b	()Landroid/content/Context;
      //   229: invokespecial 104	RLSDK/a:<init>	(Landroid/content/Context;)V
      //   232: astore_1
      //   233: aload_1
      //   234: aload_0
      //   235: invokevirtual 107	RLSDK/a:a	(Ljava/lang/String;)Ljava/io/InputStream;
      //   238: astore_0
      //   239: aload_0
      //   240: invokestatic 110	RLSDK/a:a	(Ljava/io/InputStream;)Ljava/lang/String;
      //   243: areturn
      //   244: astore_0
      //   245: ldc 112
      //   247: ldc 114
      //   249: aload_0
      //   250: invokestatic 119	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   253: pop
      //   254: ldc 121
      //   256: areturn
      //   257: astore_0
      //   258: ldc 112
      //   260: ldc 123
      //   262: aload_0
      //   263: invokestatic 119	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   266: pop
      //   267: ldc 121
      //   269: areturn
      //   270: astore_0
      //   271: ldc 112
      //   273: ldc 125
      //   275: aload_0
      //   276: invokestatic 119	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   279: pop
      //   280: ldc 121
      //   282: areturn
      //   283: astore_1
      //   284: goto -67 -> 217
      // Local variable table:
      //   start	length	slot	name	signature
      //   7	233	0	localObject	Object
      //   244	6	0	localUnsupportedEncodingException	UnsupportedEncodingException
      //   257	6	0	localMalformedURLException	MalformedURLException
      //   270	6	0	localIOException	IOException
      //   232	2	1	locala	a
      //   283	1	1	localException	Exception
      // Exception table:
      //   from	to	target	type
      //   8	183	244	java/io/UnsupportedEncodingException
      //   233	239	257	java/net/MalformedURLException
      //   233	239	270	java/io/IOException
      //   183	217	283	java/lang/Exception
    }
  }
  
  private static final class b
    extends AsyncTask<BarcodeResult, Void, String>
  {
    private static String a(BarcodeResult... paramVarArgs)
    {
      BarcodeResult localBarcodeResult = paramVarArgs[0];
      StringBuilder localStringBuilder = new StringBuilder();
      Object localObject = localBarcodeResult.barcodeString;
      String str = localBarcodeResult.getBarcodeType();
      if (localBarcodeResult.barcodeType != 16)
      {
        paramVarArgs = (BarcodeResult[])localObject;
        if (localBarcodeResult.barcodeType != 16384) {
          break label118;
        }
      }
      try
      {
        paramVarArgs = new StringBuilder();
        localObject = MessageDigest.getInstance("SHA-1").digest(((String)localObject).getBytes("UTF-8"));
        int j = localObject.length;
        int i = 0;
        while (i < j)
        {
          paramVarArgs.append(String.format("%02X", new Object[] { Byte.valueOf(localObject[i]) }));
          i += 1;
        }
        paramVarArgs = paramVarArgs.toString();
        label118:
        return "";
      }
      catch (NoSuchAlgorithmException paramVarArgs)
      {
        for (;;)
        {
          try
          {
            localStringBuilder.append("http://api.redlaser.com/logscan");
            localStringBuilder.append("?udid=" + p.a());
            localStringBuilder.append("&key=" + URLEncoder.encode(c.e, "UTF-8"));
            localStringBuilder.append("&platform=android");
            localStringBuilder.append("&barcode=" + URLEncoder.encode(paramVarArgs, "UTF-8"));
            localStringBuilder.append("&btype=" + URLEncoder.encode(str, "UTF-8"));
            localStringBuilder.append("&locale=" + URLEncoder.encode(Locale.getDefault().toString(), "UTF-8"));
            paramVarArgs = localStringBuilder.toString();
            localObject = new a(c.b());
          }
          catch (UnsupportedEncodingException paramVarArgs)
          {
            Log.e("StatusManager.LogScanTask", "Logic error sanitizing scan logging URL parameters.", paramVarArgs);
            return "";
          }
          try
          {
            paramVarArgs = ((a)localObject).a(paramVarArgs);
            return a.a(paramVarArgs);
          }
          catch (MalformedURLException paramVarArgs)
          {
            Log.e("StatusManager.LogScanTask", "Logic error. Bad scan logging URL.", paramVarArgs);
            return "";
          }
          catch (IOException paramVarArgs)
          {
            Log.e("StatusManager.LogScanTask", "Logic error. Bad URL cache.", paramVarArgs);
          }
          paramVarArgs = paramVarArgs;
          paramVarArgs.printStackTrace();
          paramVarArgs = "**ErrorGeneratingHash**";
        }
      }
      catch (UnsupportedEncodingException paramVarArgs)
      {
        for (;;)
        {
          paramVarArgs.printStackTrace();
          paramVarArgs = "**ErrorGeneratingHash**";
        }
      }
    }
  }
  
  public static enum c
  {
    private c() {}
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */