package RLSDK;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public final class cd
  extends bz
{
  private static final int[] g = { 1, 10, 34, 70, 126 };
  private static final int[] h = { 4, 20, 48, 81 };
  private static final int[] i = { 0, 161, 961, 2015, 2715 };
  private static final int[] j = { 0, 336, 1036, 1516 };
  private static final int[] k = { 8, 6, 4, 3, 1 };
  private static final int[] l = { 2, 4, 6, 8 };
  private static final int[][] m;
  private final Vector n = new Vector();
  private final Vector o = new Vector();
  
  static
  {
    int[] arrayOfInt1 = { 3, 8, 2, 1 };
    int[] arrayOfInt2 = { 3, 5, 5, 1 };
    int[] arrayOfInt3 = { 3, 1, 9, 1 };
    m = new int[][] { arrayOfInt1, arrayOfInt2, { 3, 3, 7, 1 }, arrayOfInt3, { 2, 7, 4, 1 }, { 2, 5, 6, 1 }, { 2, 3, 8, 1 }, { 1, 5, 7, 1 }, { 1, 3, 9, 1 } };
  }
  
  private ca a(aj paramaj, cb paramcb, boolean paramBoolean)
    throws y
  {
    int[] arrayOfInt = this.b;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    arrayOfInt[2] = 0;
    arrayOfInt[3] = 0;
    arrayOfInt[4] = 0;
    arrayOfInt[5] = 0;
    arrayOfInt[6] = 0;
    arrayOfInt[7] = 0;
    label72:
    float[] arrayOfFloat2;
    label109:
    float f2;
    if (paramBoolean)
    {
      b(paramaj, paramcb.b()[0], arrayOfInt);
      if (!paramBoolean) {
        break label253;
      }
      i2 = 16;
      float f1 = a(arrayOfInt) / i2;
      paramaj = this.e;
      paramcb = this.f;
      float[] arrayOfFloat1 = this.c;
      arrayOfFloat2 = this.d;
      i3 = 0;
      if (i3 >= arrayOfInt.length) {
        break label298;
      }
      f2 = arrayOfInt[i3] / f1;
      i4 = (int)(0.5F + f2);
      if (i4 > 0) {
        break label260;
      }
      i1 = 1;
      label144:
      i4 = i3 >> 1;
      if ((i3 & 0x1) != 0) {
        break label278;
      }
      paramaj[i4] = i1;
      arrayOfFloat1[i4] = (f2 - i1);
    }
    for (;;)
    {
      i3 += 1;
      break label109;
      a(paramaj, paramcb.b()[1] + 1, arrayOfInt);
      i2 = 0;
      i1 = arrayOfInt.length - 1;
      while (i2 < i1)
      {
        i3 = arrayOfInt[i2];
        arrayOfInt[i2] = arrayOfInt[i1];
        arrayOfInt[i1] = i3;
        i2 += 1;
        i1 -= 1;
      }
      break;
      label253:
      i2 = 15;
      break label72;
      label260:
      i1 = i4;
      if (i4 <= 8) {
        break label144;
      }
      i1 = 8;
      break label144;
      label278:
      paramcb[i4] = i1;
      arrayOfFloat2[i4] = (f2 - i1);
    }
    label298:
    int i10 = a(this.e);
    int i11 = a(this.f);
    int i12 = i10 + i11 - i2;
    int i8;
    label345:
    int i7;
    label356:
    int i6;
    int i9;
    if (paramBoolean)
    {
      i1 = 1;
      if ((i10 & 0x1) != i1) {
        break label432;
      }
      i8 = 1;
      if ((i11 & 0x1) != 1) {
        break label438;
      }
      i7 = 1;
      i4 = 0;
      i6 = 0;
      i3 = 0;
      i1 = 0;
      i2 = 0;
      i9 = 0;
      if (!paramBoolean) {
        break label500;
      }
      if (i10 <= 12) {
        break label444;
      }
      i5 = 1;
      label388:
      if (i11 <= 12) {
        break label464;
      }
      i1 = 1;
      i3 = i6;
      i4 = i5;
    }
    for (;;)
    {
      if (i12 == 1) {
        if (i8 != 0)
        {
          if (i7 != 0)
          {
            throw y.a();
            i1 = 0;
            break;
            label432:
            i8 = 0;
            break label345;
            label438:
            i7 = 0;
            break label356;
            label444:
            i5 = i1;
            if (i10 >= 4) {
              break label388;
            }
            i6 = 1;
            i5 = i1;
            break label388;
            label464:
            i1 = i9;
            i4 = i5;
            i3 = i6;
            if (i11 >= 4) {
              continue;
            }
            i2 = 1;
            i1 = i9;
            i4 = i5;
            i3 = i6;
            continue;
            label500:
            if (i10 > 11)
            {
              i5 = 1;
              i6 = i4;
            }
            for (;;)
            {
              if (i11 <= 10) {
                break label559;
              }
              i1 = 1;
              i4 = i5;
              i3 = i6;
              break;
              i5 = i3;
              i6 = i4;
              if (i10 < 5)
              {
                i6 = 1;
                i5 = i3;
              }
            }
            label559:
            i1 = i9;
            i4 = i5;
            i3 = i6;
            if (i11 >= 4) {
              continue;
            }
            i2 = 1;
            i1 = i9;
            i4 = i5;
            i3 = i6;
            continue;
          }
          i4 = 1;
        }
      }
    }
    while (i3 != 0) {
      if (i4 != 0)
      {
        throw y.a();
        if (i7 == 0) {
          throw y.a();
        }
        i1 = 1;
        continue;
        if (i12 == -1)
        {
          if (i8 != 0)
          {
            if (i7 != 0) {
              throw y.a();
            }
            i3 = 1;
          }
          else
          {
            if (i7 == 0) {
              throw y.a();
            }
            i2 = 1;
          }
        }
        else if (i12 == 0)
        {
          if (i8 != 0)
          {
            if (i7 == 0) {
              throw y.a();
            }
            if (i10 < i11)
            {
              i3 = 1;
              i1 = 1;
            }
            else
            {
              i4 = 1;
              i2 = 1;
            }
          }
          else if (i7 != 0)
          {
            throw y.a();
          }
        }
        else {
          throw y.a();
        }
      }
      else
      {
        a(this.e, this.c);
      }
    }
    if (i4 != 0) {
      b(this.e, this.c);
    }
    if (i2 != 0)
    {
      if (i1 != 0) {
        throw y.a();
      }
      a(this.f, this.c);
    }
    if (i1 != 0) {
      b(this.f, this.d);
    }
    int i3 = paramaj.length - 1;
    int i2 = 0;
    for (int i1 = 0; i3 >= 0; i1 = i4 + i1)
    {
      i5 = paramaj[i3];
      i4 = paramaj[i3];
      i3 -= 1;
      i2 = i2 * 9 + i5;
    }
    int i5 = 0;
    int i4 = 0;
    i3 = paramcb.length - 1;
    while (i3 >= 0)
    {
      i5 = i5 * 9 + paramcb[i3];
      i4 += paramcb[i3];
      i3 -= 1;
    }
    i2 = i5 * 3 + i2;
    if (paramBoolean)
    {
      if (((i1 & 0x1) != 0) || (i1 > 12) || (i1 < 4)) {
        throw y.a();
      }
      i1 = (12 - i1) / 2;
      i4 = k[i1];
      i3 = ce.a(paramaj, i4, false);
      i4 = ce.a(paramcb, 9 - i4, true);
      return new ca(i3 * g[i1] + i4 + i[i1], i2);
    }
    if (((i4 & 0x1) != 0) || (i4 > 10) || (i4 < 4)) {
      throw y.a();
    }
    i1 = (10 - i4) / 2;
    i3 = l[i1];
    return new ca(ce.a(paramaj, i3, true) + ce.a(paramcb, 9 - i3, false) * h[i1] + j[i1], i2);
  }
  
  private cc a(aj paramaj, boolean paramBoolean, int paramInt, Hashtable paramHashtable)
  {
    int i1 = 0;
    Object localObject;
    try
    {
      localObject = this.a;
      localObject[0] = 0;
      localObject[1] = 0;
      localObject[2] = 0;
      localObject[3] = 0;
      int i5 = paramaj.b;
      boolean bool1 = false;
      boolean bool2 = bool1;
      label64:
      int i3;
      int i2;
      int[] arrayOfInt;
      if (i1 < i5) {
        if (!paramaj.a(i1))
        {
          bool1 = true;
          break label430;
          if (i3 < i5)
          {
            if ((paramaj.a(i3) ^ bool1))
            {
              localObject[i2] += 1;
              break label469;
            }
            if (i2 != 3) {
              break label561;
            }
            if (!b((int[])localObject)) {
              break label478;
            }
            arrayOfInt = new int[2];
            arrayOfInt[0] = i1;
            arrayOfInt[1] = i3;
            bool1 = paramaj.a(arrayOfInt[0]);
            i1 = arrayOfInt[0] - 1;
            while ((i1 >= 0) && ((paramaj.a(i1) ^ bool1))) {
              i1 -= 1;
            }
          }
          throw y.a();
          i3 = i1 + 1;
          i2 = arrayOfInt[0];
          localObject = this.a;
          i1 = localObject.length - 1;
        }
      }
      label430:
      label455:
      label469:
      label478:
      label532:
      label561:
      while (i1 <= 0)
      {
        localObject[0] = (i2 - i3);
        int i4 = a((int[])localObject, m);
        i2 = arrayOfInt[1];
        if (paramBoolean)
        {
          i1 = paramaj.b - 1 - i3;
          i2 = paramaj.b - 1 - i2;
        }
        for (;;)
        {
          localObject = new cb(i4, new int[] { i3, arrayOfInt[1] }, i1, i2, paramInt);
          if (paramHashtable == null) {}
          for (paramHashtable = null;; paramHashtable = (ae)paramHashtable.get(u.h))
          {
            if (paramHashtable != null)
            {
              float f2 = (arrayOfInt[0] + arrayOfInt[1]) / 2.0F;
              float f1 = f2;
              if (paramBoolean) {
                f1 = paramaj.b - 1 - f2;
              }
              paramHashtable.a(new ad(f1, paramInt));
            }
            paramHashtable = a(paramaj, (cb)localObject, true);
            paramaj = a(paramaj, (cb)localObject, false);
            return new cc(paramHashtable.a() * 1597 + paramaj.a(), paramHashtable.b() + paramaj.b() * 4, (cb)localObject);
          }
          i1 = i3;
        }
        for (;;)
        {
          bool2 = bool1;
          if (paramBoolean == bool1) {
            break label455;
          }
          i1 += 1;
          break;
          bool1 = false;
        }
        i3 = i1;
        bool1 = bool2;
        i2 = 0;
        break label64;
        i3 += 1;
        break label64;
        i1 = localObject[0] + localObject[1] + i1;
        localObject[0] = localObject[2];
        localObject[1] = localObject[3];
        localObject[2] = 0;
        localObject[3] = 0;
        i4 = i2 - 1;
        i2 = i1;
        i1 = i4;
        localObject[i1] = 1;
        if (!bool1) {}
        for (bool1 = true;; bool1 = false)
        {
          i4 = i2;
          i2 = i1;
          i1 = i4;
          break;
          i4 = i1;
          i1 = i2 + 1;
          i2 = i4;
          break label532;
        }
      }
    }
    catch (y paramaj)
    {
      return null;
    }
    for (;;)
    {
      localObject[i1] = localObject[(i1 - 1)];
      i1 -= 1;
    }
  }
  
  private static void a(Vector paramVector, cc paramcc)
  {
    if (paramcc == null) {}
    for (;;)
    {
      return;
      Enumeration localEnumeration = paramVector.elements();
      while (localEnumeration.hasMoreElements())
      {
        cc localcc = (cc)localEnumeration.nextElement();
        if (localcc.a() == paramcc.a()) {
          localcc.e();
        }
      }
      for (int i1 = 1; i1 == 0; i1 = 0)
      {
        paramVector.addElement(paramcc);
        return;
      }
    }
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y
  {
    Object localObject1 = a(paramaj, false, paramInt, paramHashtable);
    a(this.n, (cc)localObject1);
    paramaj.a();
    paramHashtable = a(paramaj, true, paramInt, paramHashtable);
    a(this.o, paramHashtable);
    paramaj.a();
    int i4 = this.n.size();
    int i5 = this.o.size();
    int i1 = 0;
    while (i1 < i4)
    {
      localObject1 = (cc)this.n.elementAt(i1);
      if (((cc)localObject1).d() > 1)
      {
        int i2 = 0;
        while (i2 < i5)
        {
          paramHashtable = (cc)this.o.elementAt(i2);
          if (paramHashtable.d() > 1)
          {
            ((cc)localObject1).c().a();
            paramHashtable.c().a();
            int i6 = ((cc)localObject1).b();
            int i7 = paramHashtable.b();
            int i3 = ((cc)localObject1).c().a() * 9 + paramHashtable.c().a();
            paramInt = i3;
            if (i3 > 72) {
              paramInt = i3 - 1;
            }
            i3 = paramInt;
            if (paramInt > 8) {
              i3 = paramInt - 1;
            }
            if ((i6 + i7 * 16) % 79 == i3) {
              paramInt = 1;
            }
            while (paramInt != 0)
            {
              Object localObject2 = String.valueOf(4537077L * ((cc)localObject1).a() + paramHashtable.a());
              paramaj = new StringBuffer(14);
              paramInt = 13 - ((String)localObject2).length();
              for (;;)
              {
                if (paramInt > 0)
                {
                  paramaj.append('0');
                  paramInt -= 1;
                  continue;
                  paramInt = 0;
                  break;
                }
              }
              paramaj.append((String)localObject2);
              paramInt = 0;
              i1 = 0;
              while (paramInt < 13)
              {
                i3 = paramaj.charAt(paramInt) - '0';
                i2 = i3;
                if ((paramInt & 0x1) == 0) {
                  i2 = i3 * 3;
                }
                i1 += i2;
                paramInt += 1;
              }
              i1 = 10 - i1 % 10;
              paramInt = i1;
              if (i1 == 10) {
                paramInt = 0;
              }
              paramaj.append(paramInt);
              localObject2 = ((cc)localObject1).c().c();
              localObject1 = paramHashtable.c().c();
              paramaj = String.valueOf(paramaj.toString());
              paramHashtable = localObject2[0];
              localObject2 = localObject2[1];
              Object localObject3 = localObject1[0];
              localObject1 = localObject1[1];
              q localq = q.l;
              return new ab(paramaj, null, new ad[] { paramHashtable, localObject2, localObject3, localObject1 }, localq);
            }
          }
          i2 += 1;
        }
      }
      i1 += 1;
    }
    throw y.a();
  }
  
  public final void a()
  {
    this.n.setSize(0);
    this.o.setSize(0);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */