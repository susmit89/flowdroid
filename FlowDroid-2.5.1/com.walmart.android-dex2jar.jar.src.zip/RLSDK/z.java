package RLSDK;

import java.util.Hashtable;

public abstract interface z
{
  public abstract ab a(s params, Hashtable paramHashtable)
    throws y, t, v;
  
  public abstract void a();
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */