package RLSDK;

abstract class cp
  extends co
{
  cp(aj paramaj)
  {
    super(paramaj);
  }
  
  protected abstract int a(int paramInt);
  
  protected abstract void a(StringBuffer paramStringBuffer, int paramInt);
  
  protected final void b(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    paramInt1 = this.b.a(paramInt1, paramInt2);
    a(paramStringBuffer, paramInt1);
    int i = a(paramInt1);
    paramInt2 = 100000;
    paramInt1 = 0;
    while (paramInt1 < 5)
    {
      if (i / paramInt2 == 0) {
        paramStringBuffer.append('0');
      }
      paramInt2 /= 10;
      paramInt1 += 1;
    }
    paramStringBuffer.append(i);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */