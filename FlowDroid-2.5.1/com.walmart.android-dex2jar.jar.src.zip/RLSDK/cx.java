package RLSDK;

abstract class cx
{
  protected final int a;
  
  cx(int paramInt)
  {
    this.a = paramInt;
  }
  
  final int e()
  {
    return this.a;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */