package RLSDK;

import java.util.Hashtable;
import java.util.Vector;

public final class bt
  extends bu
{
  private final Vector a;
  
  public bt(Hashtable paramHashtable)
  {
    if (paramHashtable == null)
    {
      paramHashtable = null;
      this.a = new Vector();
      if (paramHashtable != null)
      {
        if (!paramHashtable.contains(q.h)) {
          break label164;
        }
        this.a.addElement(new bo());
      }
    }
    for (;;)
    {
      if (paramHashtable.contains(q.g)) {
        this.a.addElement(new bp());
      }
      if (paramHashtable.contains(q.o)) {
        this.a.addElement(new by());
      }
      if (this.a.isEmpty())
      {
        this.a.addElement(new bo());
        this.a.addElement(new bp());
        this.a.addElement(new by());
      }
      return;
      paramHashtable = (Vector)paramHashtable.get(u.c);
      break;
      label164:
      if (paramHashtable.contains(q.n)) {
        this.a.addElement(new bv());
      }
    }
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y
  {
    int[] arrayOfInt = bx.a(paramaj);
    int j = this.a.size();
    int i = 0;
    while (i < j)
    {
      Object localObject = (bx)this.a.elementAt(i);
      try
      {
        localObject = ((bx)localObject).a(paramInt, paramaj, arrayOfInt, paramHashtable);
        if ((q.h.equals(((ab)localObject).c())) && (((ab)localObject).a().charAt(0) == '0'))
        {
          paramInt = 1;
          if (paramHashtable != null) {
            break label144;
          }
          paramaj = null;
          label87:
          if ((paramaj != null) && (!paramaj.contains(q.n))) {
            break label158;
          }
        }
        label144:
        label158:
        for (i = 1;; i = 0)
        {
          if ((paramInt == 0) || (i == 0)) {
            break label164;
          }
          return new ab(((ab)localObject).a().substring(1), null, ((ab)localObject).b(), q.n);
          paramInt = 0;
          break;
          paramaj = (Vector)paramHashtable.get(u.c);
          break label87;
        }
        label164:
        return (ab)localObject;
      }
      catch (aa localaa)
      {
        i += 1;
      }
    }
    throw y.a();
  }
  
  public final void a()
  {
    int j = this.a.size();
    int i = 0;
    while (i < j)
    {
      ((z)this.a.elementAt(i)).a();
      i += 1;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */