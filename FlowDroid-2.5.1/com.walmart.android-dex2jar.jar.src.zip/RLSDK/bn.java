package RLSDK;

import java.util.Hashtable;

public final class bn
  extends bu
{
  private static final char[] a = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".toCharArray();
  private static final int[] b;
  private static final int c = arrayOfInt[47];
  
  static
  {
    int[] arrayOfInt = new int[48];
    arrayOfInt[0] = 'Ĕ';
    arrayOfInt[1] = 'ň';
    arrayOfInt[2] = 'ń';
    arrayOfInt[3] = 'ł';
    arrayOfInt[4] = 'Ĩ';
    arrayOfInt[5] = 'Ĥ';
    arrayOfInt[6] = 'Ģ';
    arrayOfInt[7] = 'Ő';
    arrayOfInt[8] = 'Ē';
    arrayOfInt[9] = 'Ċ';
    arrayOfInt[10] = 'ƨ';
    arrayOfInt[11] = 'Ƥ';
    arrayOfInt[12] = 'Ƣ';
    arrayOfInt[13] = 'Ɣ';
    arrayOfInt[14] = 'ƒ';
    arrayOfInt[15] = 'Ɗ';
    arrayOfInt[16] = 'Ũ';
    arrayOfInt[17] = 'Ť';
    arrayOfInt[18] = 'Ţ';
    arrayOfInt[19] = 'Ĵ';
    arrayOfInt[20] = 'Ě';
    arrayOfInt[21] = 'Ř';
    arrayOfInt[22] = 'Ō';
    arrayOfInt[23] = 'ņ';
    arrayOfInt[24] = 'Ĭ';
    arrayOfInt[25] = 'Ė';
    arrayOfInt[26] = 'ƴ';
    arrayOfInt[27] = 'Ʋ';
    arrayOfInt[28] = 'Ƭ';
    arrayOfInt[29] = 'Ʀ';
    arrayOfInt[30] = 'Ɩ';
    arrayOfInt[31] = 'ƚ';
    arrayOfInt[32] = 'Ŭ';
    arrayOfInt[33] = 'Ŧ';
    arrayOfInt[34] = 'Ķ';
    arrayOfInt[35] = 'ĺ';
    arrayOfInt[36] = 'Į';
    arrayOfInt[37] = 'ǔ';
    arrayOfInt[38] = 'ǒ';
    arrayOfInt[39] = 'Ǌ';
    arrayOfInt[40] = 'Ů';
    arrayOfInt[41] = 'Ŷ';
    arrayOfInt[42] = 'Ʈ';
    arrayOfInt[43] = 'Ħ';
    arrayOfInt[44] = 'ǚ';
    arrayOfInt[45] = 'ǖ';
    arrayOfInt[46] = 'Ĳ';
    arrayOfInt[47] = 'Ş';
    arrayOfInt;
    b = arrayOfInt;
  }
  
  private static char a(int paramInt)
    throws y
  {
    int i = 0;
    while (i < b.length)
    {
      if (b[i] == paramInt) {
        return a[i];
      }
      i += 1;
    }
    throw y.a();
  }
  
  private static int a(int[] paramArrayOfInt)
  {
    int i2 = paramArrayOfInt.length;
    int i = 0;
    for (int k = 0; i < i2; k = j + k)
    {
      j = paramArrayOfInt[i];
      i += 1;
    }
    int m = 0;
    i = 0;
    int j = i;
    int n;
    if (m < i2)
    {
      j = (paramArrayOfInt[m] << 8) * 9 / k;
      n = j >> 8;
      if ((j & 0xFF) <= 127) {
        break label143;
      }
      n += 1;
    }
    label143:
    for (;;)
    {
      if ((n <= 0) || (n > 4))
      {
        j = -1;
        return j;
      }
      if ((m & 0x1) == 0)
      {
        int i1 = 0;
        for (;;)
        {
          j = i;
          if (i1 >= n) {
            break;
          }
          i1 += 1;
          i = i << 1 | 0x1;
        }
      }
      j = i << n;
      m += 1;
      i = j;
      break;
    }
  }
  
  private static String a(StringBuffer paramStringBuffer)
    throws v
  {
    int j = paramStringBuffer.length();
    StringBuffer localStringBuffer = new StringBuffer(j);
    int i = 0;
    if (i < j)
    {
      char c1 = paramStringBuffer.charAt(i);
      int k;
      if ((c1 >= 'a') && (c1 <= 'd'))
      {
        k = paramStringBuffer.charAt(i + 1);
        switch (c1)
        {
        default: 
          c1 = '\000';
          label82:
          localStringBuffer.append(c1);
          i += 1;
        }
      }
      for (;;)
      {
        i += 1;
        break;
        if ((k >= 65) && (k <= 90))
        {
          c1 = (char)(k + 32);
          break label82;
        }
        throw v.a();
        if ((k >= 65) && (k <= 90))
        {
          c1 = (char)(k - 64);
          break label82;
        }
        throw v.a();
        if ((k >= 65) && (k <= 69))
        {
          c1 = (char)(k - 38);
          break label82;
        }
        if ((k >= 70) && (k <= 87))
        {
          c1 = (char)(k - 11);
          break label82;
        }
        throw v.a();
        if ((k >= 65) && (k <= 79))
        {
          c1 = (char)(k - 32);
          break label82;
        }
        if (k == 90)
        {
          c1 = ':';
          break label82;
        }
        throw v.a();
        localStringBuffer.append(c1);
      }
    }
    return localStringBuffer.toString();
  }
  
  private static void a(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
    throws t
  {
    int i = 1;
    int k = paramInt1 - 1;
    int m;
    int i1;
    for (int j = 0;; j = i1 * m + j)
    {
      m = i;
      if (k < 0) {
        break;
      }
      i1 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".indexOf(paramStringBuffer.charAt(k));
      int n = m + 1;
      i = n;
      if (n > paramInt2) {
        i = 1;
      }
      k -= 1;
    }
    if (paramStringBuffer.charAt(paramInt1) != a[(j % 47)]) {
      throw t.a();
    }
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y, t, v
  {
    int i2 = paramaj.b;
    int i = 0;
    while ((i < i2) && (!paramaj.a(i))) {
      i += 1;
    }
    int n = 0;
    paramHashtable = new int[6];
    int m = 0;
    int i3 = paramHashtable.length;
    int k = i;
    if (k < i2)
    {
      if ((paramaj.a(k) ^ m))
      {
        paramHashtable[n] += 1;
        j = m;
        m = i;
      }
      for (;;)
      {
        k += 1;
        i = m;
        m = j;
        break;
        if (n == i3 - 1)
        {
          if (a(paramHashtable) == c)
          {
            paramHashtable = new int[2];
            paramHashtable[0] = i;
            paramHashtable[1] = k;
            i = paramHashtable[1];
            m = paramaj.b;
            while ((i < m) && (!paramaj.a(i))) {
              i += 1;
            }
          }
          j = i + (paramHashtable[0] + paramHashtable[1]);
          i = 2;
          while (i < i3)
          {
            paramHashtable[(i - 2)] = paramHashtable[i];
            i += 1;
          }
          paramHashtable[(i3 - 2)] = 0;
          paramHashtable[(i3 - 1)] = 0;
        }
        for (i = n - 1;; i = n)
        {
          paramHashtable[i] = 1;
          if (m != 0) {
            break label282;
          }
          i1 = 1;
          m = j;
          n = i;
          j = i1;
          break;
          n += 1;
          j = i;
        }
        label282:
        int i1 = 0;
        m = j;
        n = i;
        j = i1;
      }
    }
    throw y.a();
    Object localObject1 = new StringBuffer(20);
    Object localObject2 = new int[6];
    a(paramaj, i, (int[])localObject2);
    int j = a((int[])localObject2);
    if (j < 0) {
      throw y.a();
    }
    char c1 = a(j);
    ((StringBuffer)localObject1).append(c1);
    k = 0;
    j = i;
    while (k < localObject2.length)
    {
      j += localObject2[k];
      k += 1;
    }
    for (;;)
    {
      if ((j < m) && (!paramaj.a(j)))
      {
        j += 1;
      }
      else
      {
        if (c1 == '*')
        {
          ((StringBuffer)localObject1).deleteCharAt(((StringBuffer)localObject1).length() - 1);
          if ((j == m) || (!paramaj.a(j))) {
            throw y.a();
          }
          if (((StringBuffer)localObject1).length() < 2) {
            throw y.a();
          }
          k = ((StringBuffer)localObject1).length();
          a((StringBuffer)localObject1, k - 2, 20);
          a((StringBuffer)localObject1, k - 1, 15);
          ((StringBuffer)localObject1).setLength(((StringBuffer)localObject1).length() - 2);
          paramaj = a((StringBuffer)localObject1);
          k = paramHashtable[1];
          float f1 = (paramHashtable[0] + k) / 2.0F;
          float f2 = (i + j) / 2.0F;
          paramHashtable = new ad(f1, paramInt);
          localObject1 = new ad(f2, paramInt);
          localObject2 = q.d;
          return new ab(paramaj, null, new ad[] { paramHashtable, localObject1 }, (q)localObject2);
        }
        i = j;
        break;
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */