package RLSDK;

import java.util.Hashtable;

public final class bk
  extends bu
{
  private static final char[] a = "0123456789-$:/.+ABCDTN".toCharArray();
  private static final int[] b = { 3, 6, 9, 96, 18, 66, 33, 36, 48, 72, 12, 24, 69, 81, 84, 21, 26, 41, 11, 14, 26, 41 };
  private static final char[] c = { 69, 42, 65, 66, 67, 68, 84, 78 };
  
  private static char a(int[] paramArrayOfInt)
  {
    int i3 = paramArrayOfInt.length;
    int j = Integer.MAX_VALUE;
    int m = 0;
    int k;
    int n;
    for (int i = 0;; i = n)
    {
      k = i;
      if (m >= i3) {
        break;
      }
      k = j;
      if (paramArrayOfInt[m] < j) {
        k = paramArrayOfInt[m];
      }
      n = i;
      if (paramArrayOfInt[m] > i) {
        n = paramArrayOfInt[m];
      }
      m += 1;
      j = k;
    }
    do
    {
      m = 0;
      i = 0;
      int i1;
      for (n = 0; m < i3; n = i1)
      {
        int i2 = i;
        i1 = n;
        if (paramArrayOfInt[m] > k)
        {
          i2 = i | 1 << i3 - 1 - m;
          i1 = n + 1;
        }
        m += 1;
        i = i2;
      }
      if ((n == 2) || (n == 3))
      {
        m = 0;
        while (m < b.length)
        {
          if (b[m] == i) {
            return a[m];
          }
          m += 1;
        }
      }
      i = k - 1;
      k = i;
    } while (i > j);
    return '!';
  }
  
  private static boolean a(char[] paramArrayOfChar, char paramChar)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    int i;
    if (paramArrayOfChar != null) {
      i = 0;
    }
    for (;;)
    {
      bool1 = bool2;
      if (i < paramArrayOfChar.length)
      {
        if (paramArrayOfChar[i] == paramChar) {
          bool1 = true;
        }
      }
      else {
        return bool1;
      }
      i += 1;
    }
  }
  
  private static int[] a(aj paramaj)
    throws y
  {
    int i1 = paramaj.b;
    int i = 0;
    while ((i < i1) && (!paramaj.a(i))) {
      i += 1;
    }
    int[] arrayOfInt = new int[7];
    int i2 = arrayOfInt.length;
    int j = 0;
    int k = 0;
    int m = i;
    while (m < i1) {
      if ((paramaj.a(m) ^ j))
      {
        arrayOfInt[k] += 1;
        m += 1;
      }
      else
      {
        if (k == i2 - 1) {
          try
          {
            if ((a(c, a(arrayOfInt))) && (paramaj.a(Math.max(0, i - (m - i) / 2), i))) {
              return new int[] { i, m };
            }
          }
          catch (IllegalArgumentException localIllegalArgumentException)
          {
            int n = i + (arrayOfInt[0] + arrayOfInt[1]);
            i = 2;
            while (i < i2)
            {
              arrayOfInt[(i - 2)] = arrayOfInt[i];
              i += 1;
            }
            arrayOfInt[(i2 - 2)] = 0;
            arrayOfInt[(i2 - 1)] = 0;
            k -= 1;
            i = n;
          }
        }
        for (;;)
        {
          arrayOfInt[k] = 1;
          j ^= 0x1;
          break;
          k += 1;
        }
      }
    }
    throw y.a();
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y
  {
    paramHashtable = a(paramaj);
    paramHashtable[1] = 0;
    int i = paramHashtable[1];
    int n = paramaj.b;
    while ((i < n) && (!paramaj.a(i))) {
      i += 1;
    }
    Object localObject1 = new StringBuffer();
    Object localObject2 = new int[7];
    Object tmp62_60 = localObject2;
    tmp62_60[0] = 0;
    Object tmp66_62 = tmp62_60;
    tmp66_62[1] = 0;
    Object tmp70_66 = tmp66_62;
    tmp70_66[2] = 0;
    Object tmp74_70 = tmp70_66;
    tmp74_70[3] = 0;
    Object tmp78_74 = tmp74_70;
    tmp78_74[4] = 0;
    Object tmp82_78 = tmp78_74;
    tmp82_78[5] = 0;
    Object tmp86_82 = tmp82_78;
    tmp86_82[6] = 0;
    tmp86_82;
    a(paramaj, i, (int[])localObject2);
    char c1 = a((int[])localObject2);
    if (c1 == '!') {
      throw y.a();
    }
    ((StringBuffer)localObject1).append(c1);
    int k = 0;
    int j = i;
    while (k < localObject2.length)
    {
      j += localObject2[k];
      k += 1;
    }
    for (;;)
    {
      if ((j < n) && (!paramaj.a(j)))
      {
        j += 1;
      }
      else
      {
        if (j >= n)
        {
          int m = 0;
          k = 0;
          while (k < localObject2.length)
          {
            m += localObject2[k];
            k += 1;
          }
          if ((j != n) && ((j - i - m) / 2 < m)) {
            throw y.a();
          }
          if (((StringBuffer)localObject1).length() < 2) {
            throw y.a();
          }
          c1 = ((StringBuffer)localObject1).charAt(0);
          if (!a(c, c1)) {
            throw y.a();
          }
          for (k = 1; k < ((StringBuffer)localObject1).length(); k = m + 1)
          {
            m = k;
            if (((StringBuffer)localObject1).charAt(k) == c1)
            {
              m = k;
              if (k + 1 != ((StringBuffer)localObject1).length())
              {
                ((StringBuffer)localObject1).delete(k + 1, ((StringBuffer)localObject1).length() - 1);
                m = ((StringBuffer)localObject1).length();
              }
            }
          }
          if (((StringBuffer)localObject1).length() > 6)
          {
            ((StringBuffer)localObject1).deleteCharAt(((StringBuffer)localObject1).length() - 1);
            ((StringBuffer)localObject1).deleteCharAt(0);
            float f1 = (paramHashtable[1] + paramHashtable[0]) / 2.0F;
            float f2 = (i + j) / 2.0F;
            paramaj = ((StringBuffer)localObject1).toString();
            paramHashtable = new ad(f1, paramInt);
            localObject1 = new ad(f2, paramInt);
            localObject2 = q.b;
            return new ab(paramaj, null, new ad[] { paramHashtable, localObject1 }, (q)localObject2);
          }
          throw y.a();
        }
        i = j;
        break;
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */