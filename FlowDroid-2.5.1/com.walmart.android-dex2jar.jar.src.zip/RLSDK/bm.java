package RLSDK;

import java.util.Hashtable;

public final class bm
  extends bu
{
  static final int[] a;
  private static final char[] b = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".toCharArray();
  private static final int c = arrayOfInt[39];
  private final boolean d;
  private final boolean e;
  
  static
  {
    int[] arrayOfInt = new int[44];
    arrayOfInt[0] = 52;
    arrayOfInt[1] = 'ġ';
    arrayOfInt[2] = 97;
    arrayOfInt[3] = 'Š';
    arrayOfInt[4] = 49;
    arrayOfInt[5] = 'İ';
    arrayOfInt[6] = 112;
    arrayOfInt[7] = 37;
    arrayOfInt[8] = 'Ĥ';
    arrayOfInt[9] = 100;
    arrayOfInt[10] = 'ĉ';
    arrayOfInt[11] = 73;
    arrayOfInt[12] = 'ň';
    arrayOfInt[13] = 25;
    arrayOfInt[14] = 'Ę';
    arrayOfInt[15] = 88;
    arrayOfInt[16] = 13;
    arrayOfInt[17] = 'Č';
    arrayOfInt[18] = 76;
    arrayOfInt[19] = 28;
    arrayOfInt[20] = 'ă';
    arrayOfInt[21] = 67;
    arrayOfInt[22] = 'ł';
    arrayOfInt[23] = 19;
    arrayOfInt[24] = 'Ē';
    arrayOfInt[25] = 82;
    arrayOfInt[26] = 7;
    arrayOfInt[27] = 'Ć';
    arrayOfInt[28] = 70;
    arrayOfInt[29] = 22;
    arrayOfInt[30] = 'Ɓ';
    arrayOfInt[31] = 'Á';
    arrayOfInt[32] = 'ǀ';
    arrayOfInt[33] = '';
    arrayOfInt[34] = 'Ɛ';
    arrayOfInt[35] = 'Ð';
    arrayOfInt[36] = '';
    arrayOfInt[37] = 'Ƅ';
    arrayOfInt[38] = 'Ä';
    arrayOfInt[39] = '';
    arrayOfInt[40] = '¨';
    arrayOfInt[41] = '¢';
    arrayOfInt[42] = '';
    arrayOfInt[43] = 42;
    arrayOfInt;
    a = arrayOfInt;
  }
  
  public bm()
  {
    this.d = false;
    this.e = false;
  }
  
  public bm(boolean paramBoolean)
  {
    this.d = paramBoolean;
    this.e = false;
  }
  
  private static char a(int paramInt)
    throws y
  {
    int i = 0;
    while (i < a.length)
    {
      if (a[i] == paramInt) {
        return b[i];
      }
      i += 1;
    }
    throw y.a();
  }
  
  private static int a(int[] paramArrayOfInt)
  {
    int i4 = paramArrayOfInt.length;
    int i;
    for (int j = 0;; j = i)
    {
      i = Integer.MAX_VALUE;
      int k = 0;
      while (k < i4)
      {
        n = paramArrayOfInt[k];
        m = i;
        if (n < i)
        {
          m = i;
          if (n > j) {
            m = n;
          }
        }
        k += 1;
        i = m;
      }
      int n = 0;
      j = 0;
      int m = 0;
      int i2;
      int i1;
      for (k = 0; n < i4; k = i1)
      {
        int i5 = paramArrayOfInt[n];
        int i3 = j;
        i2 = m;
        i1 = k;
        if (paramArrayOfInt[n] > i)
        {
          i3 = j | 1 << i4 - 1 - n;
          i1 = k + 1;
          i2 = m + i5;
        }
        n += 1;
        j = i3;
        m = i2;
      }
      if (k == 3)
      {
        n = k;
        k = 0;
        for (;;)
        {
          i1 = j;
          if (k < i4)
          {
            i1 = j;
            if (n > 0)
            {
              i2 = paramArrayOfInt[k];
              i1 = n;
              if (paramArrayOfInt[k] <= i) {
                break label203;
              }
              i1 = n - 1;
              if (i2 << 1 < m) {
                break label203;
              }
              i1 = -1;
            }
          }
          return i1;
          label203:
          k += 1;
          n = i1;
        }
      }
      if (k <= 3) {
        return -1;
      }
    }
  }
  
  private static String a(StringBuffer paramStringBuffer)
    throws v
  {
    int j = paramStringBuffer.length();
    StringBuffer localStringBuffer = new StringBuffer(j);
    int i = 0;
    if (i < j)
    {
      char c1 = paramStringBuffer.charAt(i);
      int k;
      if ((c1 == '+') || (c1 == '$') || (c1 == '%') || (c1 == '/'))
      {
        k = paramStringBuffer.charAt(i + 1);
        switch (c1)
        {
        default: 
          c1 = '\000';
          label106:
          localStringBuffer.append(c1);
          i += 1;
        }
      }
      for (;;)
      {
        i += 1;
        break;
        if ((k >= 65) && (k <= 90))
        {
          c1 = (char)(k + 32);
          break label106;
        }
        throw v.a();
        if ((k >= 65) && (k <= 90))
        {
          c1 = (char)(k - 64);
          break label106;
        }
        throw v.a();
        if ((k >= 65) && (k <= 69))
        {
          c1 = (char)(k - 38);
          break label106;
        }
        if ((k >= 70) && (k <= 87))
        {
          c1 = (char)(k - 11);
          break label106;
        }
        throw v.a();
        if ((k >= 65) && (k <= 79))
        {
          c1 = (char)(k - 32);
          break label106;
        }
        if (k == 90)
        {
          c1 = ':';
          break label106;
        }
        throw v.a();
        localStringBuffer.append(c1);
      }
    }
    return localStringBuffer.toString();
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y, t, v
  {
    int i2 = paramaj.b;
    int i = 0;
    while ((i < i2) && (!paramaj.a(i))) {
      i += 1;
    }
    int n = 0;
    paramHashtable = new int[9];
    int m = 0;
    int i3 = paramHashtable.length;
    int k = i;
    if (k < i2)
    {
      if ((paramaj.a(k) ^ m))
      {
        paramHashtable[n] += 1;
        j = m;
        m = i;
      }
      for (;;)
      {
        k += 1;
        i = m;
        m = j;
        break;
        if (n == i3 - 1)
        {
          if ((a(paramHashtable) == c) && (paramaj.a(Math.max(0, i - (k - i) / 2), i)))
          {
            paramHashtable = new int[2];
            paramHashtable[0] = i;
            paramHashtable[1] = k;
            i = paramHashtable[1];
            n = paramaj.b;
            while ((i < n) && (!paramaj.a(i))) {
              i += 1;
            }
          }
          j = i + (paramHashtable[0] + paramHashtable[1]);
          i = 2;
          while (i < i3)
          {
            paramHashtable[(i - 2)] = paramHashtable[i];
            i += 1;
          }
          paramHashtable[(i3 - 2)] = 0;
          paramHashtable[(i3 - 1)] = 0;
        }
        for (i = n - 1;; i = n)
        {
          paramHashtable[i] = 1;
          if (m != 0) {
            break label305;
          }
          i1 = 1;
          m = j;
          n = i;
          j = i1;
          break;
          n += 1;
          j = i;
        }
        label305:
        int i1 = 0;
        m = j;
        n = i;
        j = i1;
      }
    }
    throw y.a();
    Object localObject1 = new StringBuffer(20);
    Object localObject2 = new int[9];
    a(paramaj, i, (int[])localObject2);
    int j = a((int[])localObject2);
    if (j < 0) {
      throw y.a();
    }
    char c1 = a(j);
    ((StringBuffer)localObject1).append(c1);
    k = 0;
    j = i;
    while (k < localObject2.length)
    {
      j += localObject2[k];
      k += 1;
    }
    for (;;)
    {
      if ((j < n) && (!paramaj.a(j)))
      {
        j += 1;
      }
      else
      {
        if (c1 == '*')
        {
          ((StringBuffer)localObject1).deleteCharAt(((StringBuffer)localObject1).length() - 1);
          m = 0;
          k = 0;
          while (k < localObject2.length)
          {
            m += localObject2[k];
            k += 1;
          }
          if ((j != n) && ((j - i - m) / 2 < m)) {
            throw y.a();
          }
          if (this.d)
          {
            n = ((StringBuffer)localObject1).length() - 1;
            m = 0;
            k = 0;
            while (k < n)
            {
              m += "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".indexOf(((StringBuffer)localObject1).charAt(k));
              k += 1;
            }
            if (((StringBuffer)localObject1).charAt(n) != b[(m % 43)]) {
              throw t.a();
            }
            ((StringBuffer)localObject1).deleteCharAt(n);
          }
          if (((StringBuffer)localObject1).length() == 0) {
            throw y.a();
          }
          if (this.e) {}
          for (paramaj = a((StringBuffer)localObject1);; paramaj = ((StringBuffer)localObject1).toString())
          {
            float f1 = (paramHashtable[1] + paramHashtable[0]) / 2.0F;
            float f2 = (i + j) / 2.0F;
            paramHashtable = new ad(f1, paramInt);
            localObject1 = new ad(f2, paramInt);
            localObject2 = q.c;
            return new ab(paramaj, null, new ad[] { paramHashtable, localObject1 }, (q)localObject2);
          }
        }
        i = j;
        break;
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */