package RLSDK;

final class dc
{
  private static final char[] a = { 59, 60, 62, 64, 91, 92, 125, 95, 96, 126, 33, 13, 9, 44, 58, 10, 45, 46, 36, 47, 34, 124, 42, 40, 41, 63, 123, 125, 39 };
  private static final char[] b = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 38, 13, 9, 44, 58, 35, 45, 46, 36, 47, 43, 37, 42, 61, 94 };
  private static final String[] c = { "000000000000000000000000000000000000000000001", "000000000000000000000000000000000000000000900", "000000000000000000000000000000000000000810000", "000000000000000000000000000000000000729000000", "000000000000000000000000000000000656100000000", "000000000000000000000000000000590490000000000", "000000000000000000000000000531441000000000000", "000000000000000000000000478296900000000000000", "000000000000000000000430467210000000000000000", "000000000000000000387420489000000000000000000", "000000000000000348678440100000000000000000000", "000000000000313810596090000000000000000000000", "000000000282429536481000000000000000000000000", "000000254186582832900000000000000000000000000", "000228767924549610000000000000000000000000000", "205891132094649000000000000000000000000000000" };
  
  private static int a(int paramInt1, int[] paramArrayOfInt, int paramInt2, StringBuffer paramStringBuffer)
  {
    long l1;
    char[] arrayOfChar;
    int[] arrayOfInt;
    int j;
    int i;
    int m;
    long l2;
    int k;
    if (paramInt1 == 901)
    {
      paramInt1 = 0;
      l1 = 0L;
      arrayOfChar = new char[6];
      arrayOfInt = new int[6];
      j = 0;
      i = paramInt2;
      paramInt2 = paramInt1;
      if ((i < paramArrayOfInt[0]) && (j == 0))
      {
        paramInt1 = i + 1;
        i = paramArrayOfInt[i];
        if (i < 900)
        {
          arrayOfInt[paramInt2] = i;
          m = paramInt2 + 1;
          l2 = l1 * 900L + i;
          k = j;
        }
      }
    }
    for (;;)
    {
      j = k;
      l1 = l2;
      paramInt2 = m;
      i = paramInt1;
      if (m % 5 != 0) {
        break;
      }
      j = k;
      l1 = l2;
      paramInt2 = m;
      i = paramInt1;
      if (m <= 0) {
        break;
      }
      paramInt2 = 0;
      l1 = l2;
      for (;;)
      {
        if (paramInt2 < 6)
        {
          arrayOfChar[(5 - paramInt2)] = ((char)(int)(l1 % 256L));
          l1 >>= 8;
          paramInt2 += 1;
          continue;
          if ((i != 900) && (i != 901) && (i != 902) && (i != 924) && (i != 928) && (i != 923) && (i != 922)) {
            break label559;
          }
          paramInt1 -= 1;
          k = 1;
          l2 = l1;
          m = paramInt2;
          break;
        }
      }
      paramStringBuffer.append(arrayOfChar);
      paramInt2 = 0;
      j = k;
      i = paramInt1;
      break;
      paramInt1 = paramInt2 / 5 * 5;
      for (;;)
      {
        j = i;
        if (paramInt1 >= paramInt2) {
          break;
        }
        paramStringBuffer.append((char)arrayOfInt[paramInt1]);
        paramInt1 += 1;
      }
      j = paramInt2;
      if (paramInt1 == 924)
      {
        i = 0;
        l1 = 0L;
        k = 0;
        j = paramInt2;
        if (paramInt2 < paramArrayOfInt[0])
        {
          j = paramInt2;
          if (k == 0)
          {
            paramInt1 = paramInt2 + 1;
            paramInt2 = paramArrayOfInt[paramInt2];
            if (paramInt2 < 900)
            {
              m = i + 1;
              l2 = l1 * 900L + paramInt2;
              j = k;
            }
          }
        }
      }
      for (;;)
      {
        l1 = l2;
        k = j;
        i = m;
        paramInt2 = paramInt1;
        if (m % 5 != 0) {
          break;
        }
        l1 = l2;
        k = j;
        i = m;
        paramInt2 = paramInt1;
        if (m <= 0) {
          break;
        }
        arrayOfChar = new char[6];
        paramInt2 = 0;
        l1 = l2;
        for (;;)
        {
          if (paramInt2 < 6)
          {
            arrayOfChar[(5 - paramInt2)] = ((char)(int)(0xFF & l1));
            paramInt2 += 1;
            l1 >>= 8;
            continue;
            if ((paramInt2 != 900) && (paramInt2 != 901) && (paramInt2 != 902) && (paramInt2 != 924) && (paramInt2 != 928) && (paramInt2 != 923) && (paramInt2 != 922)) {
              break label544;
            }
            paramInt1 -= 1;
            j = 1;
            l2 = l1;
            m = i;
            break;
          }
        }
        paramStringBuffer.append(arrayOfChar);
        k = j;
        i = m;
        paramInt2 = paramInt1;
        break;
        return j;
        label544:
        l2 = l1;
        j = k;
        m = i;
      }
      label559:
      k = j;
      l2 = l1;
      m = paramInt2;
    }
  }
  
  private static int a(int[] paramArrayOfInt, int paramInt, StringBuffer paramStringBuffer)
  {
    int[] arrayOfInt1 = new int[paramArrayOfInt[0] << 1];
    int[] arrayOfInt2 = new int[paramArrayOfInt[0] << 1];
    int n = 0;
    int j = 0;
    int i = paramInt;
    paramInt = j;
    while ((i < paramArrayOfInt[0]) && (paramInt == 0))
    {
      j = i + 1;
      i = paramArrayOfInt[i];
      if (i < 900)
      {
        arrayOfInt1[n] = (i / 30);
        arrayOfInt1[(n + 1)] = (i % 30);
        n += 2;
        i = j;
      }
      else
      {
        switch (i)
        {
        default: 
          i = j;
          break;
        case 900: 
          i = j - 1;
          paramInt = 1;
          break;
        case 901: 
          i = j - 1;
          paramInt = 1;
          break;
        case 902: 
          i = j - 1;
          paramInt = 1;
          break;
        case 913: 
          arrayOfInt1[n] = 913;
          i = j + 1;
          arrayOfInt2[n] = paramArrayOfInt[j];
          n += 1;
          break;
        case 924: 
          i = j - 1;
          paramInt = 1;
        }
      }
    }
    int k = 0;
    j = 0;
    int i1 = 0;
    int i2;
    char c2;
    int m;
    char c1;
    if (i1 < n)
    {
      i2 = arrayOfInt1[i1];
      c2 = '\000';
      switch (k)
      {
      default: 
        paramInt = k;
        m = j;
        c1 = c2;
      }
    }
    for (;;)
    {
      if (c1 != 0) {
        paramStringBuffer.append(c1);
      }
      i1 += 1;
      j = m;
      k = paramInt;
      break;
      if (i2 < 26)
      {
        c1 = (char)(i2 + 65);
        m = j;
        paramInt = k;
      }
      else if (i2 == 26)
      {
        c1 = ' ';
        m = j;
        paramInt = k;
      }
      else if (i2 == 27)
      {
        paramInt = 1;
        c1 = c2;
        m = j;
      }
      else if (i2 == 28)
      {
        paramInt = 2;
        c1 = c2;
        m = j;
      }
      else if (i2 == 29)
      {
        paramInt = 5;
        c1 = c2;
        m = k;
      }
      else
      {
        c1 = c2;
        m = j;
        paramInt = k;
        if (i2 == 913)
        {
          paramStringBuffer.append((char)arrayOfInt2[i1]);
          c1 = c2;
          m = j;
          paramInt = k;
          continue;
          if (i2 < 26)
          {
            c1 = (char)(i2 + 97);
            m = j;
            paramInt = k;
          }
          else if (i2 == 26)
          {
            c1 = ' ';
            m = j;
            paramInt = k;
          }
          else if (i2 == 27)
          {
            paramInt = 4;
            c1 = c2;
            m = k;
          }
          else if (i2 == 28)
          {
            paramInt = 2;
            c1 = c2;
            m = j;
          }
          else if (i2 == 29)
          {
            paramInt = 5;
            c1 = c2;
            m = k;
          }
          else
          {
            c1 = c2;
            m = j;
            paramInt = k;
            if (i2 == 913)
            {
              paramStringBuffer.append((char)arrayOfInt2[i1]);
              c1 = c2;
              m = j;
              paramInt = k;
              continue;
              if (i2 < 25)
              {
                c1 = b[i2];
                m = j;
                paramInt = k;
              }
              else if (i2 == 25)
              {
                paramInt = 3;
                c1 = c2;
                m = j;
              }
              else if (i2 == 26)
              {
                c1 = ' ';
                m = j;
                paramInt = k;
              }
              else if (i2 == 27)
              {
                paramInt = 1;
                c1 = c2;
                m = j;
              }
              else if (i2 == 28)
              {
                paramInt = 0;
                c1 = c2;
                m = j;
              }
              else if (i2 == 29)
              {
                paramInt = 5;
                c1 = c2;
                m = k;
              }
              else
              {
                c1 = c2;
                m = j;
                paramInt = k;
                if (i2 == 913)
                {
                  paramStringBuffer.append((char)arrayOfInt2[i1]);
                  c1 = c2;
                  m = j;
                  paramInt = k;
                  continue;
                  if (i2 < 29)
                  {
                    c1 = a[i2];
                    m = j;
                    paramInt = k;
                  }
                  else if (i2 == 29)
                  {
                    paramInt = 0;
                    c1 = c2;
                    m = j;
                  }
                  else
                  {
                    c1 = c2;
                    m = j;
                    paramInt = k;
                    if (i2 == 913)
                    {
                      paramStringBuffer.append((char)arrayOfInt2[i1]);
                      c1 = c2;
                      m = j;
                      paramInt = k;
                      continue;
                      if (i2 < 26)
                      {
                        c1 = (char)(i2 + 65);
                        paramInt = j;
                        m = j;
                      }
                      else
                      {
                        if (i2 == 26)
                        {
                          c1 = ' ';
                          paramInt = j;
                          m = j;
                          continue;
                          if (i2 < 29)
                          {
                            c1 = a[i2];
                            paramInt = j;
                            m = j;
                            continue;
                          }
                          if (i2 == 29)
                          {
                            paramInt = 0;
                            c1 = c2;
                            m = j;
                            continue;
                            return i;
                          }
                        }
                        paramInt = j;
                        c1 = c2;
                        m = j;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  
  static ap a(int[] paramArrayOfInt)
    throws v
  {
    StringBuffer localStringBuffer = new StringBuffer(100);
    int j = 2;
    int i = paramArrayOfInt[1];
    if (j < paramArrayOfInt[0])
    {
      switch (i)
      {
      default: 
        i = a(paramArrayOfInt, j - 1, localStringBuffer);
      }
      for (;;)
      {
        if (i >= paramArrayOfInt.length) {
          break label155;
        }
        j = i + 1;
        i = paramArrayOfInt[i];
        break;
        i = a(paramArrayOfInt, j, localStringBuffer);
        continue;
        i = a(i, paramArrayOfInt, j, localStringBuffer);
        continue;
        i = b(paramArrayOfInt, j, localStringBuffer);
        continue;
        i = a(i, paramArrayOfInt, j, localStringBuffer);
        continue;
        i = a(i, paramArrayOfInt, j, localStringBuffer);
      }
      label155:
      throw v.a();
    }
    return new ap(null, localStringBuffer.toString(), null, null);
  }
  
  private static StringBuffer a(String paramString1, String paramString2)
  {
    StringBuffer localStringBuffer1 = new StringBuffer(5);
    StringBuffer localStringBuffer2 = new StringBuffer(5);
    StringBuffer localStringBuffer3 = new StringBuffer(paramString1.length());
    int i = 0;
    while (i < paramString1.length())
    {
      localStringBuffer3.append('0');
      i += 1;
    }
    i = paramString1.length() - 3;
    int j = 0;
    while (i >= 0)
    {
      localStringBuffer1.setLength(0);
      localStringBuffer1.append(paramString1.charAt(i));
      localStringBuffer1.append(paramString1.charAt(i + 1));
      localStringBuffer1.append(paramString1.charAt(i + 2));
      localStringBuffer2.setLength(0);
      localStringBuffer2.append(paramString2.charAt(i));
      localStringBuffer2.append(paramString2.charAt(i + 1));
      localStringBuffer2.append(paramString2.charAt(i + 2));
      int m = Integer.parseInt(localStringBuffer1.toString());
      int n = Integer.parseInt(localStringBuffer2.toString());
      int k = (m + n + j) % 1000;
      j = (j + (m + n)) / 1000;
      localStringBuffer3.setCharAt(i + 2, (char)(k % 10 + 48));
      localStringBuffer3.setCharAt(i + 1, (char)(k / 10 % 10 + 48));
      localStringBuffer3.setCharAt(i, (char)(k / 100 + 48));
      i -= 3;
    }
    return localStringBuffer3;
  }
  
  private static int b(int[] paramArrayOfInt, int paramInt, StringBuffer paramStringBuffer)
  {
    int j = 0;
    int k = 0;
    int[] arrayOfInt = new int[15];
    int n = paramInt;
    int i;
    int m;
    if ((n < paramArrayOfInt[0]) && (k == 0))
    {
      paramInt = n + 1;
      n = paramArrayOfInt[n];
      i = k;
      if (paramInt == paramArrayOfInt[0]) {
        i = 1;
      }
      if (n < 900)
      {
        arrayOfInt[j] = n;
        m = j + 1;
      }
    }
    for (;;)
    {
      if ((m % 15 != 0) && (n != 902))
      {
        k = i;
        j = m;
        n = paramInt;
        if (i == 0) {
          break;
        }
      }
      j = 0;
      Object localObject2 = null;
      Object localObject3;
      if (j < m)
      {
        localObject3 = c[(m - j - 1)];
        int i1 = arrayOfInt[j];
        localObject1 = new StringBuffer(((String)localObject3).length());
        k = 0;
        for (;;)
        {
          if (k < ((String)localObject3).length())
          {
            ((StringBuffer)localObject1).append('0');
            k += 1;
            continue;
            if ((n != 900) && (n != 901) && (n != 924) && (n != 928) && (n != 923) && (n != 922)) {
              break label525;
            }
            paramInt -= 1;
            i = 1;
            m = j;
            break;
          }
        }
        n = i1 / 100;
        int i2 = i1 / 10;
        k = 0;
        while (k < i1 % 10)
        {
          localObject1 = a(((StringBuffer)localObject1).toString(), (String)localObject3);
          k += 1;
        }
        k = 0;
        while (k < i2 % 10)
        {
          localObject1 = a(((StringBuffer)localObject1).toString(), ((String)localObject3 + '0').substring(1));
          k += 1;
        }
        k = 0;
        while (k < n)
        {
          localObject1 = a(((StringBuffer)localObject1).toString(), ((String)localObject3 + "00").substring(2));
          k += 1;
        }
        if (localObject2 == null) {}
        for (;;)
        {
          j += 1;
          localObject2 = localObject1;
          break;
          localObject1 = a(((StringBuffer)localObject2).toString(), ((StringBuffer)localObject1).toString());
        }
      }
      j = 0;
      label436:
      if (j < ((StringBuffer)localObject2).length()) {
        if (((StringBuffer)localObject2).charAt(j) != '1') {}
      }
      for (Object localObject1 = ((StringBuffer)localObject2).toString().substring(j + 1);; localObject1 = null)
      {
        localObject3 = localObject1;
        if (localObject1 == null) {
          localObject3 = ((StringBuffer)localObject2).toString();
        }
        paramStringBuffer.append((String)localObject3);
        j = 0;
        k = i;
        n = paramInt;
        break;
        j += 1;
        break label436;
        return n;
      }
      label525:
      m = j;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */