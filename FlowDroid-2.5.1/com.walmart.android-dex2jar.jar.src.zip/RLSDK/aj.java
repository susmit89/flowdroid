package RLSDK;

public final class aj
{
  public int[] a;
  public int b;
  
  public aj()
  {
    this.b = 0;
    this.a = new int[1];
  }
  
  public aj(int paramInt)
  {
    this.b = paramInt;
    this.a = new int[paramInt + 31 >> 5];
  }
  
  public final void a()
  {
    int[] arrayOfInt = new int[this.a.length];
    int j = this.b;
    int i = 0;
    while (i < j)
    {
      if (a(j - i - 1))
      {
        int k = i >> 5;
        arrayOfInt[k] |= 1 << (i & 0x1F);
      }
      i += 1;
    }
    this.a = arrayOfInt;
  }
  
  public final boolean a(int paramInt)
  {
    return (this.a[(paramInt >> 5)] & 1 << (paramInt & 0x1F)) != 0;
  }
  
  public final boolean a(int paramInt1, int paramInt2)
  {
    if (paramInt2 < paramInt1) {
      throw new IllegalArgumentException();
    }
    if (paramInt2 == paramInt1) {
      return true;
    }
    int i1 = paramInt2 - 1;
    int n = paramInt1 >> 5;
    int i2 = i1 >> 5;
    int i = n;
    while (i <= i2)
    {
      if (i > n)
      {
        paramInt2 = 0;
        if (i >= i2) {
          break label99;
        }
      }
      label99:
      for (int j = 31;; j = i1 & 0x1F)
      {
        if ((paramInt2 != 0) || (j != 31)) {
          break label109;
        }
        m = -1;
        if ((m & this.a[i]) == 0) {
          break label144;
        }
        return false;
        paramInt2 = paramInt1 & 0x1F;
        break;
      }
      label109:
      int m = 0;
      int k = paramInt2;
      paramInt2 = m;
      for (;;)
      {
        m = paramInt2;
        if (k > j) {
          break;
        }
        paramInt2 |= 1 << k;
        k += 1;
      }
      label144:
      i += 1;
    }
    return true;
  }
  
  public final void b(int paramInt)
  {
    int[] arrayOfInt = this.a;
    int i = paramInt >> 5;
    arrayOfInt[i] |= 1 << (paramInt & 0x1F);
  }
  
  public final String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer(this.b);
    int i = 0;
    if (i < this.b)
    {
      if ((i & 0x7) == 0) {
        localStringBuffer.append(' ');
      }
      if (a(i)) {}
      for (char c = 'X';; c = '.')
      {
        localStringBuffer.append(c);
        i += 1;
        break;
      }
    }
    return localStringBuffer.toString();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */