package RLSDK;

import java.util.Hashtable;
import java.util.Vector;

public final class x
  implements z
{
  private Hashtable a;
  private Vector b;
  
  private ab b(s params)
    throws y
  {
    int j = this.b.size();
    int i = 0;
    while (i < j)
    {
      Object localObject = (z)this.b.elementAt(i);
      try
      {
        localObject = ((z)localObject).a(params, this.a);
        return (ab)localObject;
      }
      catch (aa localaa)
      {
        i += 1;
      }
    }
    throw y.a();
  }
  
  public final ab a(s params)
    throws y
  {
    if (this.b == null) {
      a(null);
    }
    return b(params);
  }
  
  public final ab a(s params, Hashtable paramHashtable)
    throws y
  {
    a(paramHashtable);
    return b(params);
  }
  
  public final void a()
  {
    int j = this.b.size();
    int i = 0;
    while (i < j)
    {
      ((z)this.b.elementAt(i)).a();
      i += 1;
    }
  }
  
  public final void a(Hashtable paramHashtable)
  {
    int j = 0;
    this.a = paramHashtable;
    int i;
    if ((paramHashtable != null) && (paramHashtable.containsKey(u.d)))
    {
      i = 1;
      if (paramHashtable != null) {
        break label321;
      }
    }
    label321:
    for (Vector localVector = null;; localVector = (Vector)paramHashtable.get(u.c))
    {
      this.b = new Vector();
      if (localVector != null)
      {
        if ((localVector.contains(q.n)) || (localVector.contains(q.o)) || (localVector.contains(q.h)) || (localVector.contains(q.g)) || (localVector.contains(q.b)) || (localVector.contains(q.c)) || (localVector.contains(q.d)) || (localVector.contains(q.e)) || (localVector.contains(q.i)) || (localVector.contains(q.l)) || (localVector.contains(q.m))) {
          j = 1;
        }
        if ((j != 0) && (i == 0)) {
          this.b.addElement(new bs(paramHashtable));
        }
        if (localVector.contains(q.k)) {
          this.b.addElement(new df());
        }
        if (localVector.contains(q.f)) {
          this.b.addElement(new bd());
        }
        if (localVector.contains(q.a)) {
          this.b.addElement(new ag());
        }
        if (localVector.contains(q.j)) {
          this.b.addElement(new da());
        }
        if ((j != 0) && (i != 0)) {
          this.b.addElement(new bs(paramHashtable));
        }
      }
      return;
      i = 0;
      break;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */