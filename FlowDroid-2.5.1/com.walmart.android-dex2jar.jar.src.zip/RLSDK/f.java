package RLSDK;

import android.graphics.Point;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.Size;
import android.os.Build;
import android.os.Build.VERSION;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

final class f
{
  static int a;
  private static final String b = f.class.getSimpleName();
  private static final Pattern c = Pattern.compile(",");
  private Point d;
  private int e;
  private String f;
  
  f()
  {
    a = Build.VERSION.SDK_INT;
    this.d = new Point();
  }
  
  final Point a()
  {
    return this.d;
  }
  
  final void a(Camera paramCamera)
  {
    Camera.Parameters localParameters = paramCamera.getParameters();
    this.e = localParameters.getPreviewFormat();
    this.f = localParameters.get("preview-format");
    Object localObject2 = localParameters.getSupportedPreviewSizes();
    Object localObject1 = Build.MODEL;
    Object localObject3 = Build.BRAND;
    String str1 = Build.PRODUCT;
    String str2 = Build.MANUFACTURER;
    int j = Integer.MAX_VALUE;
    int i = j;
    if (((String)localObject3).equals("motorala"))
    {
      i = j;
      if (((String)localObject1).equals("Xoom")) {
        i = 921599;
      }
    }
    if (((String)localObject1).equals("ADR6400L")) {
      i = 921599;
    }
    j = i;
    if (str2.equals("HTC"))
    {
      j = i;
      if (((String)localObject1).equals("HTC Desire"))
      {
        j = i;
        if (str1.equals("htc_bravo")) {
          j = 921599;
        }
      }
    }
    if (((String)localObject1).equals("Desire HD")) {
      j = 307199;
    }
    i = j;
    if (str2.equals("LGE"))
    {
      i = j;
      if (((String)localObject1).equals("VM670")) {
        i = 345599;
      }
    }
    j = i;
    if (str2.equals("samsung"))
    {
      j = i;
      if (((String)localObject1).equals("SCH-I535")) {
        j = 921600;
      }
    }
    if (a == 7) {
      j = 196607;
    }
    for (;;)
    {
      localObject1 = (Camera.Size)((List)localObject2).get(0);
      localObject3 = ((List)localObject2).iterator();
      i = 0;
      while (((Iterator)localObject3).hasNext())
      {
        localObject2 = (Camera.Size)((Iterator)localObject3).next();
        int k = ((Camera.Size)localObject2).height * ((Camera.Size)localObject2).width;
        if (k <= j)
        {
          if (k <= i) {
            break label412;
          }
          i = k;
          localObject1 = localObject2;
        }
      }
      label399:
      label412:
      for (;;)
      {
        break;
        localParameters.setPreviewSize(((Camera.Size)localObject1).width, ((Camera.Size)localObject1).height);
        this.d.x = ((Camera.Size)localObject1).width;
        this.d.y = ((Camera.Size)localObject1).height;
        localObject1 = localParameters.getSupportedFlashModes();
        if (localObject1 != null)
        {
          if ((!Build.MODEL.contains("Behold II")) || (Build.VERSION.SDK_INT != 3)) {
            break label399;
          }
          localParameters.set("flash-value", 1);
        }
        for (;;)
        {
          if (((List)localObject1).contains("off")) {
            localParameters.set("flash-mode", "off");
          }
          try
          {
            paramCamera.setParameters(localParameters);
            return;
          }
          catch (RuntimeException paramCamera)
          {
            return;
          }
          localParameters.set("flash-value", 2);
        }
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */