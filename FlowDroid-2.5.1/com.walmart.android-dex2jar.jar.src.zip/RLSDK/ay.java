package RLSDK;

public final class ay
{
  private final ak a;
  private final int b;
  private final int c;
  private final int d;
  private final int e;
  private final int f;
  private final int g;
  
  public ay(ak paramak)
    throws y
  {
    this.a = paramak;
    this.b = paramak.b;
    this.c = paramak.a;
    this.d = (this.c - 30 >> 1);
    this.e = (this.c + 30 >> 1);
    this.g = (this.b - 30 >> 1);
    this.f = (this.b + 30 >> 1);
    if ((this.g < 0) || (this.d < 0) || (this.f >= this.b) || (this.e >= this.c)) {
      throw y.a();
    }
  }
  
  public ay(ak paramak, int paramInt1, int paramInt2)
    throws y
  {
    this.a = paramak;
    this.b = paramak.b;
    this.c = paramak.a;
    this.d = (paramInt1 - 7);
    this.e = (paramInt1 + 7);
    this.g = (paramInt2 - 7);
    this.f = (paramInt2 + 7);
    if ((this.g < 0) || (this.d < 0) || (this.f >= this.b) || (this.e >= this.c)) {
      throw y.a();
    }
  }
  
  private ad a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    float f1 = paramFloat1 - paramFloat3;
    float f2 = paramFloat2 - paramFloat4;
    int j = (int)((float)Math.sqrt(f1 * f1 + f2 * f2) + 0.5F);
    paramFloat3 = (paramFloat3 - paramFloat1) / j;
    paramFloat4 = (paramFloat4 - paramFloat2) / j;
    int i = 0;
    while (i < j)
    {
      int k = (int)(i * paramFloat3 + paramFloat1 + 0.5F);
      int m = (int)(i * paramFloat4 + paramFloat2 + 0.5F);
      if (this.a.a(k, m)) {
        return new ad(k, m);
      }
      i += 1;
    }
    return null;
  }
  
  private boolean a(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int i = paramInt1;
    if (paramBoolean) {
      while (paramInt1 <= paramInt2)
      {
        if (this.a.a(paramInt1, paramInt3)) {
          return true;
        }
        paramInt1 += 1;
      }
    }
    do
    {
      i += 1;
      if (i > paramInt2) {
        break;
      }
    } while (!this.a.a(paramInt3, i));
    return true;
    return false;
  }
  
  public final ad[] a()
    throws y
  {
    int k = this.d;
    int i3 = this.e;
    int i = this.g;
    int n = this.f;
    int i7 = 0;
    int i6 = 1;
    int i5 = 0;
    int m;
    int i8;
    int j;
    boolean bool;
    int i1;
    if (i6 != 0)
    {
      m = 0;
      i8 = 1;
      j = i3;
      while ((i8 != 0) && (j < this.c))
      {
        bool = a(i, n, j, false);
        i8 = bool;
        if (bool)
        {
          j += 1;
          m = 1;
          i8 = bool;
        }
      }
      if (j >= this.c)
      {
        i1 = 1;
        m = j;
        j = n;
        n = i1;
      }
    }
    for (;;)
    {
      if ((n == 0) && (i5 != 0))
      {
        i1 = m - k;
        ad localad1 = null;
        n = 1;
        ad localad2;
        for (;;)
        {
          localad2 = localad1;
          if (n >= i1) {
            break;
          }
          localad1 = a(k, j - n, k + n, j);
          localad2 = localad1;
          if (localad1 != null) {
            break;
          }
          n += 1;
        }
        i8 = 1;
        i1 = m;
        m = n;
        while ((i8 != 0) && (m < this.b))
        {
          bool = a(k, j, m, true);
          i8 = bool;
          if (bool)
          {
            m += 1;
            i1 = 1;
            i8 = bool;
          }
        }
        if (m >= this.b)
        {
          n = 1;
          i1 = j;
          j = m;
          m = i1;
          continue;
        }
        i8 = 1;
        int i4 = i1;
        i1 = k;
        while ((i8 != 0) && (i1 >= 0))
        {
          bool = a(i, m, i1, false);
          i8 = bool;
          if (bool)
          {
            i1 -= 1;
            i4 = 1;
            i8 = bool;
          }
        }
        if (i1 < 0)
        {
          n = 1;
          i2 = j;
          k = i1;
          j = m;
          m = i2;
          continue;
        }
        i8 = 1;
        int i2 = i;
        while ((i8 != 0) && (i2 >= 0))
        {
          bool = a(i1, j, i2, true);
          i8 = bool;
          if (bool)
          {
            i2 -= 1;
            i4 = 1;
            i8 = bool;
          }
        }
        if (i2 < 0)
        {
          n = 1;
          i3 = j;
          k = i1;
          j = m;
          i = i2;
          m = i3;
          continue;
        }
        n = m;
        i = i2;
        i3 = j;
        k = i1;
        i6 = i4;
        if (i4 == 0) {
          break;
        }
        i5 = 1;
        n = m;
        i = i2;
        i3 = j;
        k = i1;
        i6 = i4;
        break;
        if (localad2 == null) {
          throw y.a();
        }
        localad1 = null;
        n = 1;
        ad localad3;
        for (;;)
        {
          localad3 = localad1;
          if (n >= i1) {
            break;
          }
          localad1 = a(k, i + n, k + n, i);
          localad3 = localad1;
          if (localad1 != null) {
            break;
          }
          n += 1;
        }
        if (localad3 == null) {
          throw y.a();
        }
        localad1 = null;
        k = 1;
        ad localad4;
        for (;;)
        {
          localad4 = localad1;
          if (k >= i1) {
            break;
          }
          localad1 = a(m, i + k, m - k, i);
          localad4 = localad1;
          if (localad1 != null) {
            break;
          }
          k += 1;
        }
        if (localad4 == null) {
          throw y.a();
        }
        localad1 = null;
        i = 1;
        ad localad5;
        for (;;)
        {
          localad5 = localad1;
          if (i >= i1) {
            break;
          }
          localad1 = a(m, j - i, m - i, j);
          localad5 = localad1;
          if (localad1 != null) {
            break;
          }
          i += 1;
        }
        if (localad5 == null) {
          throw y.a();
        }
        float f1 = localad5.a();
        float f2 = localad5.b();
        float f3 = localad2.a();
        float f4 = localad2.b();
        float f5 = localad4.a();
        float f6 = localad4.b();
        float f7 = localad3.a();
        float f8 = localad3.b();
        if (f1 < this.c / 2) {
          return new ad[] { new ad(f7 - 1.0F, f8 + 1.0F), new ad(f3 + 1.0F, f4 + 1.0F), new ad(f5 - 1.0F, f6 - 1.0F), new ad(f1 + 1.0F, f2 - 1.0F) };
        }
        return new ad[] { new ad(f7 + 1.0F, f8 + 1.0F), new ad(f3 + 1.0F, f4 - 1.0F), new ad(f5 - 1.0F, f6 + 1.0F), new ad(f1 - 1.0F, f2 - 1.0F) };
      }
      throw y.a();
      m = i3;
      j = n;
      n = i7;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */