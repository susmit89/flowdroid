package RLSDK;

public final class bb
{
  private final az a;
  
  public bb(az paramaz)
  {
    this.a = paramaz;
  }
  
  public final void a(int[] paramArrayOfInt, int paramInt)
    throws bc
  {
    Object localObject1 = new ba(this.a, paramArrayOfInt);
    Object localObject2 = new int[paramInt];
    boolean bool = this.a.equals(az.f);
    int j = 1;
    int i = 0;
    Object localObject3;
    int k;
    if (i < paramInt)
    {
      localObject3 = this.a;
      if (bool)
      {
        k = i + 1;
        label57:
        k = ((ba)localObject1).b(((az)localObject3).a(k));
        localObject2[(localObject2.length - 1 - i)] = k;
        if (k == 0) {
          break label840;
        }
        j = 0;
      }
    }
    label521:
    label534:
    label558:
    label600:
    label705:
    label715:
    label770:
    label830:
    label840:
    for (;;)
    {
      i += 1;
      break;
      k = i;
      break label57;
      if (j != 0) {
        return;
      }
      localObject2 = new ba(this.a, (int[])localObject2);
      localObject3 = this.a.a(paramInt, 1);
      if (((ba)localObject3).a() < ((ba)localObject2).a())
      {
        localObject1 = localObject2;
        localObject2 = localObject3;
      }
      for (;;)
      {
        Object localObject6 = this.a.b();
        ba localba = this.a.a();
        Object localObject5 = this.a.a();
        Object localObject7 = this.a.b();
        localObject3 = localObject1;
        Object localObject4 = localObject2;
        localObject1 = localba;
        localObject2 = localObject7;
        while (((ba)localObject4).a() >= paramInt / 2)
        {
          if (((ba)localObject4).b()) {
            throw new bc("r_{i-1} was zero");
          }
          localObject7 = this.a.a();
          i = ((ba)localObject4).a(((ba)localObject4).a());
          i = this.a.c(i);
          while ((((ba)localObject3).a() >= ((ba)localObject4).a()) && (!((ba)localObject3).b()))
          {
            j = ((ba)localObject3).a() - ((ba)localObject4).a();
            k = this.a.c(((ba)localObject3).a(((ba)localObject3).a()), i);
            localObject7 = ((ba)localObject7).a(this.a.a(j, k));
            localObject3 = ((ba)localObject3).a(((ba)localObject4).a(j, k));
          }
          localba = ((ba)localObject7).b((ba)localObject1).a((ba)localObject6);
          localObject6 = ((ba)localObject7).b((ba)localObject2).a((ba)localObject5);
          localObject5 = localObject2;
          localObject2 = localObject6;
          localObject6 = localObject1;
          localObject1 = localba;
          localObject7 = localObject3;
          localObject3 = localObject4;
          localObject4 = localObject7;
        }
        paramInt = ((ba)localObject2).a(0);
        if (paramInt == 0) {
          throw new bc("sigmaTilde(0) was zero");
        }
        paramInt = this.a.c(paramInt);
        localObject1 = ((ba)localObject2).c(paramInt);
        localObject3 = ((ba)localObject4).c(paramInt);
        localObject2 = new ba[2];
        localObject2[0] = localObject1;
        localObject2[1] = localObject3;
        localObject3 = localObject2[0];
        localObject2 = localObject2[1];
        k = ((ba)localObject3).a();
        int n;
        if (k == 1)
        {
          localObject1 = new int[1];
          localObject1[0] = ((ba)localObject3).a(1);
          int m = localObject1.length;
          localObject3 = new int[m];
          i = 0;
          if (i >= m) {
            break label770;
          }
          n = this.a.c(localObject1[i]);
          paramInt = 1;
          j = 0;
          if (j >= m) {
            break label715;
          }
          if (i == j) {
            break label830;
          }
          k = this.a.c(localObject1[j], n);
          if ((k & 0x1) != 0) {
            break label705;
          }
          k |= 0x1;
          paramInt = this.a.c(paramInt, k);
        }
        for (;;)
        {
          j += 1;
          break label558;
          localObject1 = new int[k];
          i = 0;
          paramInt = 1;
          while ((paramInt < this.a.c()) && (i < k))
          {
            j = i;
            if (((ba)localObject3).b(paramInt) == 0)
            {
              localObject1[i] = this.a.c(paramInt);
              j = i + 1;
            }
            paramInt += 1;
            i = j;
          }
          if (i != k) {
            throw new bc("Error locator degree does not match number of roots");
          }
          break label521;
          k &= 0xFFFFFFFE;
          break label600;
          localObject3[i] = this.a.c(((ba)localObject2).b(n), this.a.c(paramInt));
          if (bool) {
            localObject3[i] = this.a.c(localObject3[i], n);
          }
          i += 1;
          break label534;
          paramInt = 0;
          while (paramInt < localObject1.length)
          {
            i = paramArrayOfInt.length - 1 - this.a.b(localObject1[paramInt]);
            if (i < 0) {
              throw new bc("Bad error location");
            }
            paramArrayOfInt[i] = az.b(paramArrayOfInt[i], localObject3[paramInt]);
            paramInt += 1;
          }
          break;
        }
        localObject1 = localObject3;
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */