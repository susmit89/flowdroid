package RLSDK;

public final class bp
  extends bx
{
  private final int[] a = new int[4];
  
  protected final int a(aj paramaj, int[] paramArrayOfInt, StringBuffer paramStringBuffer)
    throws y
  {
    int[] arrayOfInt = this.a;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    arrayOfInt[2] = 0;
    arrayOfInt[3] = 0;
    int m = paramaj.b;
    int i = paramArrayOfInt[1];
    int j = 0;
    int k;
    while ((j < 4) && (i < m))
    {
      paramStringBuffer.append((char)(a(paramaj, arrayOfInt, i, d) + 48));
      k = 0;
      while (k < arrayOfInt.length)
      {
        i += arrayOfInt[k];
        k += 1;
      }
      j += 1;
    }
    i = a(paramaj, i, true, c)[1];
    j = 0;
    while ((j < 4) && (i < m))
    {
      paramStringBuffer.append((char)(a(paramaj, arrayOfInt, i, d) + 48));
      k = 0;
      while (k < arrayOfInt.length)
      {
        i += arrayOfInt[k];
        k += 1;
      }
      j += 1;
    }
    return i;
  }
  
  final q b()
  {
    return q.g;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */