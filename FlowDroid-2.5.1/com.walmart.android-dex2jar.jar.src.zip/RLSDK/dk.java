package RLSDK;

import java.util.Hashtable;

public final class dk
{
  private final bb a = new bb(az.e);
  
  public final ap a(ak paramak, Hashtable paramHashtable)
    throws v, t
  {
    Object localObject = new dg(paramak);
    paramak = ((dg)localObject).b();
    dl localdl = ((dg)localObject).a().a();
    localObject = dh.a(((dg)localObject).c(), paramak, localdl);
    int i = 0;
    int j = 0;
    while (i < localObject.length)
    {
      j += localObject[i].a();
      i += 1;
    }
    byte[] arrayOfByte1 = new byte[j];
    i = 0;
    j = 0;
    while (i < localObject.length)
    {
      int[] arrayOfInt = localObject[i];
      byte[] arrayOfByte2 = arrayOfInt.b();
      int m = arrayOfInt.a();
      int n = arrayOfByte2.length;
      arrayOfInt = new int[n];
      int k = 0;
      while (k < n)
      {
        arrayOfByte2[k] &= 0xFF;
        k += 1;
      }
      k = arrayOfByte2.length;
      try
      {
        this.a.a(arrayOfInt, k - m);
        k = 0;
        while (k < m)
        {
          arrayOfByte2[k] = ((byte)arrayOfInt[k]);
          k += 1;
        }
        k = 0;
      }
      catch (bc paramak)
      {
        throw t.a();
      }
      while (k < m)
      {
        arrayOfByte1[j] = arrayOfByte2[k];
        k += 1;
        j += 1;
      }
      i += 1;
    }
    return dj.a(arrayOfByte1, paramak, localdl, paramHashtable);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */