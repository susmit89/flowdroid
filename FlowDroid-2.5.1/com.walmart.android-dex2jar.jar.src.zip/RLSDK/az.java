package RLSDK;

public final class az
{
  public static final az a = new az(4201, 4096);
  public static final az b = new az(1033, 1024);
  public static final az c = new az(67, 64);
  public static final az d = new az(19, 16);
  public static final az e = new az(285, 256);
  public static final az f;
  public static final az g;
  private int[] h;
  private int[] i;
  private ba j;
  private ba k;
  private final int l;
  private final int m;
  private boolean n = false;
  
  static
  {
    az localaz = new az(301, 256);
    f = localaz;
    g = localaz;
  }
  
  private az(int paramInt1, int paramInt2)
  {
    this.m = paramInt1;
    this.l = paramInt2;
    if (paramInt2 <= 0) {
      d();
    }
  }
  
  static int b(int paramInt1, int paramInt2)
  {
    return paramInt1 ^ paramInt2;
  }
  
  private void d()
  {
    this.h = new int[this.l];
    this.i = new int[this.l];
    int i2 = 0;
    int i1 = 1;
    while (i2 < this.l)
    {
      this.h[i2] = i1;
      int i3 = i1 << 1;
      i1 = i3;
      if (i3 >= this.l) {
        i1 = (i3 ^ this.m) & this.l - 1;
      }
      i2 += 1;
    }
    i1 = 0;
    while (i1 < this.l - 1)
    {
      this.i[this.h[i1]] = i1;
      i1 += 1;
    }
    this.j = new ba(this, new int[] { 0 });
    this.k = new ba(this, new int[] { 1 });
    this.n = true;
  }
  
  private void e()
  {
    if (!this.n) {
      d();
    }
  }
  
  final int a(int paramInt)
  {
    e();
    return this.h[paramInt];
  }
  
  final ba a()
  {
    e();
    return this.j;
  }
  
  final ba a(int paramInt1, int paramInt2)
  {
    e();
    if (paramInt1 < 0) {
      throw new IllegalArgumentException();
    }
    if (paramInt2 == 0) {
      return this.j;
    }
    int[] arrayOfInt = new int[paramInt1 + 1];
    arrayOfInt[0] = paramInt2;
    return new ba(this, arrayOfInt);
  }
  
  final int b(int paramInt)
  {
    e();
    if (paramInt == 0) {
      throw new IllegalArgumentException();
    }
    return this.i[paramInt];
  }
  
  final ba b()
  {
    e();
    return this.k;
  }
  
  public final int c()
  {
    return this.l;
  }
  
  final int c(int paramInt)
  {
    e();
    if (paramInt == 0) {
      throw new ArithmeticException();
    }
    return this.h[(this.l - this.i[paramInt] - 1)];
  }
  
  final int c(int paramInt1, int paramInt2)
  {
    e();
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return 0;
    }
    int i1;
    if ((paramInt1 >= 0) && (paramInt2 >= 0) && (paramInt1 < this.l))
    {
      i1 = paramInt1;
      if (paramInt2 < this.l) {}
    }
    else
    {
      i1 = paramInt1 + 1;
    }
    paramInt1 = this.i[i1] + this.i[paramInt2];
    int[] arrayOfInt = this.h;
    paramInt2 = this.l;
    return arrayOfInt[(paramInt1 / this.l + paramInt1 % paramInt2)];
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/az.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */