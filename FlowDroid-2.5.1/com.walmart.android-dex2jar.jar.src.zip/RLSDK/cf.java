package RLSDK;

final class cf
{
  private final boolean a;
  private final ca b;
  private final ca c;
  private final cb d;
  
  cf(ca paramca1, ca paramca2, cb paramcb, boolean paramBoolean)
  {
    this.b = paramca1;
    this.c = paramca2;
    this.d = paramcb;
    this.a = paramBoolean;
  }
  
  final boolean a()
  {
    return this.a;
  }
  
  final ca b()
  {
    return this.b;
  }
  
  final ca c()
  {
    return this.c;
  }
  
  final cb d()
  {
    return this.d;
  }
  
  public final boolean e()
  {
    return this.c == null;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */