package RLSDK;

abstract class co
  extends cq
{
  co(aj paramaj)
  {
    super(paramaj);
  }
  
  protected final void a(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    int i = 0;
    int j;
    while (i < 4)
    {
      j = this.b.a(i * 10 + paramInt1, 10);
      if (j / 100 == 0) {
        paramStringBuffer.append('0');
      }
      if (j / 10 == 0) {
        paramStringBuffer.append('0');
      }
      paramStringBuffer.append(j);
      i += 1;
    }
    paramInt1 = 0;
    i = 0;
    while (paramInt1 < 13)
    {
      int k = paramStringBuffer.charAt(paramInt1 + paramInt2) - '0';
      j = k;
      if ((paramInt1 & 0x1) == 0) {
        j = k * 3;
      }
      i += j;
      paramInt1 += 1;
    }
    paramInt2 = 10 - i % 10;
    paramInt1 = paramInt2;
    if (paramInt2 == 10) {
      paramInt1 = 0;
    }
    paramStringBuffer.append(paramInt1);
  }
  
  protected final void b(StringBuffer paramStringBuffer, int paramInt)
  {
    paramStringBuffer.append("(01)");
    int i = paramStringBuffer.length();
    paramStringBuffer.append('9');
    a(paramStringBuffer, paramInt, i);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/co.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */