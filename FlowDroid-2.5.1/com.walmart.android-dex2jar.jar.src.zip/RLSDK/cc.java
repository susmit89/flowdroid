package RLSDK;

final class cc
  extends ca
{
  private final cb a;
  private int b;
  
  cc(int paramInt1, int paramInt2, cb paramcb)
  {
    super(paramInt1, paramInt2);
    this.a = paramcb;
  }
  
  final cb c()
  {
    return this.a;
  }
  
  final int d()
  {
    return this.b;
  }
  
  final void e()
  {
    this.b += 1;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */