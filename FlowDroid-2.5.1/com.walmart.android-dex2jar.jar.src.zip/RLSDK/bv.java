package RLSDK;

import java.util.Hashtable;

public final class bv
  extends bx
{
  private final bx a = new bo();
  
  private static ab a(ab paramab)
    throws v
  {
    String str = paramab.a();
    if (str.charAt(0) == '0') {
      return new ab(str.substring(1), null, paramab.b(), q.n);
    }
    throw v.a();
  }
  
  protected final int a(aj paramaj, int[] paramArrayOfInt, StringBuffer paramStringBuffer)
    throws y
  {
    return this.a.a(paramaj, paramArrayOfInt, paramStringBuffer);
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y, v, t
  {
    return a(this.a.a(paramInt, paramaj, paramHashtable));
  }
  
  public final ab a(int paramInt, aj paramaj, int[] paramArrayOfInt, Hashtable paramHashtable)
    throws y, v, t
  {
    return a(this.a.a(paramInt, paramaj, paramArrayOfInt, paramHashtable));
  }
  
  public final ab a(s params, Hashtable paramHashtable)
    throws y, v
  {
    return a(this.a.a(params, paramHashtable));
  }
  
  final q b()
  {
    return q.n;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */