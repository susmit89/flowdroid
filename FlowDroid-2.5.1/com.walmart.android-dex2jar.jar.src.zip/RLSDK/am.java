package RLSDK;

import java.util.Hashtable;

public final class am
  extends as
{
  private static Hashtable a;
  private static Hashtable b;
  private final String c;
  
  private am(int paramInt, String paramString)
  {
    super(paramInt);
    this.c = paramString;
  }
  
  public static am a(int paramInt)
  {
    if (a == null)
    {
      a = new Hashtable(29);
      b = new Hashtable(29);
      a(0, "Cp437");
      a(1, new String[] { "ISO8859_1", "ISO-8859-1" });
      a(2, "Cp437");
      a(3, new String[] { "ISO8859_1", "ISO-8859-1" });
      a(4, "ISO8859_2");
      a(5, "ISO8859_3");
      a(6, "ISO8859_4");
      a(7, "ISO8859_5");
      a(8, "ISO8859_6");
      a(9, "ISO8859_7");
      a(10, "ISO8859_8");
      a(11, "ISO8859_9");
      a(12, "ISO8859_10");
      a(13, "ISO8859_11");
      a(15, "ISO8859_13");
      a(16, "ISO8859_14");
      a(17, "ISO8859_15");
      a(18, "ISO8859_16");
      a(20, new String[] { "SJIS", "Shift_JIS" });
    }
    if ((paramInt < 0) || (paramInt >= 900)) {
      throw new IllegalArgumentException("Bad ECI value: " + paramInt);
    }
    return (am)a.get(new Integer(paramInt));
  }
  
  private static void a(int paramInt, String paramString)
  {
    am localam = new am(paramInt, paramString);
    a.put(new Integer(paramInt), localam);
    b.put(paramString, localam);
  }
  
  private static void a(int paramInt, String[] paramArrayOfString)
  {
    int i = 0;
    am localam = new am(paramInt, paramArrayOfString[0]);
    a.put(new Integer(paramInt), localam);
    paramInt = i;
    while (paramInt < paramArrayOfString.length)
    {
      b.put(paramArrayOfString[paramInt], localam);
      paramInt += 1;
    }
  }
  
  public final String a()
  {
    return this.c;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */