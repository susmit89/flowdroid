package RLSDK;

final class ci
  extends cm
{
  ci(aj paramaj)
  {
    super(paramaj);
  }
  
  protected final int a(int paramInt)
  {
    if (paramInt < 10000) {
      return paramInt;
    }
    return paramInt - 10000;
  }
  
  protected final void a(StringBuffer paramStringBuffer, int paramInt)
  {
    if (paramInt < 10000)
    {
      paramStringBuffer.append("(3202)");
      return;
    }
    paramStringBuffer.append("(3203)");
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ci.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */