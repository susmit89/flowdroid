package RLSDK;

public final class dl
{
  public static final dl a = new dl(0, 1, "L");
  public static final dl b = new dl(1, 0, "M");
  public static final dl c = new dl(2, 3, "Q");
  public static final dl d = new dl(3, 2, "H");
  private static final dl[] e = { b, a, d, c };
  private final int f;
  private final int g;
  private final String h;
  
  private dl(int paramInt1, int paramInt2, String paramString)
  {
    this.f = paramInt1;
    this.g = paramInt2;
    this.h = paramString;
  }
  
  public static dl a(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= e.length)) {
      throw new IllegalArgumentException();
    }
    return e[paramInt];
  }
  
  public final int a()
  {
    return this.f;
  }
  
  public final String toString()
  {
    return this.h;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */