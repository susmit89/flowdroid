package RLSDK;

import java.util.Hashtable;

public final class da
  implements z
{
  private static final ad[] a = new ad[0];
  private final dd b = new dd();
  
  public final ab a(s params, Hashtable paramHashtable)
    throws y, v
  {
    boolean bool2 = true;
    if ((paramHashtable != null) && (paramHashtable.containsKey(u.b)))
    {
      params = params.c();
      paramHashtable = params.a();
      int[] arrayOfInt = params.b();
      if ((paramHashtable == null) || (arrayOfInt == null)) {
        throw y.a();
      }
      int i = paramHashtable[0];
      int j = paramHashtable[1];
      int k = params.a;
      while ((i < k) && (params.a(i, j))) {
        i += 1;
      }
      if (i == k) {
        throw y.a();
      }
      int n = i - paramHashtable[0] >>> 3;
      if (n == 0) {
        throw y.a();
      }
      int i1 = paramHashtable[1];
      int i2 = arrayOfInt[1];
      j = paramHashtable[0];
      int m = params.a;
      boolean bool1 = true;
      i = 0;
      while ((j < m - 1) && (i < 8))
      {
        k = j + 1;
        boolean bool3 = params.a(k, i1);
        j = i;
        if (bool1 != bool3) {
          j = i + 1;
        }
        bool1 = bool3;
        i = j;
        j = k;
      }
      if (j == m - 1) {
        throw y.a();
      }
      int i3 = paramHashtable[0];
      i = params.a - 1;
      while ((i > i3) && (!params.a(i, i1))) {
        i -= 1;
      }
      m = 0;
      k = i;
      bool1 = bool2;
      i = m;
      while ((k > i3) && (i < 9))
      {
        m = k - 1;
        bool2 = params.a(m, i1);
        k = i;
        if (bool1 != bool2) {
          k = i + 1;
        }
        bool1 = bool2;
        i = k;
        k = m;
      }
      if (k == i3) {
        throw y.a();
      }
      m = (k - j + 1) / n;
      i2 = (i2 - i1 + 1) / n;
      if ((m == 0) || (i2 == 0)) {
        throw y.a();
      }
      i3 = n >> 1;
      paramHashtable = new ak(m, i2);
      i = 0;
      while (i < i2)
      {
        k = 0;
        while (k < m)
        {
          if (params.a(k * n + (j + i3), i1 + i3 + i * n)) {
            paramHashtable.b(k, i);
          }
          k += 1;
        }
        i += 1;
      }
      params = this.b;
      paramHashtable = dd.a(paramHashtable);
    }
    for (params = a;; params = params.e())
    {
      return new ab(paramHashtable.b(), paramHashtable.a(), params, q.j);
      params = new de(params).a();
      paramHashtable = this.b;
      paramHashtable = dd.a(params.d());
    }
  }
  
  public final void a() {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/da.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */