package RLSDK;

public final class y
  extends aa
{
  private static final y a = new y();
  
  public static y a()
  {
    return a;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */