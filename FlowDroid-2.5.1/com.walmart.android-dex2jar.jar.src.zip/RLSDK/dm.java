package RLSDK;

final class dm
{
  private static final int[][] a;
  private static final int[] b = { 0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4 };
  private final dl c;
  private final byte d;
  
  static
  {
    int[] arrayOfInt1 = { 24188, 2 };
    int[] arrayOfInt2 = { 16590, 5 };
    int[] arrayOfInt3 = { 20375, 6 };
    int[] arrayOfInt4 = { 19104, 7 };
    int[] arrayOfInt5 = { 32170, 10 };
    int[] arrayOfInt6 = { 30877, 11 };
    int[] arrayOfInt7 = { 25368, 13 };
    int[] arrayOfInt8 = { 26998, 15 };
    int[] arrayOfInt9 = { 6608, 19 };
    int[] arrayOfInt10 = { 3340, 22 };
    int[] arrayOfInt11 = { 12392, 25 };
    int[] arrayOfInt12 = { 9396, 28 };
    int[] arrayOfInt13 = { 11994, 30 };
    a = new int[][] { { 21522, 0 }, { 20773, 1 }, arrayOfInt1, { 23371, 3 }, { 17913, 4 }, arrayOfInt2, arrayOfInt3, arrayOfInt4, { 30660, 8 }, { 29427, 9 }, arrayOfInt5, arrayOfInt6, { 26159, 12 }, arrayOfInt7, { 27713, 14 }, arrayOfInt8, { 5769, 16 }, { 5054, 17 }, { 7399, 18 }, arrayOfInt9, { 1890, 20 }, { 597, 21 }, arrayOfInt10, { 2107, 23 }, { 13663, 24 }, arrayOfInt11, { 16177, 26 }, { 14854, 27 }, arrayOfInt12, { 8579, 29 }, arrayOfInt13, { 11245, 31 } };
  }
  
  private dm(int paramInt)
  {
    this.c = dl.a(paramInt >> 3 & 0x3);
    this.d = ((byte)(paramInt & 0x7));
  }
  
  static int a(int paramInt1, int paramInt2)
  {
    paramInt1 ^= paramInt2;
    paramInt2 = b[(paramInt1 & 0xF)];
    int i = b[(paramInt1 >>> 4 & 0xF)];
    int j = b[(paramInt1 >>> 8 & 0xF)];
    int k = b[(paramInt1 >>> 12 & 0xF)];
    int m = b[(paramInt1 >>> 16 & 0xF)];
    int n = b[(paramInt1 >>> 20 & 0xF)];
    int i1 = b[(paramInt1 >>> 24 & 0xF)];
    return b[(paramInt1 >>> 28 & 0xF)] + (paramInt2 + i + j + k + m + n + i1);
  }
  
  static dm b(int paramInt1, int paramInt2)
  {
    dm localdm = c(paramInt1, paramInt2);
    if (localdm != null) {
      return localdm;
    }
    return c(paramInt1 ^ 0x5412, paramInt2 ^ 0x5412);
  }
  
  private static dm c(int paramInt1, int paramInt2)
  {
    int i = 0;
    int j = Integer.MAX_VALUE;
    int k = 0;
    int[] arrayOfInt;
    int n;
    int m;
    if (k < a.length)
    {
      arrayOfInt = a[k];
      n = arrayOfInt[0];
      if ((n == paramInt1) || (n == paramInt2)) {
        return new dm(arrayOfInt[1]);
      }
      m = a(paramInt1, n);
      if (m >= j) {
        break label132;
      }
      i = arrayOfInt[1];
      j = m;
    }
    label132:
    for (;;)
    {
      if (paramInt1 != paramInt2)
      {
        m = a(paramInt2, n);
        if (m < j)
        {
          i = arrayOfInt[1];
          j = m;
        }
      }
      for (;;)
      {
        k += 1;
        break;
        if (j <= 3) {
          return new dm(i);
        }
        return null;
      }
    }
  }
  
  final dl a()
  {
    return this.c;
  }
  
  final byte b()
  {
    return this.d;
  }
  
  public final boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof dm)) {}
    do
    {
      return false;
      paramObject = (dm)paramObject;
    } while ((this.c != ((dm)paramObject).c) || (this.d != ((dm)paramObject).d));
    return true;
  }
  
  public final int hashCode()
  {
    return this.c.a() << 3 | this.d;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */