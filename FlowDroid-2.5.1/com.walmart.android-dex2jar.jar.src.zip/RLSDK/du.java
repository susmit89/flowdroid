package RLSDK;

public final class du
{
  private final ds a = paramArrayOfds[0];
  private final ds b = paramArrayOfds[1];
  private final ds c = paramArrayOfds[2];
  
  public du(ds[] paramArrayOfds) {}
  
  public final ds a()
  {
    return this.a;
  }
  
  public final ds b()
  {
    return this.b;
  }
  
  public final ds c()
  {
    return this.c;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/du.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */