package RLSDK;

final class dh
{
  private final int a;
  private final byte[] b;
  
  private dh(int paramInt, byte[] paramArrayOfByte)
  {
    this.a = paramInt;
    this.b = paramArrayOfByte;
  }
  
  static dh[] a(byte[] paramArrayOfByte, do paramdo, dl paramdl)
  {
    if (paramArrayOfByte.length != paramdo.c()) {
      throw new IllegalArgumentException();
    }
    paramdo = paramdo.a(paramdl);
    paramdl = paramdo.b();
    int i = 0;
    int j = 0;
    while (i < paramdl.length)
    {
      j += paramdl[i].a();
      i += 1;
    }
    dh[] arrayOfdh = new dh[j];
    i = 0;
    int k = 0;
    while (i < paramdl.length)
    {
      Object localObject = paramdl[i];
      j = 0;
      while (j < ((do.a)localObject).a())
      {
        m = ((do.a)localObject).b();
        arrayOfdh[k] = new dh(m, new byte[paramdo.a() + m]);
        j += 1;
        k += 1;
      }
      i += 1;
    }
    j = arrayOfdh[0].b.length;
    i = arrayOfdh.length - 1;
    while ((i >= 0) && (arrayOfdh[i].b.length != j)) {
      i -= 1;
    }
    int i1 = i + 1;
    int n = j - paramdo.a();
    j = 0;
    i = 0;
    while (j < n)
    {
      m = 0;
      while (m < k)
      {
        arrayOfdh[m].b[j] = paramArrayOfByte[i];
        m += 1;
        i += 1;
      }
      j += 1;
    }
    int m = i1;
    j = i;
    while (m < k)
    {
      arrayOfdh[m].b[n] = paramArrayOfByte[j];
      m += 1;
      j += 1;
    }
    int i2 = arrayOfdh[0].b.length;
    i = n;
    while (i < i2)
    {
      m = 0;
      if (m < k)
      {
        if (m < i1) {}
        for (n = i;; n = i + 1)
        {
          arrayOfdh[m].b[n] = paramArrayOfByte[j];
          j += 1;
          m += 1;
          break;
        }
      }
      i += 1;
    }
    return arrayOfdh;
  }
  
  final int a()
  {
    return this.a;
  }
  
  final byte[] b()
  {
    return this.b;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */