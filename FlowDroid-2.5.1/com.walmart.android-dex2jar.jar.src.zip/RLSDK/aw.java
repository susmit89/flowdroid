package RLSDK;

public final class aw
{
  private final float a;
  private final float b;
  private final float c;
  private final float d;
  private final float e;
  private final float f;
  private final float g;
  private final float h;
  private final float i;
  
  private aw(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
  {
    this.a = paramFloat1;
    this.b = paramFloat4;
    this.c = paramFloat7;
    this.d = paramFloat2;
    this.e = paramFloat5;
    this.f = paramFloat8;
    this.g = paramFloat3;
    this.h = paramFloat6;
    this.i = paramFloat9;
  }
  
  private static aw a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
  {
    float f3 = paramFloat8 - paramFloat6;
    float f1 = paramFloat2 - paramFloat4 + paramFloat6 - paramFloat8;
    if ((f3 == 0.0F) && (f1 == 0.0F)) {
      return new aw(paramFloat3 - paramFloat1, paramFloat5 - paramFloat3, paramFloat1, paramFloat4 - paramFloat2, paramFloat6 - paramFloat4, paramFloat2, 0.0F, 0.0F, 1.0F);
    }
    float f2 = paramFloat3 - paramFloat5;
    float f4 = paramFloat7 - paramFloat5;
    paramFloat5 = paramFloat1 - paramFloat3 + paramFloat5 - paramFloat7;
    paramFloat6 = paramFloat4 - paramFloat6;
    float f5 = f2 * f3 - f4 * paramFloat6;
    f3 = (f3 * paramFloat5 - f4 * f1) / f5;
    paramFloat5 = (f2 * f1 - paramFloat5 * paramFloat6) / f5;
    return new aw(paramFloat3 - paramFloat1 + f3 * paramFloat3, paramFloat7 - paramFloat1 + paramFloat5 * paramFloat7, paramFloat1, f3 * paramFloat4 + (paramFloat4 - paramFloat2), paramFloat5 * paramFloat8 + (paramFloat8 - paramFloat2), paramFloat2, f3, paramFloat5, 1.0F);
  }
  
  public static aw a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
  {
    aw localaw1 = a(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
    paramFloat1 = localaw1.e;
    paramFloat2 = localaw1.i;
    paramFloat3 = localaw1.f;
    paramFloat4 = localaw1.h;
    paramFloat5 = localaw1.f;
    paramFloat6 = localaw1.g;
    paramFloat7 = localaw1.d;
    paramFloat8 = localaw1.i;
    float f1 = localaw1.d;
    float f2 = localaw1.h;
    float f3 = localaw1.e;
    float f4 = localaw1.g;
    float f5 = localaw1.c;
    float f6 = localaw1.h;
    float f7 = localaw1.b;
    float f8 = localaw1.i;
    float f9 = localaw1.a;
    float f10 = localaw1.i;
    float f11 = localaw1.c;
    float f12 = localaw1.g;
    float f13 = localaw1.b;
    float f14 = localaw1.g;
    float f15 = localaw1.a;
    float f16 = localaw1.h;
    float f17 = localaw1.b;
    float f18 = localaw1.f;
    float f19 = localaw1.c;
    float f20 = localaw1.e;
    float f21 = localaw1.c;
    float f22 = localaw1.d;
    float f23 = localaw1.a;
    float f24 = localaw1.f;
    float f25 = localaw1.a;
    float f26 = localaw1.e;
    float f27 = localaw1.b;
    localaw1 = new aw(paramFloat1 * paramFloat2 - paramFloat3 * paramFloat4, paramFloat5 * paramFloat6 - paramFloat7 * paramFloat8, f1 * f2 - f3 * f4, f5 * f6 - f7 * f8, f9 * f10 - f11 * f12, f13 * f14 - f15 * f16, f17 * f18 - f19 * f20, f21 * f22 - f23 * f24, f25 * f26 - localaw1.d * f27);
    aw localaw2 = a(paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
    paramFloat1 = localaw2.a;
    paramFloat2 = localaw1.a;
    paramFloat3 = localaw2.d;
    paramFloat4 = localaw1.b;
    paramFloat5 = localaw2.g;
    paramFloat6 = localaw1.c;
    paramFloat7 = localaw2.a;
    paramFloat8 = localaw1.d;
    paramFloat9 = localaw2.d;
    paramFloat10 = localaw1.e;
    paramFloat11 = localaw2.g;
    paramFloat12 = localaw1.f;
    paramFloat13 = localaw2.a;
    paramFloat14 = localaw1.g;
    paramFloat15 = localaw2.d;
    paramFloat16 = localaw1.h;
    f1 = localaw2.g;
    f2 = localaw1.i;
    f3 = localaw2.b;
    f4 = localaw1.a;
    f5 = localaw2.e;
    f6 = localaw1.b;
    f7 = localaw2.h;
    f8 = localaw1.c;
    f9 = localaw2.b;
    f10 = localaw1.d;
    f11 = localaw2.e;
    f12 = localaw1.e;
    f13 = localaw2.h;
    f14 = localaw1.f;
    f15 = localaw2.b;
    f16 = localaw1.g;
    f17 = localaw2.e;
    f18 = localaw1.h;
    f19 = localaw2.h;
    f20 = localaw1.i;
    f21 = localaw2.c;
    f22 = localaw1.a;
    f23 = localaw2.f;
    f24 = localaw1.b;
    f25 = localaw2.i;
    f26 = localaw1.c;
    f27 = localaw2.c;
    float f28 = localaw1.d;
    float f29 = localaw2.f;
    float f30 = localaw1.e;
    float f31 = localaw2.i;
    float f32 = localaw1.f;
    float f33 = localaw2.c;
    float f34 = localaw1.g;
    float f35 = localaw2.f;
    float f36 = localaw1.h;
    float f37 = localaw2.i;
    return new aw(paramFloat1 * paramFloat2 + paramFloat3 * paramFloat4 + paramFloat5 * paramFloat6, paramFloat7 * paramFloat8 + paramFloat9 * paramFloat10 + paramFloat11 * paramFloat12, paramFloat13 * paramFloat14 + paramFloat15 * paramFloat16 + f1 * f2, f3 * f4 + f5 * f6 + f7 * f8, f9 * f10 + f11 * f12 + f13 * f14, f15 * f16 + f17 * f18 + f19 * f20, f21 * f22 + f23 * f24 + f25 * f26, f27 * f28 + f29 * f30 + f31 * f32, f33 * f34 + f35 * f36 + localaw1.i * f37);
  }
  
  public final void a(float[] paramArrayOfFloat)
  {
    int k = paramArrayOfFloat.length;
    float f1 = this.a;
    float f2 = this.b;
    float f3 = this.c;
    float f4 = this.d;
    float f5 = this.e;
    float f6 = this.f;
    float f7 = this.g;
    float f8 = this.h;
    float f9 = this.i;
    int j = 0;
    while (j < k)
    {
      float f10 = paramArrayOfFloat[j];
      float f11 = paramArrayOfFloat[(j + 1)];
      float f12 = f3 * f10 + f6 * f11 + f9;
      paramArrayOfFloat[j] = ((f1 * f10 + f4 * f11 + f7) / f12);
      paramArrayOfFloat[(j + 1)] = ((f10 * f2 + f11 * f5 + f8) / f12);
      j += 2;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/aw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */