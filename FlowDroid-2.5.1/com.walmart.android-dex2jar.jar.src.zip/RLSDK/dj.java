package RLSDK;

import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.Vector;

final class dj
{
  private static final char[] a = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 32, 36, 37, 42, 43, 45, 46, 47, 58 };
  
  private static char a(int paramInt)
    throws v
  {
    if (paramInt >= a.length) {
      throw v.a();
    }
    return a[paramInt];
  }
  
  static ap a(byte[] paramArrayOfByte, do paramdo, dl paramdl, Hashtable paramHashtable)
    throws v
  {
    al localal = new al(paramArrayOfByte);
    StringBuffer localStringBuffer = new StringBuffer(50);
    am localam = null;
    boolean bool = false;
    Vector localVector = new Vector(1);
    label87:
    label154:
    label319:
    label496:
    label499:
    for (;;)
    {
      dn localdn;
      if (localal.a() < 4)
      {
        localdn = dn.a;
        if (localdn.equals(dn.a)) {
          break label496;
        }
        if ((!localdn.equals(dn.h)) && (!localdn.equals(dn.i))) {
          break label154;
        }
        bool = true;
      }
      for (;;)
      {
        if (!localdn.equals(dn.a)) {
          break label499;
        }
        paramHashtable = localStringBuffer.toString();
        paramdo = localVector;
        if (localVector.isEmpty()) {
          paramdo = null;
        }
        if (paramdl == null) {}
        for (paramdl = null;; paramdl = paramdl.toString())
        {
          return new ap(paramArrayOfByte, paramHashtable, paramdo, paramdl);
          try
          {
            localdn = dn.a(localal.a(4));
          }
          catch (IllegalArgumentException paramArrayOfByte)
          {
            throw v.a();
          }
          if (localdn.equals(dn.d))
          {
            localal.a(16);
            break label87;
          }
          if (localdn.equals(dn.f))
          {
            i = localal.a(8);
            if ((i & 0x80) == 0) {
              i &= 0x7F;
            }
            for (;;)
            {
              localam = am.a(i);
              if (localam != null) {
                break label319;
              }
              throw v.a();
              if ((i & 0xC0) == 128)
              {
                i = (i & 0x3F) << 8 | localal.a(8);
              }
              else
              {
                if ((i & 0xE0) != 192) {
                  break;
                }
                i = (i & 0x1F) << 16 | localal.a(16);
              }
            }
            throw new IllegalArgumentException("Bad ECI bits starting with byte " + i);
            break label87;
          }
          if (localdn.equals(dn.j))
          {
            i = localal.a(4);
            int j = localal.a(localdn.a(paramdo));
            if (i == 1) {
              a(localal, localStringBuffer, j);
            }
            break label87;
          }
          int i = localal.a(localdn.a(paramdo));
          if (localdn.equals(dn.b))
          {
            c(localal, localStringBuffer, i);
            break label87;
          }
          if (localdn.equals(dn.c))
          {
            a(localal, localStringBuffer, i, bool);
            break label87;
          }
          if (localdn.equals(dn.e))
          {
            a(localal, localStringBuffer, i, localam, localVector, paramHashtable);
            break label87;
          }
          if (localdn.equals(dn.g))
          {
            b(localal, localStringBuffer, i);
            break label87;
          }
          throw v.a();
        }
      }
    }
  }
  
  private static void a(al paramal, StringBuffer paramStringBuffer, int paramInt)
    throws v
  {
    if (paramInt * 13 > paramal.a()) {
      throw v.a();
    }
    byte[] arrayOfByte = new byte[paramInt * 2];
    int j = 0;
    int i = paramInt;
    paramInt = j;
    if (i > 0)
    {
      j = paramal.a(13);
      j = j % 96 | j / 96 << 8;
      if (j < 959) {
        j += 41377;
      }
      for (;;)
      {
        arrayOfByte[paramInt] = ((byte)(j >> 8 & 0xFF));
        arrayOfByte[(paramInt + 1)] = ((byte)(j & 0xFF));
        i -= 1;
        paramInt += 2;
        break;
        j += 42657;
      }
    }
    try
    {
      paramStringBuffer.append(new String(arrayOfByte, "GB2312"));
      return;
    }
    catch (UnsupportedEncodingException paramal)
    {
      throw v.a();
    }
  }
  
  private static void a(al paramal, StringBuffer paramStringBuffer, int paramInt, am paramam, Vector paramVector, Hashtable paramHashtable)
    throws v
  {
    if (paramInt << 3 > paramal.a()) {
      throw v.a();
    }
    byte[] arrayOfByte = new byte[paramInt];
    int i = 0;
    while (i < paramInt)
    {
      arrayOfByte[i] = ((byte)paramal.a(8));
      i += 1;
    }
    if (paramam == null) {}
    for (paramal = ax.a(arrayOfByte, paramHashtable);; paramal = paramam.a()) {
      try
      {
        paramStringBuffer.append(new String(arrayOfByte, paramal));
        paramVector.addElement(arrayOfByte);
        return;
      }
      catch (UnsupportedEncodingException paramal)
      {
        throw v.a();
      }
    }
  }
  
  private static void a(al paramal, StringBuffer paramStringBuffer, int paramInt, boolean paramBoolean)
    throws v
  {
    int i = paramStringBuffer.length();
    while (paramInt > 1)
    {
      int j = paramal.a(11);
      paramStringBuffer.append(a(j / 45));
      paramStringBuffer.append(a(j % 45));
      paramInt -= 2;
    }
    if (paramInt == 1) {
      paramStringBuffer.append(a(paramal.a(6)));
    }
    if (paramBoolean)
    {
      paramInt = i;
      if (paramInt < paramStringBuffer.length())
      {
        if (paramStringBuffer.charAt(paramInt) == '%')
        {
          if ((paramInt >= paramStringBuffer.length() - 1) || (paramStringBuffer.charAt(paramInt + 1) != '%')) {
            break label133;
          }
          paramStringBuffer.deleteCharAt(paramInt + 1);
        }
        for (;;)
        {
          paramInt += 1;
          break;
          label133:
          paramStringBuffer.setCharAt(paramInt, '\035');
        }
      }
    }
  }
  
  private static void b(al paramal, StringBuffer paramStringBuffer, int paramInt)
    throws v
  {
    if (paramInt * 13 > paramal.a()) {
      throw v.a();
    }
    byte[] arrayOfByte = new byte[paramInt * 2];
    int j = 0;
    int i = paramInt;
    paramInt = j;
    if (i > 0)
    {
      j = paramal.a(13);
      j = j % 192 | j / 192 << 8;
      if (j < 7936) {
        j += 33088;
      }
      for (;;)
      {
        arrayOfByte[paramInt] = ((byte)(j >> 8));
        arrayOfByte[(paramInt + 1)] = ((byte)j);
        i -= 1;
        paramInt += 2;
        break;
        j += 49472;
      }
    }
    try
    {
      paramStringBuffer.append(new String(arrayOfByte, "SJIS"));
      return;
    }
    catch (UnsupportedEncodingException paramal)
    {
      throw v.a();
    }
  }
  
  private static void c(al paramal, StringBuffer paramStringBuffer, int paramInt)
    throws v
  {
    while (paramInt >= 3)
    {
      int i = paramal.a(10);
      if (i >= 1000) {
        throw v.a();
      }
      paramStringBuffer.append(a(i / 100));
      paramStringBuffer.append(a(i / 10 % 10));
      paramStringBuffer.append(a(i % 10));
      paramInt -= 3;
    }
    if (paramInt == 2)
    {
      paramInt = paramal.a(7);
      if (paramInt >= 100) {
        throw v.a();
      }
      paramStringBuffer.append(a(paramInt / 10));
      paramStringBuffer.append(a(paramInt % 10));
    }
    while (paramInt != 1) {
      return;
    }
    paramInt = paramal.a(4);
    if (paramInt >= 10) {
      throw v.a();
    }
    paramStringBuffer.append(a(paramInt));
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */