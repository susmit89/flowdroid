package RLSDK;

import java.io.UnsupportedEncodingException;
import java.util.Vector;

final class bg
{
  private static final char[] a = { 42, 42, 42, 32, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90 };
  private static final char[] b = { 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 58, 59, 60, 61, 62, 63, 64, 91, 92, 93, 94, 95 };
  private static final char[] c = { 42, 42, 42, 32, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122 };
  private static final char[] d = { 39, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 123, 124, 125, 126, 127 };
  
  private static byte a(int paramInt1, int paramInt2)
  {
    paramInt1 -= paramInt2 * 149 % 255 + 1;
    if (paramInt1 >= 0) {}
    for (;;)
    {
      return (byte)paramInt1;
      paramInt1 += 256;
    }
  }
  
  private static int a(al paramal, StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2)
    throws v
  {
    int i = 0;
    int k = paramal.a(8);
    if (k == 0) {
      throw v.a();
    }
    if (k <= 128)
    {
      if (i != 0) {}
      for (i = k + 128;; i = k)
      {
        paramStringBuffer1.append((char)(i - 1));
        return 1;
      }
    }
    if (k == 129) {
      return 0;
    }
    int j;
    if (k <= 229)
    {
      j = k - 130;
      if (j < 10) {
        paramStringBuffer1.append('0');
      }
      paramStringBuffer1.append(j);
      j = i;
    }
    label243:
    do
    {
      do
      {
        do
        {
          for (;;)
          {
            i = j;
            if (paramal.a() > 0) {
              break;
            }
            return 1;
            if (k == 230) {
              return 2;
            }
            if (k == 231) {
              return 6;
            }
            j = i;
            if (k != 232)
            {
              j = i;
              if (k != 233)
              {
                j = i;
                if (k != 234) {
                  if (k == 235)
                  {
                    j = 1;
                  }
                  else if (k == 236)
                  {
                    paramStringBuffer1.append("[)>\03605\035");
                    paramStringBuffer2.insert(0, "\036\004");
                    j = i;
                  }
                  else
                  {
                    if (k != 237) {
                      break label243;
                    }
                    paramStringBuffer1.append("[)>\03606\035");
                    paramStringBuffer2.insert(0, "\036\004");
                    j = i;
                  }
                }
              }
            }
          }
          if (k == 238) {
            return 4;
          }
          if (k == 239) {
            return 3;
          }
          if (k == 240) {
            return 5;
          }
          j = i;
        } while (k == 241);
        j = i;
      } while (k < 242);
      if (k != 254) {
        break label313;
      }
      j = i;
    } while (paramal.a() == 0);
    label313:
    throw v.a();
  }
  
  static ap a(byte[] paramArrayOfByte)
    throws v
  {
    Object localObject1 = new al(paramArrayOfByte);
    Object localObject2 = new StringBuffer(100);
    StringBuffer localStringBuffer = new StringBuffer(0);
    Vector localVector = new Vector(1);
    int i = 1;
    while (i == 1)
    {
      i = a((al)localObject1, (StringBuffer)localObject2, localStringBuffer);
      if ((i == 0) || (((al)localObject1).a() <= 0))
      {
        if (localStringBuffer.length() > 0) {
          ((StringBuffer)localObject2).append(localStringBuffer.toString());
        }
        localObject2 = ((StringBuffer)localObject2).toString();
        localObject1 = localVector;
        if (localVector.isEmpty()) {
          localObject1 = null;
        }
        return new ap(paramArrayOfByte, (String)localObject2, (Vector)localObject1, null);
      }
    }
    switch (i)
    {
    default: 
      throw v.a();
    case 2: 
      a((al)localObject1, (StringBuffer)localObject2);
    }
    for (;;)
    {
      i = 1;
      break;
      b((al)localObject1, (StringBuffer)localObject2);
      continue;
      c((al)localObject1, (StringBuffer)localObject2);
      continue;
      d((al)localObject1, (StringBuffer)localObject2);
      continue;
      a((al)localObject1, (StringBuffer)localObject2, localVector);
    }
  }
  
  private static void a(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    paramInt1 = (paramInt1 << 8) + paramInt2 - 1;
    paramInt2 = paramInt1 / 1600;
    paramArrayOfInt[0] = paramInt2;
    paramInt1 -= paramInt2 * 1600;
    paramInt2 = paramInt1 / 40;
    paramArrayOfInt[1] = paramInt2;
    paramArrayOfInt[2] = (paramInt1 - paramInt2 * 40);
  }
  
  private static void a(al paramal, StringBuffer paramStringBuffer)
    throws v
  {
    int[] arrayOfInt = new int[3];
    int i = 0;
    label200:
    label313:
    do
    {
      if (paramal.a() == 8) {}
      do
      {
        return;
        j = paramal.a(8);
      } while (j == 254);
      a(j, paramal.a(8), arrayOfInt);
      int k = 0;
      int j = 0;
      if (k < 3)
      {
        int m = arrayOfInt[k];
        char c1;
        switch (j)
        {
        default: 
          throw v.a();
        case 0: 
          if (m < 3)
          {
            m += 1;
            j = i;
            i = m;
          }
          for (;;)
          {
            m = k + 1;
            k = i;
            i = j;
            j = k;
            k = m;
            break;
            if (m >= a.length) {
              break label200;
            }
            c1 = a[m];
            if (i != 0)
            {
              paramStringBuffer.append((char)(c1 + ''));
              i = j;
              j = 0;
            }
            else
            {
              paramStringBuffer.append(c1);
              m = i;
              i = j;
              j = m;
            }
          }
          throw v.a();
        case 1: 
          if (i != 0)
          {
            paramStringBuffer.append((char)(m + 128));
            i = 0;
          }
          for (;;)
          {
            j = i;
            i = 0;
            break;
            paramStringBuffer.append(m);
          }
        case 2: 
          if (m < b.length)
          {
            c1 = b[m];
            if (i != 0)
            {
              paramStringBuffer.append((char)(c1 + ''));
              i = 0;
            }
          }
          for (;;)
          {
            j = i;
            i = 0;
            break;
            paramStringBuffer.append(c1);
            continue;
            if (m == 27) {
              throw v.a();
            }
            if (m != 30) {
              break label313;
            }
            i = 1;
          }
          throw v.a();
        }
        if (i != 0)
        {
          paramStringBuffer.append((char)(m + 224));
          i = 0;
        }
        for (;;)
        {
          j = i;
          i = 0;
          break;
          paramStringBuffer.append((char)(m + 96));
        }
      }
    } while (paramal.a() > 0);
  }
  
  private static void a(al paramal, StringBuffer paramStringBuffer, Vector paramVector)
    throws v
  {
    int j = 3;
    int i = a(paramal.a(8), 2);
    if (i == 0) {
      i = paramal.a() / 8;
    }
    while (i < 0)
    {
      throw v.a();
      if (i >= 250)
      {
        i = (i - 249) * 250 + a(paramal.a(8), 3);
        j = 4;
      }
    }
    byte[] arrayOfByte = new byte[i];
    int k = 0;
    while (k < i)
    {
      if (paramal.a() < 8) {
        throw v.a();
      }
      arrayOfByte[k] = a(paramal.a(8), j);
      k += 1;
      j += 1;
    }
    paramVector.addElement(arrayOfByte);
    try
    {
      paramStringBuffer.append(new String(arrayOfByte, "ISO8859_1"));
      return;
    }
    catch (UnsupportedEncodingException paramal)
    {
      throw new RuntimeException("Platform does not support required encoding: " + paramal);
    }
  }
  
  private static void b(al paramal, StringBuffer paramStringBuffer)
    throws v
  {
    int[] arrayOfInt = new int[3];
    int i = 0;
    int j = 0;
    label167:
    label279:
    do
    {
      if (paramal.a() == 8) {}
      do
      {
        return;
        k = paramal.a(8);
      } while (k == 254);
      a(k, paramal.a(8), arrayOfInt);
      int k = 0;
      if (k < 3)
      {
        int m = arrayOfInt[k];
        char c1;
        switch (i)
        {
        default: 
          throw v.a();
        case 0: 
          if (m < 3) {
            i = m + 1;
          }
          for (;;)
          {
            k += 1;
            break;
            if (m >= c.length) {
              break label167;
            }
            c1 = c[m];
            if (j != 0)
            {
              paramStringBuffer.append((char)(c1 + ''));
              j = 0;
            }
            else
            {
              paramStringBuffer.append(c1);
            }
          }
          throw v.a();
        case 1: 
          if (j != 0)
          {
            paramStringBuffer.append((char)(m + 128));
            j = 0;
          }
          for (;;)
          {
            i = 0;
            break;
            paramStringBuffer.append(m);
          }
        case 2: 
          if (m < b.length)
          {
            c1 = b[m];
            if (j != 0)
            {
              paramStringBuffer.append((char)(c1 + ''));
              j = 0;
            }
          }
          for (;;)
          {
            i = 0;
            break;
            paramStringBuffer.append(c1);
            continue;
            if (m == 27) {
              throw v.a();
            }
            if (m != 30) {
              break label279;
            }
            j = 1;
          }
          throw v.a();
        }
        if (m < d.length)
        {
          c1 = d[m];
          if (j != 0)
          {
            paramStringBuffer.append((char)(c1 + ''));
            j = 0;
          }
          for (;;)
          {
            i = 0;
            break;
            paramStringBuffer.append(c1);
          }
        }
        throw v.a();
      }
    } while (paramal.a() > 0);
  }
  
  private static void c(al paramal, StringBuffer paramStringBuffer)
    throws v
  {
    int[] arrayOfInt = new int[3];
    label154:
    do
    {
      if (paramal.a() == 8) {}
      do
      {
        return;
        i = paramal.a(8);
      } while (i == 254);
      a(i, paramal.a(8), arrayOfInt);
      int i = 0;
      if (i < 3)
      {
        int j = arrayOfInt[i];
        if (j == 0) {
          paramStringBuffer.append('\r');
        }
        for (;;)
        {
          i += 1;
          break;
          if (j == 1)
          {
            paramStringBuffer.append('*');
          }
          else if (j == 2)
          {
            paramStringBuffer.append('>');
          }
          else if (j == 3)
          {
            paramStringBuffer.append(' ');
          }
          else if (j < 14)
          {
            paramStringBuffer.append((char)(j + 44));
          }
          else
          {
            if (j >= 40) {
              break label154;
            }
            paramStringBuffer.append((char)(j + 51));
          }
        }
        throw v.a();
      }
    } while (paramal.a() > 0);
  }
  
  private static void d(al paramal, StringBuffer paramStringBuffer)
  {
    int i = 0;
    if (paramal.a() <= 16) {
      label11:
      return;
    }
    int j = 0;
    label14:
    int k;
    if (j < 4)
    {
      k = paramal.a(6);
      if (k != 31) {
        break label84;
      }
      i = 1;
    }
    label81:
    label84:
    for (;;)
    {
      if (i == 0)
      {
        if ((k & 0x20) != 0) {
          break label81;
        }
        k |= 0x40;
      }
      for (;;)
      {
        paramStringBuffer.append(k);
        j += 1;
        break label14;
        if (i != 0) {
          break label11;
        }
        if (paramal.a() > 0) {
          break;
        }
        return;
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */