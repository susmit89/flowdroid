package RLSDK;

import android.content.ContentResolver;
import android.provider.Settings.Secure;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public final class p
{
  private static String a = null;
  
  public static String a()
  {
    return a;
  }
  
  public static void a(ContentResolver paramContentResolver)
  {
    long l2 = 0L;
    if (a != null) {}
    for (;;)
    {
      return;
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("http://android.ebay.com/");
      localStringBuilder.append(Settings.Secure.getString(paramContentResolver, "android_id"));
      try
      {
        paramContentResolver = MessageDigest.getInstance("SHA-1");
        paramContentResolver = paramContentResolver.digest(localStringBuilder.toString().getBytes());
        if (paramContentResolver.length == 20)
        {
          paramContentResolver[6] = ((byte)(paramContentResolver[6] & 0xF));
          paramContentResolver[6] = ((byte)(paramContentResolver[6] | 0x50));
          paramContentResolver[8] = ((byte)(paramContentResolver[8] & 0xBF));
          paramContentResolver[8] = ((byte)(paramContentResolver[8] | 0x80));
          int i = 0;
          long l1 = 0L;
          while (i < 8)
          {
            l1 = l1 << 8 ^ paramContentResolver[i] & 0xFF;
            i += 1;
          }
          i = 8;
          while (i < 16)
          {
            l2 = l2 << 8 ^ paramContentResolver[i] & 0xFF;
            i += 1;
          }
          paramContentResolver = new UUID(l1, l2).toString().toUpperCase();
          a = paramContentResolver + "," + "1" + "," + "0";
          return;
        }
      }
      catch (NoSuchAlgorithmException paramContentResolver) {}
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */