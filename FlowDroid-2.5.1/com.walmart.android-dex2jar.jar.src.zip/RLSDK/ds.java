package RLSDK;

public final class ds
  extends ad
{
  private final float a;
  private int b;
  
  ds(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    super(paramFloat1, paramFloat2);
    this.a = paramFloat3;
    this.b = 1;
  }
  
  final boolean a(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (Math.abs(paramFloat2 - b()) <= paramFloat1)
    {
      bool1 = bool2;
      if (Math.abs(paramFloat3 - a()) <= paramFloat1)
      {
        paramFloat1 = Math.abs(paramFloat1 - this.a);
        if (paramFloat1 > 1.0F)
        {
          bool1 = bool2;
          if (paramFloat1 / this.a > 1.0F) {}
        }
        else
        {
          bool1 = true;
        }
      }
    }
    return bool1;
  }
  
  public final float c()
  {
    return this.a;
  }
  
  final int d()
  {
    return this.b;
  }
  
  final void e()
  {
    this.b += 1;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */