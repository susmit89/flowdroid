package RLSDK;

import java.util.Vector;

final class dq
{
  private final ak a;
  private final Vector b;
  private final int c;
  private final int d;
  private final int e;
  private final int f;
  private final float g;
  private final int[] h;
  private final ae i;
  
  dq(ak paramak, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, ae paramae)
  {
    this.a = paramak;
    this.b = new Vector(5);
    this.c = paramInt1;
    this.d = paramInt2;
    this.e = paramInt3;
    this.f = paramInt4;
    this.g = paramFloat;
    this.h = new int[3];
    this.i = paramae;
  }
  
  private static float a(int[] paramArrayOfInt, int paramInt)
  {
    return paramInt - paramArrayOfInt[2] - paramArrayOfInt[1] / 2.0F;
  }
  
  private dp a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int j = paramArrayOfInt[0];
    int k = paramArrayOfInt[1];
    j = paramArrayOfInt[2] + (j + k);
    float f2 = a(paramArrayOfInt, paramInt2);
    k = (int)f2;
    int m = paramArrayOfInt[1] * 2;
    ak localak = this.a;
    int n = localak.b;
    int[] arrayOfInt = this.h;
    arrayOfInt[0] = 0;
    arrayOfInt[1] = 0;
    arrayOfInt[2] = 0;
    paramInt2 = paramInt1;
    while ((paramInt2 >= 0) && (localak.a(k, paramInt2)) && (arrayOfInt[1] <= m))
    {
      arrayOfInt[1] += 1;
      paramInt2 -= 1;
    }
    float f1;
    float f3;
    if ((paramInt2 < 0) || (arrayOfInt[1] > m))
    {
      f1 = NaN.0F;
      if (!Float.isNaN(f1))
      {
        f3 = (paramArrayOfInt[0] + paramArrayOfInt[1] + paramArrayOfInt[2]) / 3.0F;
        paramInt2 = this.b.size();
        paramInt1 = 0;
      }
    }
    else
    {
      for (;;)
      {
        if (paramInt1 >= paramInt2) {
          break label466;
        }
        if (((dp)this.b.elementAt(paramInt1)).a(f3, f1, f2))
        {
          return new dp(f2, f1, f3);
          while ((paramInt2 >= 0) && (!localak.a(k, paramInt2)) && (arrayOfInt[0] <= m))
          {
            arrayOfInt[0] += 1;
            paramInt2 -= 1;
          }
          if (arrayOfInt[0] > m)
          {
            f1 = NaN.0F;
            break;
          }
          paramInt1 += 1;
          while ((paramInt1 < n) && (localak.a(k, paramInt1)) && (arrayOfInt[1] <= m))
          {
            arrayOfInt[1] += 1;
            paramInt1 += 1;
          }
          if ((paramInt1 == n) || (arrayOfInt[1] > m))
          {
            f1 = NaN.0F;
            break;
          }
          while ((paramInt1 < n) && (!localak.a(k, paramInt1)) && (arrayOfInt[2] <= m))
          {
            arrayOfInt[2] += 1;
            paramInt1 += 1;
          }
          if (arrayOfInt[2] > m)
          {
            f1 = NaN.0F;
            break;
          }
          if (Math.abs(arrayOfInt[0] + arrayOfInt[1] + arrayOfInt[2] - j) * 5 >= j * 2)
          {
            f1 = NaN.0F;
            break;
          }
          if (a(arrayOfInt))
          {
            f1 = a(arrayOfInt, paramInt1);
            break;
          }
          f1 = NaN.0F;
          break;
        }
        paramInt1 += 1;
      }
      label466:
      paramArrayOfInt = new dp(f2, f1, f3);
      this.b.addElement(paramArrayOfInt);
      if (this.i != null) {
        this.i.a(paramArrayOfInt);
      }
    }
    return null;
  }
  
  private boolean a(int[] paramArrayOfInt)
  {
    float f1 = this.g;
    float f2 = f1 / 2.0F;
    int j = 0;
    while (j < 3)
    {
      if (Math.abs(f1 - paramArrayOfInt[j]) >= f2) {
        return false;
      }
      j += 1;
    }
    return true;
  }
  
  final dp a()
    throws y
  {
    int i1 = this.c;
    int i2 = this.f;
    int i3 = i1 + this.e;
    int i4 = this.d;
    int[] arrayOfInt = new int[3];
    int m = 0;
    while (m < i2)
    {
      if ((m & 0x1) == 0) {}
      int i5;
      for (int j = m + 1 >> 1;; j = -(m + 1 >> 1))
      {
        i5 = i4 + (i2 >> 1) + j;
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        arrayOfInt[2] = 0;
        j = i1;
        while ((j < i3) && (!this.a.a(j, i5))) {
          j += 1;
        }
      }
      int k = 0;
      int n = j;
      j = k;
      Object localObject;
      if (n < i3) {
        if (this.a.a(n, i5))
        {
          k = j;
          if (j == 1) {
            break label243;
          }
          if (j == 2) {
            if (a(arrayOfInt))
            {
              localObject = a(arrayOfInt, i5, n);
              if (localObject == null) {}
            }
          }
        }
      }
      label243:
      dp localdp;
      do
      {
        return (dp)localObject;
        arrayOfInt[0] = arrayOfInt[2];
        arrayOfInt[1] = 1;
        arrayOfInt[2] = 0;
        j = 1;
        for (;;)
        {
          n += 1;
          break;
          j += 1;
          arrayOfInt[j] += 1;
          continue;
          k = j;
          if (j == 1) {
            k = j + 1;
          }
          arrayOfInt[k] += 1;
          j = k;
        }
        if (!a(arrayOfInt)) {
          break label288;
        }
        localdp = a(arrayOfInt, i5, i3);
        localObject = localdp;
      } while (localdp != null);
      label288:
      m += 1;
    }
    if (!this.b.isEmpty()) {
      return (dp)this.b.elementAt(0);
    }
    throw y.a();
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */