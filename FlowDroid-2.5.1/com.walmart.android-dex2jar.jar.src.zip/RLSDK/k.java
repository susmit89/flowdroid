package RLSDK;

import android.content.Context;
import android.graphics.Region;
import android.graphics.Region.Op;
import android.view.SurfaceView;
import android.widget.FrameLayout;

final class k
  extends SurfaceView
{
  k(Context paramContext)
  {
    super(paramContext);
  }
  
  public final boolean gatherTransparentRegion(Region paramRegion)
  {
    FrameLayout localFrameLayout = (FrameLayout)getParent();
    int i = localFrameLayout.getWidth();
    int j = localFrameLayout.getHeight();
    if ((i > 0) && (j > 0))
    {
      int[] arrayOfInt = new int[2];
      localFrameLayout.getLocationInWindow(arrayOfInt);
      int k = arrayOfInt[0];
      int m = arrayOfInt[1];
      paramRegion.op(k, m, i + k, j + m, Region.Op.UNION);
    }
    return true;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */