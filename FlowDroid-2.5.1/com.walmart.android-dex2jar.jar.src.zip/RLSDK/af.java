package RLSDK;

public final class af
  extends ar
{
  private final boolean a;
  private final int b;
  private final int c;
  
  public af(ak paramak, ad[] paramArrayOfad, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    super(paramak, paramArrayOfad);
    this.a = paramBoolean;
    this.b = paramInt1;
    this.c = paramInt2;
  }
  
  public final int a()
  {
    return this.c;
  }
  
  public final int b()
  {
    return this.b;
  }
  
  public final boolean c()
  {
    return this.a;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */