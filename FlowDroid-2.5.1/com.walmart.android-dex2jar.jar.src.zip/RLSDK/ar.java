package RLSDK;

public class ar
{
  private final ak a;
  private final ad[] b;
  
  public ar(ak paramak, ad[] paramArrayOfad)
  {
    this.a = paramak;
    this.b = paramArrayOfad;
  }
  
  public final ak d()
  {
    return this.a;
  }
  
  public final ad[] e()
  {
    return this.b;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */