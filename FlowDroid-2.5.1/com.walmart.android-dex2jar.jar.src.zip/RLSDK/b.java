package RLSDK;

import android.os.AsyncTask;
import java.util.ArrayList;
import java.util.Map;

public final class b
{
  private static ArrayList<b> a = new ArrayList();
  
  public static void a(String paramString, Map<String, String> paramMap)
  {
    paramString = new b(paramString, paramMap);
    a.add(paramString);
    paramString = new a((byte)0);
    paramMap = (ArrayList)a.clone();
    a.clear();
    paramString.execute(new ArrayList[] { paramMap });
  }
  
  private static final class a
    extends AsyncTask<ArrayList<b.b>, Void, Void>
  {
    public ArrayList<b.b> a;
    
    /* Error */
    private Void a(ArrayList<b.b>... paramVarArgs)
    {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: iconst_0
      //   3: aaload
      //   4: putfield 22	RLSDK/b$a:a	Ljava/util/ArrayList;
      //   7: new 24	org/json/JSONObject
      //   10: dup
      //   11: invokespecial 25	org/json/JSONObject:<init>	()V
      //   14: astore_1
      //   15: aload_1
      //   16: ldc 27
      //   18: ldc 29
      //   20: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   23: pop
      //   24: invokestatic 38	RLSDK/p:a	()Ljava/lang/String;
      //   27: astore_2
      //   28: aload_2
      //   29: ifnull +11 -> 40
      //   32: aload_1
      //   33: ldc 40
      //   35: aload_2
      //   36: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   39: pop
      //   40: aload_1
      //   41: ldc 42
      //   43: getstatic 48	android/os/Build:MODEL	Ljava/lang/String;
      //   46: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   49: pop
      //   50: aload_1
      //   51: ldc 50
      //   53: getstatic 54	RLSDK/o:a	Ljava/lang/String;
      //   56: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   59: pop
      //   60: aload_1
      //   61: ldc 56
      //   63: getstatic 61	android/os/Build$VERSION:RELEASE	Ljava/lang/String;
      //   66: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   69: pop
      //   70: aload_1
      //   71: ldc 63
      //   73: getstatic 68	RLSDK/c:e	Ljava/lang/String;
      //   76: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   79: pop
      //   80: getstatic 71	RLSDK/c:d	Ljava/lang/String;
      //   83: ifnull +13 -> 96
      //   86: aload_1
      //   87: ldc 73
      //   89: getstatic 71	RLSDK/c:d	Ljava/lang/String;
      //   92: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   95: pop
      //   96: new 75	org/json/JSONArray
      //   99: dup
      //   100: invokespecial 76	org/json/JSONArray:<init>	()V
      //   103: astore_2
      //   104: aload_0
      //   105: getfield 22	RLSDK/b$a:a	Ljava/util/ArrayList;
      //   108: invokevirtual 82	java/util/ArrayList:iterator	()Ljava/util/Iterator;
      //   111: astore_3
      //   112: aload_3
      //   113: invokeinterface 88 1 0
      //   118: ifeq +163 -> 281
      //   121: aload_3
      //   122: invokeinterface 92 1 0
      //   127: checkcast 94	RLSDK/b$b
      //   130: astore 4
      //   132: ldc 96
      //   134: iconst_1
      //   135: anewarray 98	java/lang/Object
      //   138: dup
      //   139: iconst_0
      //   140: aload 4
      //   142: getfield 102	RLSDK/b$b:b	J
      //   145: l2d
      //   146: ldc2_w 103
      //   149: ddiv
      //   150: invokestatic 110	java/lang/Double:valueOf	(D)Ljava/lang/Double;
      //   153: aastore
      //   154: invokestatic 116	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   157: astore 6
      //   159: new 24	org/json/JSONObject
      //   162: dup
      //   163: invokespecial 25	org/json/JSONObject:<init>	()V
      //   166: astore 5
      //   168: aload 5
      //   170: ldc 117
      //   172: aload 4
      //   174: getfield 118	RLSDK/b$b:a	Ljava/lang/String;
      //   177: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   180: pop
      //   181: aload 5
      //   183: ldc 120
      //   185: aload 6
      //   187: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   190: pop
      //   191: aload 4
      //   193: getfield 124	RLSDK/b$b:c	Ljava/util/Map;
      //   196: ifnull +75 -> 271
      //   199: aload 4
      //   201: getfield 124	RLSDK/b$b:c	Ljava/util/Map;
      //   204: invokeinterface 130 1 0
      //   209: invokeinterface 133 1 0
      //   214: astore 6
      //   216: aload 6
      //   218: invokeinterface 88 1 0
      //   223: ifeq +48 -> 271
      //   226: aload 6
      //   228: invokeinterface 92 1 0
      //   233: checkcast 112	java/lang/String
      //   236: astore 7
      //   238: aload 5
      //   240: aload 7
      //   242: aload 4
      //   244: getfield 124	RLSDK/b$b:c	Ljava/util/Map;
      //   247: aload 7
      //   249: invokeinterface 137 2 0
      //   254: checkcast 112	java/lang/String
      //   257: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   260: pop
      //   261: goto -45 -> 216
      //   264: astore_1
      //   265: aload_1
      //   266: invokevirtual 140	java/lang/Exception:printStackTrace	()V
      //   269: aconst_null
      //   270: areturn
      //   271: aload_2
      //   272: aload 5
      //   274: invokevirtual 143	org/json/JSONArray:put	(Ljava/lang/Object;)Lorg/json/JSONArray;
      //   277: pop
      //   278: goto -166 -> 112
      //   281: aload_1
      //   282: ldc -111
      //   284: aload_2
      //   285: invokevirtual 33	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   288: pop
      //   289: aload_1
      //   290: invokevirtual 148	org/json/JSONObject:toString	()Ljava/lang/String;
      //   293: ldc -106
      //   295: invokestatic 156	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
      //   298: astore_1
      //   299: new 158	java/lang/StringBuilder
      //   302: dup
      //   303: ldc -96
      //   305: invokespecial 163	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   308: aload_1
      //   309: invokevirtual 167	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   312: invokevirtual 168	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   315: astore_1
      //   316: new 170	org/apache/http/client/methods/HttpPost
      //   319: dup
      //   320: ldc -84
      //   322: invokespecial 173	org/apache/http/client/methods/HttpPost:<init>	(Ljava/lang/String;)V
      //   325: astore_2
      //   326: aload_2
      //   327: new 175	org/apache/http/entity/StringEntity
      //   330: dup
      //   331: aload_1
      //   332: ldc -79
      //   334: invokespecial 180	org/apache/http/entity/StringEntity:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   337: invokevirtual 184	org/apache/http/client/methods/HttpPost:setEntity	(Lorg/apache/http/HttpEntity;)V
      //   340: aload_2
      //   341: ldc -70
      //   343: ldc -68
      //   345: invokevirtual 191	org/apache/http/client/methods/HttpPost:setHeader	(Ljava/lang/String;Ljava/lang/String;)V
      //   348: new 193	org/apache/http/impl/client/DefaultHttpClient
      //   351: dup
      //   352: invokespecial 194	org/apache/http/impl/client/DefaultHttpClient:<init>	()V
      //   355: aload_2
      //   356: invokeinterface 200 2 0
      //   361: pop
      //   362: goto -93 -> 269
      //   365: astore_2
      //   366: goto -270 -> 96
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	369	0	this	a
      //   0	369	1	paramVarArgs	ArrayList<b.b>[]
      //   27	329	2	localObject1	Object
      //   365	1	2	localException	Exception
      //   111	11	3	localIterator	java.util.Iterator
      //   130	113	4	localb	b.b
      //   166	107	5	localJSONObject	org.json.JSONObject
      //   157	70	6	localObject2	Object
      //   236	12	7	str	String
      // Exception table:
      //   from	to	target	type
      //   15	28	264	java/lang/Exception
      //   32	40	264	java/lang/Exception
      //   40	80	264	java/lang/Exception
      //   96	112	264	java/lang/Exception
      //   112	216	264	java/lang/Exception
      //   216	261	264	java/lang/Exception
      //   271	278	264	java/lang/Exception
      //   281	362	264	java/lang/Exception
      //   80	96	365	java/lang/Exception
    }
  }
  
  static final class b
  {
    String a;
    long b;
    Map<String, String> c;
    
    public b(String paramString, Map<String, String> paramMap)
    {
      this.a = paramString;
      this.b = System.currentTimeMillis();
      this.c = paramMap;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */