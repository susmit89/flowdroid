package RLSDK;

import java.util.Hashtable;

public final class dr
{
  private final ak a;
  private ae b;
  
  public dr(ak paramak)
  {
    this.a = paramak;
  }
  
  private float a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = 0;
    float f2 = 1.0F;
    float f3 = b(paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt3 = paramInt1 - (paramInt3 - paramInt1);
    float f1;
    if (paramInt3 < 0)
    {
      f1 = paramInt1 / (paramInt1 - paramInt3);
      paramInt3 = 0;
    }
    for (;;)
    {
      paramInt4 = (int)(paramInt2 - f1 * (paramInt4 - paramInt2));
      if (paramInt4 < 0)
      {
        f1 = paramInt2 / (paramInt2 - paramInt4);
        paramInt4 = i;
      }
      for (;;)
      {
        f2 = paramInt1;
        return b(paramInt1, paramInt2, (int)(f1 * (paramInt3 - paramInt1) + f2), paramInt4) + f3;
        if (paramInt3 <= this.a.a) {
          break label186;
        }
        f1 = (this.a.a - paramInt1) / (paramInt3 - paramInt1);
        paramInt3 = this.a.a;
        break;
        if (paramInt4 > this.a.b)
        {
          f1 = (this.a.b - paramInt2) / (paramInt4 - paramInt2);
          paramInt4 = this.a.b;
        }
        else
        {
          f1 = f2;
        }
      }
      label186:
      f1 = 1.0F;
    }
  }
  
  private float a(ad paramad1, ad paramad2)
  {
    float f1 = a((int)paramad1.a(), (int)paramad1.b(), (int)paramad2.a(), (int)paramad2.b());
    float f2 = a((int)paramad2.a(), (int)paramad2.b(), (int)paramad1.a(), (int)paramad1.b());
    if (Float.isNaN(f1)) {
      return f2 / 7.0F;
    }
    if (Float.isNaN(f2)) {
      return f1 / 7.0F;
    }
    return (f1 + f2) / 14.0F;
  }
  
  private ar a(du paramdu)
    throws y, v
  {
    ds localds1 = paramdu.b();
    ds localds2 = paramdu.c();
    ds localds3 = paramdu.a();
    float f1 = (a(localds1, localds2) + a(localds1, localds3)) / 2.0F;
    if (f1 < 1.0F) {
      throw y.a();
    }
    int i = ((int)(ad.a(localds1, localds2) / f1 + 0.5F) + (int)(ad.a(localds1, localds3) / f1 + 0.5F) >> 1) + 7;
    float f2;
    float f3;
    float f4;
    float f5;
    int m;
    int n;
    int i1;
    switch (i & 0x3)
    {
    case 1: 
    default: 
    case 0: 
    case 2: 
      for (;;)
      {
        paramdu = do.a(i);
        int j = paramdu.d();
        if (paramdu.b().length <= 0) {
          break label646;
        }
        f2 = localds2.a();
        f3 = localds1.a();
        f4 = localds3.a();
        f5 = localds2.b();
        float f6 = localds1.b();
        float f7 = localds3.b();
        float f8 = 1.0F - 3.0F / (j - 7);
        float f9 = localds1.a();
        int k = (int)((f2 - f3 + f4 - localds1.a()) * f8 + f9);
        m = (int)(localds1.b() + f8 * (f5 - f6 + f7 - localds1.b()));
        j = 4;
        for (;;)
        {
          if (j > 16) {
            break label646;
          }
          i3 = (int)(j * f1);
          try
          {
            n = Math.max(0, k - i3);
            i1 = Math.min(this.a.a - 1, k + i3);
            if (i1 - n >= 3.0F * f1) {
              break;
            }
            throw y.a();
          }
          catch (y paramdu)
          {
            j <<= 1;
          }
        }
        i += 1;
        continue;
        i -= 1;
      }
    }
    throw y.a();
    int i2 = Math.max(0, m - i3);
    int i3 = Math.min(this.a.b - 1, i3 + m);
    if (i3 - i2 < 3.0F * f1) {
      throw y.a();
    }
    label611:
    label646:
    for (paramdu = new dq(this.a, n, i2, i1 - n, i3 - i2, f1, this.b).a();; paramdu = null)
    {
      f1 = i - 3.5F;
      Object localObject;
      ak localak;
      if (paramdu != null)
      {
        f4 = paramdu.a();
        f5 = paramdu.b();
        f2 = f1 - 3.0F;
        f3 = f2;
        localObject = aw.a(3.5F, 3.5F, f1, 3.5F, f2, f3, 3.5F, f1, localds1.a(), localds1.b(), localds2.a(), localds2.b(), f4, f5, localds3.a(), localds3.b());
        localak = this.a;
        localak = au.a().a(localak, i, i, (aw)localObject);
        if (paramdu != null) {
          break label611;
        }
        paramdu = new ad[3];
        paramdu[0] = localds3;
        paramdu[1] = localds1;
        paramdu[2] = localds2;
      }
      for (;;)
      {
        return new ar(localak, paramdu);
        f4 = localds2.a() - localds1.a() + localds3.a();
        f5 = localds2.b() - localds1.b() + localds3.b();
        f2 = f1;
        f3 = f1;
        break;
        localObject = new ad[4];
        localObject[0] = localds3;
        localObject[1] = localds1;
        localObject[2] = localds2;
        localObject[3] = paramdu;
        paramdu = (du)localObject;
      }
    }
  }
  
  private float b(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int k;
    int n;
    int m;
    int i;
    if (Math.abs(paramInt4 - paramInt2) > Math.abs(paramInt3 - paramInt1))
    {
      k = 1;
      if (k == 0) {
        break label306;
      }
      n = paramInt4;
      m = paramInt3;
      i = paramInt2;
      paramInt4 = paramInt1;
    }
    for (;;)
    {
      int i5 = Math.abs(n - i);
      int i6 = Math.abs(m - paramInt4);
      paramInt2 = -i5;
      int i1;
      label71:
      int i2;
      label81:
      int j;
      label94:
      int i3;
      label108:
      int i4;
      if (i < n)
      {
        i1 = 1;
        if (paramInt4 >= m) {
          break label190;
        }
        i2 = 1;
        paramInt3 = 0;
        paramInt1 = i;
        j = paramInt2 >> 1;
        paramInt2 = paramInt4;
        if (paramInt1 == n) {
          break label278;
        }
        if (k == 0) {
          break label196;
        }
        i3 = paramInt2;
        if (k == 0) {
          break label202;
        }
        i4 = paramInt1;
        label116:
        if (paramInt3 != 1) {
          break label208;
        }
        if (!this.a.a(i3, i4)) {
          break label303;
        }
        paramInt3 += 1;
      }
      label190:
      label196:
      label202:
      label208:
      label278:
      label303:
      for (;;)
      {
        if (paramInt3 == 3)
        {
          paramInt3 = paramInt1 - i;
          paramInt2 -= paramInt4;
          paramInt1 = paramInt3;
          if (i1 < 0) {
            paramInt1 = paramInt3 + 1;
          }
          return (float)Math.sqrt(paramInt1 * paramInt1 + paramInt2 * paramInt2);
          k = 0;
          break;
          i1 = -1;
          break label71;
          i2 = -1;
          break label81;
          i3 = paramInt1;
          break label108;
          i4 = paramInt2;
          break label116;
          if (this.a.a(i3, i4)) {
            break label303;
          }
          paramInt3 += 1;
          continue;
        }
        i4 = j + i6;
        i3 = paramInt2;
        j = i4;
        if (i4 > 0)
        {
          if (paramInt2 != m)
          {
            i3 = paramInt2 + i2;
            j = i4 - i5;
          }
        }
        else
        {
          paramInt1 += i1;
          paramInt2 = i3;
          break label94;
        }
        paramInt1 = n - i;
        paramInt2 = m - paramInt4;
        return (float)Math.sqrt(paramInt1 * paramInt1 + paramInt2 * paramInt2);
      }
      label306:
      m = paramInt4;
      paramInt4 = paramInt2;
      i = paramInt1;
      n = paramInt3;
    }
  }
  
  public final ar a(Hashtable paramHashtable)
    throws y, v
  {
    if (paramHashtable == null) {}
    for (ae localae = null;; localae = (ae)paramHashtable.get(u.h))
    {
      this.b = localae;
      return a(new dt(this.a, this.b).a(paramHashtable));
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */