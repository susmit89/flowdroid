package RLSDK;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import com.ebay.redlasersdk.BarcodeResult;
import com.ebay.redlasersdk.BarcodeTypes;
import com.ebay.redlasersdk.recognizers.BarcodeResultInternal;
import com.ebay.redlasersdk.recognizers.NewLaserScanner;
import com.ebay.redlasersdk.recognizers.RealtimeScanner;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class d
  extends Handler
{
  public BarcodeTypes a;
  public RectF b;
  private final String c = "BarcodeEngine";
  private final boolean d = true;
  private NewLaserScanner e;
  private boolean f = false;
  private RealtimeScanner g;
  private final boolean h = true;
  private com.ebay.redlasersdk.recognizers.b i;
  private long j = 0L;
  private int k = 0;
  private int l = 0;
  private int m = 0;
  private m n;
  
  public d(BarcodeTypes paramBarcodeTypes, Context paramContext)
  {
    c.a(paramContext);
    this.a = paramBarcodeTypes;
    this.n = new m();
    this.b = new RectF();
    this.b.setEmpty();
    this.e = new NewLaserScanner(this.a);
    this.e.setHandler(this.n);
    this.e.start();
    this.e.isBusy = false;
    this.g = new RealtimeScanner(paramContext, this.a);
    this.g.setHandler(this.n);
    this.g.start();
    this.g.isBusy = false;
    this.i = new com.ebay.redlasersdk.recognizers.b(this.a);
    this.i.setHandler(this.n);
    this.i.start();
    this.i.isBusy = false;
  }
  
  public final Set<BarcodeResult> a(Bitmap paramBitmap)
  {
    long l1 = SystemClock.uptimeMillis();
    new HashSet();
    if ((c.a() == c.c.c) || (c.a() == c.c.e)) {
      return null;
    }
    for (;;)
    {
      int i1;
      try
      {
        Object localObject2 = new byte[paramBitmap.getHeight() * paramBitmap.getWidth()];
        Object localObject1 = new int[paramBitmap.getWidth() * 4 + 16];
        i1 = 0;
        if (i1 < paramBitmap.getHeight())
        {
          int i3 = paramBitmap.getWidth();
          paramBitmap.getPixels((int[])localObject1, 0, paramBitmap.getWidth(), 0, i1, paramBitmap.getWidth(), 1);
          int i2 = 0;
          if (i2 < paramBitmap.getWidth())
          {
            int i4 = localObject1[i2];
            localObject2[(i3 * i1 + i2)] = ((byte)((i4 & 0xFF) + ((i4 >> 16 & 0xFF) + (i4 >> 7 & 0x1FE)) >> 2));
            i2 += 1;
            continue;
          }
        }
        else
        {
          RectF localRectF = new RectF(0.0F, 0.0F, paramBitmap.getWidth(), paramBitmap.getHeight());
          localObject1 = new a();
          ((a)localObject1).a = ((byte[])localObject2);
          ((a)localObject1).b = paramBitmap.getWidth();
          ((a)localObject1).c = paramBitmap.getHeight();
          ((a)localObject1).d = localRectF;
          ((a)localObject1).e = 0;
          ((a)localObject1).f = 0;
          localObject2 = this.e.ProcessFrameSync((a)localObject1);
          this.n.a((BarcodeResultInternal[])localObject2);
          localObject2 = this.g.ProcessFrameSync((a)localObject1);
          this.n.a((BarcodeResultInternal[])localObject2);
          localObject1 = this.i.ProcessFrameSync((a)localObject1);
          this.n.a((BarcodeResultInternal[])localObject1);
          localObject1 = (Set)this.n.a().get("FoundBarcodes");
          double d1 = (SystemClock.uptimeMillis() - l1) / 1000.0D;
          localObject2 = new HashMap();
          ((HashMap)localObject2).put("numFinds", String.format("%d", new Object[] { Integer.valueOf(((Set)localObject1).size()) }));
          ((HashMap)localObject2).put("dur", String.format("%.2f", new Object[] { Double.valueOf(d1) }));
          ((HashMap)localObject2).put("height", String.format("%d", new Object[] { Integer.valueOf(paramBitmap.getHeight()) }));
          ((HashMap)localObject2).put("width", String.format("%d", new Object[] { Integer.valueOf(paramBitmap.getWidth()) }));
          b.a("ANDRSDK.PHOTO_SESSION_FINISHED", (Map)localObject2);
          return (Set<BarcodeResult>)localObject1;
        }
      }
      catch (Exception paramBitmap)
      {
        return null;
      }
      catch (Throwable paramBitmap)
      {
        return null;
      }
      i1 += 1;
    }
  }
  
  public final void a()
  {
    if (this.e != null)
    {
      Message.obtain(this.e.getThreadHandler(), 7877125, null).sendToTarget();
      this.e = null;
    }
    if (this.g != null)
    {
      Message.obtain(this.g.getThreadHandler(), 7877125, null).sendToTarget();
      this.g = null;
    }
    if (this.i != null)
    {
      Message.obtain(this.i.getThreadHandler(), 7877125, null).sendToTarget();
      this.i = null;
    }
    this.n.b();
  }
  
  public final void a(RectF paramRectF)
  {
    this.b = paramRectF;
  }
  
  public final void a(BarcodeTypes paramBarcodeTypes)
  {
    this.a = paramBarcodeTypes;
    this.e.enabledScanTypes = this.a;
    if (this.f) {
      this.g.enabledScanTypes = this.a;
    }
    paramBarcodeTypes = this.i;
    BarcodeTypes localBarcodeTypes = this.a;
    paramBarcodeTypes.a();
  }
  
  public final void a(boolean paramBoolean)
  {
    this.f = paramBoolean;
  }
  
  public final void a(byte[] paramArrayOfByte)
  {
    this.n.a(paramArrayOfByte);
  }
  
  final void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    Object localObject2 = Integer.valueOf(0);
    Object localObject1 = localObject2;
    if (!this.e.isBusy)
    {
      localObject1 = localObject2;
      if ((this.e.getRecognizableTypes() & this.a.getEnabledTypes()) != 0) {
        localObject1 = Integer.valueOf(((Integer)localObject2).intValue() | 0x4);
      }
    }
    localObject2 = localObject1;
    if (this.f)
    {
      localObject2 = localObject1;
      if (!this.g.isBusy)
      {
        localObject2 = localObject1;
        if ((this.g.getRecognizableTypes() & this.a.getEnabledTypes()) != 0) {
          localObject2 = Integer.valueOf(((Integer)localObject1).intValue() | 0x1);
        }
      }
    }
    localObject1 = localObject2;
    if (!this.i.isBusy)
    {
      localObject1 = localObject2;
      if ((this.i.getRecognizableTypes() & this.a.getEnabledTypes()) != 0) {
        localObject1 = Integer.valueOf(((Integer)localObject2).intValue() | 0x2);
      }
    }
    if (((Integer)localObject1).intValue() != 0)
    {
      Object localObject3 = new RectF(0.0F, 0.0F, paramInt1, paramInt2);
      RectF localRectF = new RectF(this.b);
      localObject2 = localRectF;
      if (localRectF.isEmpty()) {
        localObject2 = localObject3;
      }
      ((RectF)localObject2).setIntersect((RectF)localObject2, (RectF)localObject3);
      localObject3 = new a();
      ((a)localObject3).a = paramArrayOfByte;
      ((a)localObject3).b = paramInt1;
      ((a)localObject3).c = paramInt2;
      ((a)localObject3).d = ((RectF)localObject2);
      ((a)localObject3).e = ((Integer)localObject1).intValue();
      ((a)localObject3).f = paramInt3;
      if ((((Integer)localObject1).intValue() & 0x4) != 0)
      {
        this.e.isBusy = true;
        Message.obtain(this.e.getThreadHandler(), 7877120, localObject3).sendToTarget();
        this.k += 1;
      }
      if ((((Integer)localObject1).intValue() & 0x1) != 0)
      {
        this.g.isBusy = true;
        Message.obtain(this.g.getThreadHandler(), 7877120, localObject3).sendToTarget();
        this.l += 1;
      }
      if ((((Integer)localObject1).intValue() & 0x2) != 0)
      {
        this.i.isBusy = true;
        Message.obtain(this.i.getThreadHandler(), 7877120, localObject3).sendToTarget();
        this.m += 1;
      }
      if (this.j != 0L) {
        break label458;
      }
      this.j = Calendar.getInstance().getTimeInMillis();
      this.k = 0;
      this.l = 0;
      this.m = 0;
    }
    label458:
    long l1;
    do
    {
      return;
      g.get().addCallbackBuffer(paramArrayOfByte);
      break;
      l1 = (Calendar.getInstance().getTimeInMillis() - this.j) / 1000L;
    } while (l1 <= 10.0D);
    String.format("Last 10 seconds:%.2f NL scans/s, %.2f OCC scans/s, %.2f ZXing scans/s", new Object[] { Float.valueOf(this.k / (float)l1), Float.valueOf(this.l / (float)l1), Float.valueOf(this.m / (float)l1) });
    this.j = Calendar.getInstance().getTimeInMillis();
    this.k = 0;
    this.l = 0;
    this.m = 0;
  }
  
  public final HashMap<String, Object> b()
  {
    return this.n.a();
  }
  
  public final class a
  {
    public byte[] a;
    public int b;
    public int c;
    public RectF d;
    public int e;
    public int f;
    
    public a() {}
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */