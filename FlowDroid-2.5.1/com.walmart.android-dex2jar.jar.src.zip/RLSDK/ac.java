package RLSDK;

import java.util.Hashtable;

public final class ac
{
  public static final ac a = new ac("OTHER");
  public static final ac b = new ac("ORIENTATION");
  public static final ac c = new ac("BYTE_SEGMENTS");
  public static final ac d = new ac("ERROR_CORRECTION_LEVEL");
  public static final ac e = new ac("ISSUE_NUMBER");
  public static final ac f = new ac("SUGGESTED_PRICE");
  public static final ac g = new ac("POSSIBLE_COUNTRY");
  private static final Hashtable h = new Hashtable();
  private final String i;
  
  private ac(String paramString)
  {
    this.i = paramString;
    h.put(paramString, this);
  }
  
  public final String toString()
  {
    return this.i;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */