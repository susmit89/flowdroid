package RLSDK;

import android.app.Application;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.hardware.Camera;
import com.ebay.redlasersdk.BarcodeScanActivity;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

public class h
  extends g
{
  protected boolean captureJpegOfNextPreviewFrame;
  protected ArrayList<byte[]> previewBuffers = new ArrayList();
  
  protected h(Application paramApplication)
  {
    super(paramApplication);
  }
  
  public void addCallbackBuffer(byte[] paramArrayOfByte)
  {
    if (this.previewing) {
      this.camera.addCallbackBuffer(paramArrayOfByte);
    }
  }
  
  protected void determineOrientation()
  {
    this.relativeCameraOrientation = 90;
    if (this.scanActivity.getOrientationSetting().equals("orientationLandscape")) {
      this.relativeCameraOrientation = 0;
    }
  }
  
  public void onPreviewFrame(byte[] paramArrayOfByte, Camera paramCamera)
  {
    super.onPreviewFrame(paramArrayOfByte, paramCamera);
    Object localObject = this.configManager.a();
    if (this.previewBuffers.size() < 4)
    {
      byte[] arrayOfByte = new byte[((Point)localObject).x * ((Point)localObject).y * 3 / 2];
      paramCamera.addCallbackBuffer(arrayOfByte);
      paramCamera = TAG;
      new StringBuilder("Allocating buffer ").append(this.previewBuffers.size()).append(".").toString();
      this.previewBuffers.add(arrayOfByte);
    }
    if (this.captureJpegOfNextPreviewFrame)
    {
      this.captureJpegOfNextPreviewFrame = false;
      paramArrayOfByte = new YuvImage(paramArrayOfByte, 17, ((Point)localObject).x, ((Point)localObject).y, null);
      paramCamera = new Rect(0, 0, ((Point)localObject).x, ((Point)localObject).y);
      localObject = new ByteArrayOutputStream();
      if (paramArrayOfByte.compressToJpeg(paramCamera, 80, (OutputStream)localObject)) {
        this.frameEngine.a(((ByteArrayOutputStream)localObject).toByteArray());
      }
    }
  }
  
  protected void openCamera()
    throws IOException
  {
    this.camera = Camera.open();
    if (this.camera == null) {
      throw new IOException();
    }
    if (this.scanActivity.getOrientationSetting().equals("orientationLandscape"))
    {
      this.camera.setDisplayOrientation(0);
      return;
    }
    this.camera.setDisplayOrientation(90);
  }
  
  protected void startPreview()
  {
    Object localObject = TAG;
    if ((this.camera != null) && (!this.previewing))
    {
      this.previewing = true;
      this.previewBuffers.clear();
      this.captureJpegOfNextPreviewFrame = false;
      this.camera.setPreviewCallbackWithBuffer(this);
      this.camera.startPreview();
      localObject = TAG;
      this.isAutoFocusing = false;
      this.isOnTimerForRepeatedAutoFocus = false;
      determineFocusMode(true);
      localObject = this.configManager.a();
      int i = ((Point)localObject).x;
      localObject = new byte[((Point)localObject).y * i * 3 / 2];
      this.previewBuffers.add(localObject);
      this.camera.addCallbackBuffer((byte[])localObject);
      localObject = TAG;
    }
  }
  
  public void stopPreview(BarcodeScanActivity paramBarcodeScanActivity)
  {
    if (paramBarcodeScanActivity != this.scanActivity) {
      paramBarcodeScanActivity = TAG;
    }
    while ((this.camera == null) || (!this.previewing)) {
      return;
    }
    this.previewing = false;
    this.camera.setPreviewCallbackWithBuffer(null);
    this.camera.stopPreview();
    this.previewBuffers.clear();
  }
  
  public void takePicture()
  {
    if (this.previewing) {
      this.captureJpegOfNextPreviewFrame = true;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */