package RLSDK;

public abstract interface ao
{
  public abstract int a(Object paramObject1, Object paramObject2);
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */