package RLSDK;

import java.util.Hashtable;

public final class bl
  extends bu
{
  static final int[][] a;
  
  static
  {
    int[] arrayOfInt1 = { 2, 2, 1, 2, 1, 3 };
    int[] arrayOfInt2 = { 3, 2, 1, 1, 2, 2 };
    int[] arrayOfInt3 = { 1, 3, 1, 1, 2, 3 };
    int[] arrayOfInt4 = { 1, 1, 1, 4, 2, 2 };
    int[] arrayOfInt5 = { 1, 1, 2, 2, 1, 4 };
    int[] arrayOfInt6 = { 1, 2, 2, 1, 1, 4 };
    a = new int[][] { { 2, 1, 2, 2, 2, 2 }, { 2, 2, 2, 1, 2, 2 }, { 2, 2, 2, 2, 2, 1 }, { 1, 2, 1, 2, 2, 3 }, { 1, 2, 1, 3, 2, 2 }, { 1, 3, 1, 2, 2, 2 }, { 1, 2, 2, 2, 1, 3 }, { 1, 2, 2, 3, 1, 2 }, { 1, 3, 2, 2, 1, 2 }, arrayOfInt1, { 2, 2, 1, 3, 1, 2 }, { 2, 3, 1, 2, 1, 2 }, { 1, 1, 2, 2, 3, 2 }, { 1, 2, 2, 1, 3, 2 }, { 1, 2, 2, 2, 3, 1 }, { 1, 1, 3, 2, 2, 2 }, { 1, 2, 3, 1, 2, 2 }, { 1, 2, 3, 2, 2, 1 }, { 2, 2, 3, 2, 1, 1 }, { 2, 2, 1, 1, 3, 2 }, { 2, 2, 1, 2, 3, 1 }, { 2, 1, 3, 2, 1, 2 }, { 2, 2, 3, 1, 1, 2 }, { 3, 1, 2, 1, 3, 1 }, { 3, 1, 1, 2, 2, 2 }, arrayOfInt2, { 3, 2, 1, 2, 2, 1 }, { 3, 1, 2, 2, 1, 2 }, { 3, 2, 2, 1, 1, 2 }, { 3, 2, 2, 2, 1, 1 }, { 2, 1, 2, 1, 2, 3 }, { 2, 1, 2, 3, 2, 1 }, { 2, 3, 2, 1, 2, 1 }, { 1, 1, 1, 3, 2, 3 }, arrayOfInt3, { 1, 3, 1, 3, 2, 1 }, { 1, 1, 2, 3, 1, 3 }, { 1, 3, 2, 1, 1, 3 }, { 1, 3, 2, 3, 1, 1 }, { 2, 1, 1, 3, 1, 3 }, { 2, 3, 1, 1, 1, 3 }, { 2, 3, 1, 3, 1, 1 }, { 1, 1, 2, 1, 3, 3 }, { 1, 1, 2, 3, 3, 1 }, { 1, 3, 2, 1, 3, 1 }, { 1, 1, 3, 1, 2, 3 }, { 1, 1, 3, 3, 2, 1 }, { 1, 3, 3, 1, 2, 1 }, { 3, 1, 3, 1, 2, 1 }, { 2, 1, 1, 3, 3, 1 }, { 2, 3, 1, 1, 3, 1 }, { 2, 1, 3, 1, 1, 3 }, { 2, 1, 3, 3, 1, 1 }, { 2, 1, 3, 1, 3, 1 }, { 3, 1, 1, 1, 2, 3 }, { 3, 1, 1, 3, 2, 1 }, { 3, 3, 1, 1, 2, 1 }, { 3, 1, 2, 1, 1, 3 }, { 3, 1, 2, 3, 1, 1 }, { 3, 3, 2, 1, 1, 1 }, { 3, 1, 4, 1, 1, 1 }, { 2, 2, 1, 4, 1, 1 }, { 4, 3, 1, 1, 1, 1 }, { 1, 1, 1, 2, 2, 4 }, arrayOfInt4, { 1, 2, 1, 1, 2, 4 }, { 1, 2, 1, 4, 2, 1 }, { 1, 4, 1, 1, 2, 2 }, { 1, 4, 1, 2, 2, 1 }, arrayOfInt5, { 1, 1, 2, 4, 1, 2 }, arrayOfInt6, { 1, 2, 2, 4, 1, 1 }, { 1, 4, 2, 1, 1, 2 }, { 1, 4, 2, 2, 1, 1 }, { 2, 4, 1, 2, 1, 1 }, { 2, 2, 1, 1, 1, 4 }, { 4, 1, 3, 1, 1, 1 }, { 2, 4, 1, 1, 1, 2 }, { 1, 3, 4, 1, 1, 1 }, { 1, 1, 1, 2, 4, 2 }, { 1, 2, 1, 1, 4, 2 }, { 1, 2, 1, 2, 4, 1 }, { 1, 1, 4, 2, 1, 2 }, { 1, 2, 4, 1, 1, 2 }, { 1, 2, 4, 2, 1, 1 }, { 4, 1, 1, 2, 1, 2 }, { 4, 2, 1, 1, 1, 2 }, { 4, 2, 1, 2, 1, 1 }, { 2, 1, 2, 1, 4, 1 }, { 2, 1, 4, 1, 2, 1 }, { 4, 1, 2, 1, 2, 1 }, { 1, 1, 1, 1, 4, 3 }, { 1, 1, 1, 3, 4, 1 }, { 1, 3, 1, 1, 4, 1 }, { 1, 1, 4, 1, 1, 3 }, { 1, 1, 4, 3, 1, 1 }, { 4, 1, 1, 1, 1, 3 }, { 4, 1, 1, 3, 1, 1 }, { 1, 1, 3, 1, 4, 1 }, { 1, 1, 4, 1, 3, 1 }, { 3, 1, 1, 1, 4, 1 }, { 4, 1, 1, 1, 3, 1 }, { 2, 1, 1, 4, 1, 2 }, { 2, 1, 1, 2, 1, 4 }, { 2, 1, 1, 2, 3, 2 }, { 2, 3, 3, 1, 1, 1, 2 } };
  }
  
  private static int a(aj paramaj, int[] paramArrayOfInt, int paramInt)
    throws y
  {
    a(paramaj, paramInt, paramArrayOfInt);
    int i = 64;
    int k = -1;
    paramInt = 0;
    while (paramInt < a.length)
    {
      int m = a(paramArrayOfInt, a[paramInt], 179);
      int j = i;
      if (m < i)
      {
        k = paramInt;
        j = m;
      }
      paramInt += 1;
      i = j;
    }
    if (k >= 0) {
      return k;
    }
    throw y.a();
  }
  
  public final ab a(int paramInt, aj paramaj, Hashtable paramHashtable)
    throws y, v, t
  {
    int i4 = paramaj.b;
    int i = 0;
    while ((i < i4) && (!paramaj.a(i))) {
      i += 1;
    }
    int k = 0;
    paramHashtable = new int[6];
    int j = 0;
    int i5 = paramHashtable.length;
    int i1 = i;
    int m;
    int n;
    int i2;
    label135:
    int i3;
    for (;;)
    {
      if (i1 < i4) {
        if ((paramaj.a(i1) ^ j))
        {
          paramHashtable[k] += 1;
          m = k;
          k = i;
          i = m;
          m = i;
          i1 += 1;
          i = k;
          k = m;
        }
        else if (k == i5 - 1)
        {
          n = 64;
          i2 = -1;
          m = 103;
          if (m <= 105)
          {
            i3 = a(paramHashtable, a[m], 179);
            if (i3 >= n) {
              break label1674;
            }
            i2 = m;
            n = i3;
          }
        }
      }
    }
    label329:
    label627:
    label1009:
    label1437:
    label1444:
    label1576:
    label1674:
    for (;;)
    {
      m += 1;
      break label135;
      if ((i2 >= 0) && (paramaj.a(Math.max(0, i - (i1 - i) / 2), i)))
      {
        paramHashtable = new int[3];
        paramHashtable[0] = i;
        paramHashtable[1] = i1;
        paramHashtable[2] = i2;
        m = paramHashtable[2];
      }
      switch (m)
      {
      default: 
        throw v.a();
        m = paramHashtable[0] + paramHashtable[1] + i;
        i = 2;
        while (i < i5)
        {
          paramHashtable[(i - 2)] = paramHashtable[i];
          i += 1;
        }
        paramHashtable[(i5 - 2)] = 0;
        paramHashtable[(i5 - 1)] = 0;
        i = k - 1;
        k = m;
        paramHashtable[i] = 1;
        if (j == 0) {}
        for (j = 1;; j = 0)
        {
          break;
          m = k + 1;
          k = i;
          i = m;
          break label329;
        }
        throw y.a();
      case 103: 
        i = 101;
      }
      Object localObject1;
      Object localObject2;
      int i6;
      int i8;
      for (;;)
      {
        localObject1 = new StringBuffer(20);
        i3 = paramHashtable[0];
        n = paramHashtable[1];
        localObject2 = new int[6];
        k = 1;
        i4 = 0;
        i6 = 0;
        i2 = 0;
        i5 = 0;
        i1 = 0;
        j = i;
        i = i6;
        if (i != 0) {
          break label1444;
        }
        i8 = a(paramaj, (int[])localObject2, n);
        if (i8 != 106) {
          k = 1;
        }
        i6 = i1;
        i5 = m;
        if (i8 != 106)
        {
          i6 = i1 + 1;
          i5 = m + i6 * i8;
        }
        m = 0;
        i3 = n;
        while (m < localObject2.length)
        {
          i3 += localObject2[m];
          m += 1;
        }
        i = 100;
        continue;
        i = 99;
      }
      switch (i8)
      {
      default: 
        switch (j)
        {
        default: 
          i1 = j;
          j = k;
          k = 0;
          m = i;
          i = i1;
        }
        break;
      }
      int i7;
      for (;;)
      {
        i1 = i;
        if (i4 != 0)
        {
          if (i != 101) {
            break label1437;
          }
          i1 = 100;
        }
        i4 = k;
        i7 = i1;
        k = i2;
        i = m;
        i2 = i8;
        i8 = i3;
        i1 = i6;
        m = i5;
        i5 = k;
        i3 = n;
        n = i8;
        k = j;
        j = i7;
        break;
        throw v.a();
        if (i8 < 64)
        {
          ((StringBuffer)localObject1).append((char)(i8 + 32));
          m = i;
          i1 = 0;
          i = j;
          j = k;
          k = i1;
        }
        else if (i8 < 96)
        {
          ((StringBuffer)localObject1).append((char)(i8 - 64));
          m = i;
          i1 = 0;
          i = j;
          j = k;
          k = i1;
        }
        else
        {
          if (i8 != 106) {
            k = 0;
          }
          switch (i8)
          {
          }
          for (;;)
          {
            i1 = 0;
            m = i;
            i = j;
            j = k;
            k = i1;
            break;
            m = i;
            i1 = 0;
            i = j;
            j = k;
            k = i1;
            break;
            i1 = 1;
            i7 = 100;
            m = i;
            j = k;
            i = i7;
            k = i1;
            break;
            i7 = 100;
            i1 = 0;
            m = i;
            j = k;
            i = i7;
            k = i1;
            break;
            i7 = 99;
            i1 = 0;
            m = i;
            j = k;
            i = i7;
            k = i1;
            break;
            i = 1;
          }
          if (i8 >= 96) {
            break label1009;
          }
          ((StringBuffer)localObject1).append((char)(i8 + 32));
          m = i;
          i1 = 0;
          i = j;
          j = k;
          k = i1;
        }
      }
      if (i8 != 106) {
        k = 0;
      }
      for (;;)
      {
        m = i;
        switch (i8)
        {
        }
        for (m = i;; m = 1)
        {
          i1 = 0;
          i = j;
          j = k;
          k = i1;
          break;
          i1 = 0;
          m = i;
          i = j;
          j = k;
          k = i1;
          break;
          i1 = 1;
          i7 = 101;
          m = i;
          j = k;
          i = i7;
          k = i1;
          break;
          i7 = 101;
          i1 = 0;
          m = i;
          j = k;
          i = i7;
          k = i1;
          break;
          i7 = 99;
          i1 = 0;
          m = i;
          j = k;
          i = i7;
          k = i1;
          break;
        }
        if (i8 < 100)
        {
          if (i8 < 10) {
            ((StringBuffer)localObject1).append('0');
          }
          ((StringBuffer)localObject1).append(i8);
          m = i;
          i1 = 0;
          i = j;
          j = k;
          k = i1;
          break;
        }
        if (i8 != 106) {
          k = 0;
        }
        for (;;)
        {
          switch (i8)
          {
          case 103: 
          case 104: 
          case 105: 
          default: 
            i1 = 0;
            m = i;
            i = j;
            j = k;
            k = i1;
            break;
          case 102: 
            i1 = 0;
            m = i;
            i = j;
            j = k;
            k = i1;
            break;
          case 101: 
            i7 = 101;
            i1 = 0;
            m = i;
            j = k;
            i = i7;
            k = i1;
            break;
          case 100: 
            i7 = 100;
            i1 = 0;
            m = i;
            j = k;
            i = i7;
            k = i1;
            break;
          case 106: 
            i1 = 0;
            m = 1;
            i = j;
            j = k;
            k = i1;
            break;
            i1 = 101;
            break label627;
            i = paramaj.b;
            while ((n < i) && (paramaj.a(n))) {
              n += 1;
            }
            if (!paramaj.a(n, Math.min(i, (n - i3) / 2 + n))) {
              throw y.a();
            }
            if ((m - i1 * i5) % 103 != i5) {
              throw t.a();
            }
            i = ((StringBuffer)localObject1).length();
            if ((i > 0) && (k != 0))
            {
              if (j != 99) {
                break label1576;
              }
              ((StringBuffer)localObject1).delete(i - 2, i);
            }
            for (;;)
            {
              paramaj = ((StringBuffer)localObject1).toString();
              if (paramaj.length() != 0) {
                break;
              }
              throw v.a();
              ((StringBuffer)localObject1).delete(i - 1, i);
            }
            float f1 = (paramHashtable[1] + paramHashtable[0]) / 2.0F;
            float f2 = (n + i3) / 2.0F;
            paramHashtable = new ad(f1, paramInt);
            localObject1 = new ad(f2, paramInt);
            localObject2 = q.e;
            return new ab(paramaj, null, new ad[] { paramHashtable, localObject1 }, (q)localObject2);
          }
        }
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/bl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */