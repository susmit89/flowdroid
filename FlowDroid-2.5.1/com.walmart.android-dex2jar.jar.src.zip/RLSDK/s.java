package RLSDK;

public final class s
{
  private final r a;
  private ak b;
  
  public s(r paramr)
  {
    if (paramr == null) {
      throw new IllegalArgumentException("Binarizer must be non-null.");
    }
    this.a = paramr;
    this.b = null;
  }
  
  public final int a()
  {
    return this.a.a().b();
  }
  
  public final aj a(int paramInt, aj paramaj)
    throws y
  {
    return this.a.a(paramInt, paramaj);
  }
  
  public final int b()
  {
    return this.a.a().c();
  }
  
  public final ak c()
    throws y
  {
    if (this.b == null) {
      this.b = this.a.b();
    }
    return this.b;
  }
  
  public final boolean d()
  {
    this.a.a();
    return false;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */