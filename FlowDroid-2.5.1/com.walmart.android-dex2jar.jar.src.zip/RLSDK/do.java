package RLSDK;

public final class do
{
  private static final int[] a = { 31892, 34236, 39577, 42195, 48118, 51042, 55367, 58893, 63784, 68472, 70749, 76311, 79154, 84390, 87683, 92361, 96236, 102084, 102881, 110507, 110734, 117786, 119615, 126325, 127568, 133589, 136944, 141498, 145311, 150283, 152622, 158308, 161089, 167017 };
  private static final do[] b;
  private final int c;
  private final int[] d;
  private final b[] e;
  private final int f;
  
  static
  {
    Object localObject1 = new b(7, new a(1, 19));
    Object localObject2 = new b(10, new a(1, 16));
    Object localObject3 = new b(13, new a(1, 13));
    Object localObject4 = new b(17, new a(1, 9));
    localObject1 = new do(1, new int[0], (b)localObject1, (b)localObject2, (b)localObject3, (b)localObject4);
    localObject2 = new b(10, new a(1, 34));
    localObject3 = new b(16, new a(1, 28));
    localObject4 = new b(22, new a(1, 22));
    Object localObject5 = new b(28, new a(1, 16));
    localObject2 = new do(2, new int[] { 6, 18 }, (b)localObject2, (b)localObject3, (b)localObject4, (b)localObject5);
    localObject3 = new b(15, new a(1, 55));
    localObject4 = new b(26, new a(1, 44));
    localObject5 = new b(18, new a(2, 17));
    Object localObject6 = new b(22, new a(2, 13));
    localObject3 = new do(3, new int[] { 6, 22 }, (b)localObject3, (b)localObject4, (b)localObject5, (b)localObject6);
    localObject4 = new b(20, new a(1, 80));
    localObject5 = new b(18, new a(2, 32));
    localObject6 = new b(26, new a(2, 24));
    Object localObject7 = new b(16, new a(4, 9));
    localObject4 = new do(4, new int[] { 6, 26 }, (b)localObject4, (b)localObject5, (b)localObject6, (b)localObject7);
    localObject5 = new b(26, new a(1, 108));
    localObject6 = new b(24, new a(2, 43));
    localObject7 = new b(18, new a(2, 15), new a(2, 16));
    Object localObject8 = new b(22, new a(2, 11), new a(2, 12));
    localObject5 = new do(5, new int[] { 6, 30 }, (b)localObject5, (b)localObject6, (b)localObject7, (b)localObject8);
    localObject6 = new b(18, new a(2, 68));
    localObject7 = new b(16, new a(4, 27));
    localObject8 = new b(24, new a(4, 19));
    Object localObject9 = new b(28, new a(4, 15));
    localObject6 = new do(6, new int[] { 6, 34 }, (b)localObject6, (b)localObject7, (b)localObject8, (b)localObject9);
    localObject7 = new b(20, new a(2, 78));
    localObject8 = new b(18, new a(4, 31));
    localObject9 = new b(18, new a(2, 14), new a(4, 15));
    Object localObject10 = new b(26, new a(4, 13), new a(1, 14));
    localObject7 = new do(7, new int[] { 6, 22, 38 }, (b)localObject7, (b)localObject8, (b)localObject9, (b)localObject10);
    localObject8 = new b(24, new a(2, 97));
    localObject9 = new b(22, new a(2, 38), new a(2, 39));
    localObject10 = new b(22, new a(4, 18), new a(2, 19));
    Object localObject11 = new b(26, new a(4, 14), new a(2, 15));
    localObject8 = new do(8, new int[] { 6, 24, 42 }, (b)localObject8, (b)localObject9, (b)localObject10, (b)localObject11);
    localObject9 = new b(30, new a(2, 116));
    localObject10 = new b(22, new a(3, 36), new a(2, 37));
    localObject11 = new b(20, new a(4, 16), new a(4, 17));
    Object localObject12 = new b(24, new a(4, 12), new a(4, 13));
    localObject9 = new do(9, new int[] { 6, 26, 46 }, (b)localObject9, (b)localObject10, (b)localObject11, (b)localObject12);
    localObject10 = new b(18, new a(2, 68), new a(2, 69));
    localObject11 = new b(26, new a(4, 43), new a(1, 44));
    localObject12 = new b(24, new a(6, 19), new a(2, 20));
    Object localObject13 = new b(28, new a(6, 15), new a(2, 16));
    localObject10 = new do(10, new int[] { 6, 28, 50 }, (b)localObject10, (b)localObject11, (b)localObject12, (b)localObject13);
    localObject11 = new b(20, new a(4, 81));
    localObject12 = new b(30, new a(1, 50), new a(4, 51));
    localObject13 = new b(28, new a(4, 22), new a(4, 23));
    Object localObject14 = new b(24, new a(3, 12), new a(8, 13));
    localObject11 = new do(11, new int[] { 6, 30, 54 }, (b)localObject11, (b)localObject12, (b)localObject13, (b)localObject14);
    localObject12 = new b(24, new a(2, 92), new a(2, 93));
    localObject13 = new b(22, new a(6, 36), new a(2, 37));
    localObject14 = new b(26, new a(4, 20), new a(6, 21));
    Object localObject15 = new b(28, new a(7, 14), new a(4, 15));
    localObject12 = new do(12, new int[] { 6, 32, 58 }, (b)localObject12, (b)localObject13, (b)localObject14, (b)localObject15);
    localObject13 = new b(26, new a(4, 107));
    localObject14 = new b(22, new a(8, 37), new a(1, 38));
    localObject15 = new b(24, new a(8, 20), new a(4, 21));
    Object localObject16 = new b(22, new a(12, 11), new a(4, 12));
    localObject13 = new do(13, new int[] { 6, 34, 62 }, (b)localObject13, (b)localObject14, (b)localObject15, (b)localObject16);
    localObject14 = new b(30, new a(3, 115), new a(1, 116));
    localObject15 = new b(24, new a(4, 40), new a(5, 41));
    localObject16 = new b(20, new a(11, 16), new a(5, 17));
    Object localObject17 = new b(24, new a(11, 12), new a(5, 13));
    localObject14 = new do(14, new int[] { 6, 26, 46, 66 }, (b)localObject14, (b)localObject15, (b)localObject16, (b)localObject17);
    localObject15 = new b(22, new a(5, 87), new a(1, 88));
    localObject16 = new b(24, new a(5, 41), new a(5, 42));
    localObject17 = new b(30, new a(5, 24), new a(7, 25));
    Object localObject18 = new b(24, new a(11, 12), new a(7, 13));
    localObject15 = new do(15, new int[] { 6, 26, 48, 70 }, (b)localObject15, (b)localObject16, (b)localObject17, (b)localObject18);
    localObject16 = new b(24, new a(5, 98), new a(1, 99));
    localObject17 = new b(28, new a(7, 45), new a(3, 46));
    localObject18 = new b(24, new a(15, 19), new a(2, 20));
    Object localObject19 = new b(30, new a(3, 15), new a(13, 16));
    localObject16 = new do(16, new int[] { 6, 26, 50, 74 }, (b)localObject16, (b)localObject17, (b)localObject18, (b)localObject19);
    localObject17 = new b(28, new a(1, 107), new a(5, 108));
    localObject18 = new b(28, new a(10, 46), new a(1, 47));
    localObject19 = new b(28, new a(1, 22), new a(15, 23));
    Object localObject20 = new b(28, new a(2, 14), new a(17, 15));
    localObject17 = new do(17, new int[] { 6, 30, 54, 78 }, (b)localObject17, (b)localObject18, (b)localObject19, (b)localObject20);
    localObject18 = new b(30, new a(5, 120), new a(1, 121));
    localObject19 = new b(26, new a(9, 43), new a(4, 44));
    localObject20 = new b(28, new a(17, 22), new a(1, 23));
    Object localObject21 = new b(28, new a(2, 14), new a(19, 15));
    localObject18 = new do(18, new int[] { 6, 30, 56, 82 }, (b)localObject18, (b)localObject19, (b)localObject20, (b)localObject21);
    localObject19 = new b(28, new a(3, 113), new a(4, 114));
    localObject20 = new b(26, new a(3, 44), new a(11, 45));
    localObject21 = new b(26, new a(17, 21), new a(4, 22));
    Object localObject22 = new b(26, new a(9, 13), new a(16, 14));
    localObject19 = new do(19, new int[] { 6, 30, 58, 86 }, (b)localObject19, (b)localObject20, (b)localObject21, (b)localObject22);
    localObject20 = new b(28, new a(3, 107), new a(5, 108));
    localObject21 = new b(26, new a(3, 41), new a(13, 42));
    localObject22 = new b(30, new a(15, 24), new a(5, 25));
    Object localObject23 = new b(28, new a(15, 15), new a(10, 16));
    localObject20 = new do(20, new int[] { 6, 34, 62, 90 }, (b)localObject20, (b)localObject21, (b)localObject22, (b)localObject23);
    localObject21 = new b(28, new a(4, 116), new a(4, 117));
    localObject22 = new b(26, new a(17, 42));
    localObject23 = new b(28, new a(17, 22), new a(6, 23));
    Object localObject24 = new b(30, new a(19, 16), new a(6, 17));
    localObject21 = new do(21, new int[] { 6, 28, 50, 72, 94 }, (b)localObject21, (b)localObject22, (b)localObject23, (b)localObject24);
    localObject22 = new b(28, new a(2, 111), new a(7, 112));
    localObject23 = new b(28, new a(17, 46));
    localObject24 = new b(30, new a(7, 24), new a(16, 25));
    Object localObject25 = new b(24, new a(34, 13));
    localObject22 = new do(22, new int[] { 6, 26, 50, 74, 98 }, (b)localObject22, (b)localObject23, (b)localObject24, (b)localObject25);
    localObject23 = new b(30, new a(4, 121), new a(5, 122));
    localObject24 = new b(28, new a(4, 47), new a(14, 48));
    localObject25 = new b(30, new a(11, 24), new a(14, 25));
    Object localObject26 = new b(30, new a(16, 15), new a(14, 16));
    localObject23 = new do(23, new int[] { 6, 30, 54, 78, 102 }, (b)localObject23, (b)localObject24, (b)localObject25, (b)localObject26);
    localObject24 = new b(30, new a(6, 117), new a(4, 118));
    localObject25 = new b(28, new a(6, 45), new a(14, 46));
    localObject26 = new b(30, new a(11, 24), new a(16, 25));
    Object localObject27 = new b(30, new a(30, 16), new a(2, 17));
    localObject24 = new do(24, new int[] { 6, 28, 54, 80, 106 }, (b)localObject24, (b)localObject25, (b)localObject26, (b)localObject27);
    localObject25 = new b(26, new a(8, 106), new a(4, 107));
    localObject26 = new b(28, new a(8, 47), new a(13, 48));
    localObject27 = new b(30, new a(7, 24), new a(22, 25));
    Object localObject28 = new b(30, new a(22, 15), new a(13, 16));
    localObject25 = new do(25, new int[] { 6, 32, 58, 84, 110 }, (b)localObject25, (b)localObject26, (b)localObject27, (b)localObject28);
    localObject26 = new b(28, new a(10, 114), new a(2, 115));
    localObject27 = new b(28, new a(19, 46), new a(4, 47));
    localObject28 = new b(28, new a(28, 22), new a(6, 23));
    Object localObject29 = new b(30, new a(33, 16), new a(4, 17));
    localObject26 = new do(26, new int[] { 6, 30, 58, 86, 114 }, (b)localObject26, (b)localObject27, (b)localObject28, (b)localObject29);
    localObject27 = new b(30, new a(8, 122), new a(4, 123));
    localObject28 = new b(28, new a(22, 45), new a(3, 46));
    localObject29 = new b(30, new a(8, 23), new a(26, 24));
    Object localObject30 = new b(30, new a(12, 15), new a(28, 16));
    localObject27 = new do(27, new int[] { 6, 34, 62, 90, 118 }, (b)localObject27, (b)localObject28, (b)localObject29, (b)localObject30);
    localObject28 = new b(30, new a(3, 117), new a(10, 118));
    localObject29 = new b(28, new a(3, 45), new a(23, 46));
    localObject30 = new b(30, new a(4, 24), new a(31, 25));
    Object localObject31 = new b(30, new a(11, 15), new a(31, 16));
    localObject28 = new do(28, new int[] { 6, 26, 50, 74, 98, 122 }, (b)localObject28, (b)localObject29, (b)localObject30, (b)localObject31);
    localObject29 = new b(30, new a(7, 116), new a(7, 117));
    localObject30 = new b(28, new a(21, 45), new a(7, 46));
    localObject31 = new b(30, new a(1, 23), new a(37, 24));
    Object localObject32 = new b(30, new a(19, 15), new a(26, 16));
    localObject29 = new do(29, new int[] { 6, 30, 54, 78, 102, 126 }, (b)localObject29, (b)localObject30, (b)localObject31, (b)localObject32);
    localObject30 = new b(30, new a(5, 115), new a(10, 116));
    localObject31 = new b(28, new a(19, 47), new a(10, 48));
    localObject32 = new b(30, new a(15, 24), new a(25, 25));
    Object localObject33 = new b(30, new a(23, 15), new a(25, 16));
    localObject30 = new do(30, new int[] { 6, 26, 52, 78, 104, 130 }, (b)localObject30, (b)localObject31, (b)localObject32, (b)localObject33);
    localObject31 = new b(30, new a(13, 115), new a(3, 116));
    localObject32 = new b(28, new a(2, 46), new a(29, 47));
    localObject33 = new b(30, new a(42, 24), new a(1, 25));
    Object localObject34 = new b(30, new a(23, 15), new a(28, 16));
    localObject31 = new do(31, new int[] { 6, 30, 56, 82, 108, 134 }, (b)localObject31, (b)localObject32, (b)localObject33, (b)localObject34);
    localObject32 = new b(30, new a(17, 115));
    localObject33 = new b(28, new a(10, 46), new a(23, 47));
    localObject34 = new b(30, new a(10, 24), new a(35, 25));
    Object localObject35 = new b(30, new a(19, 15), new a(35, 16));
    localObject32 = new do(32, new int[] { 6, 34, 60, 86, 112, 138 }, (b)localObject32, (b)localObject33, (b)localObject34, (b)localObject35);
    localObject33 = new b(30, new a(17, 115), new a(1, 116));
    localObject34 = new b(28, new a(14, 46), new a(21, 47));
    localObject35 = new b(30, new a(29, 24), new a(19, 25));
    Object localObject36 = new b(30, new a(11, 15), new a(46, 16));
    localObject33 = new do(33, new int[] { 6, 30, 58, 86, 114, 142 }, (b)localObject33, (b)localObject34, (b)localObject35, (b)localObject36);
    localObject34 = new b(30, new a(13, 115), new a(6, 116));
    localObject35 = new b(28, new a(14, 46), new a(23, 47));
    localObject36 = new b(30, new a(44, 24), new a(7, 25));
    Object localObject37 = new b(30, new a(59, 16), new a(1, 17));
    localObject34 = new do(34, new int[] { 6, 34, 62, 90, 118, 146 }, (b)localObject34, (b)localObject35, (b)localObject36, (b)localObject37);
    localObject35 = new b(30, new a(12, 121), new a(7, 122));
    localObject36 = new b(28, new a(12, 47), new a(26, 48));
    localObject37 = new b(30, new a(39, 24), new a(14, 25));
    Object localObject38 = new b(30, new a(22, 15), new a(41, 16));
    localObject35 = new do(35, new int[] { 6, 30, 54, 78, 102, 126, 150 }, (b)localObject35, (b)localObject36, (b)localObject37, (b)localObject38);
    localObject36 = new b(30, new a(6, 121), new a(14, 122));
    localObject37 = new b(28, new a(6, 47), new a(34, 48));
    localObject38 = new b(30, new a(46, 24), new a(10, 25));
    Object localObject39 = new b(30, new a(2, 15), new a(64, 16));
    localObject36 = new do(36, new int[] { 6, 24, 50, 76, 102, 128, 154 }, (b)localObject36, (b)localObject37, (b)localObject38, (b)localObject39);
    localObject37 = new b(30, new a(17, 122), new a(4, 123));
    localObject38 = new b(28, new a(29, 46), new a(14, 47));
    localObject39 = new b(30, new a(49, 24), new a(10, 25));
    b localb1 = new b(30, new a(24, 15), new a(46, 16));
    localObject37 = new do(37, new int[] { 6, 28, 54, 80, 106, 132, 158 }, (b)localObject37, (b)localObject38, (b)localObject39, localb1);
    localObject38 = new b(30, new a(4, 122), new a(18, 123));
    localObject39 = new b(28, new a(13, 46), new a(32, 47));
    localb1 = new b(30, new a(48, 24), new a(14, 25));
    b localb2 = new b(30, new a(42, 15), new a(32, 16));
    localObject38 = new do(38, new int[] { 6, 32, 58, 84, 110, 136, 162 }, (b)localObject38, (b)localObject39, localb1, localb2);
    localObject39 = new b(30, new a(20, 117), new a(4, 118));
    localb1 = new b(28, new a(40, 47), new a(7, 48));
    localb2 = new b(30, new a(43, 24), new a(22, 25));
    b localb3 = new b(30, new a(10, 15), new a(67, 16));
    localObject39 = new do(39, new int[] { 6, 26, 54, 82, 110, 138, 166 }, (b)localObject39, localb1, localb2, localb3);
    localb1 = new b(30, new a(19, 118), new a(6, 119));
    localb2 = new b(28, new a(18, 47), new a(31, 48));
    localb3 = new b(30, new a(34, 24), new a(34, 25));
    b localb4 = new b(30, new a(20, 15), new a(61, 16));
    b = new do[] { localObject1, localObject2, localObject3, localObject4, localObject5, localObject6, localObject7, localObject8, localObject9, localObject10, localObject11, localObject12, localObject13, localObject14, localObject15, localObject16, localObject17, localObject18, localObject19, localObject20, localObject21, localObject22, localObject23, localObject24, localObject25, localObject26, localObject27, localObject28, localObject29, localObject30, localObject31, localObject32, localObject33, localObject34, localObject35, localObject36, localObject37, localObject38, localObject39, new do(40, new int[] { 6, 30, 58, 86, 114, 142, 170 }, localb1, localb2, localb3, localb4) };
  }
  
  private do(int paramInt, int[] paramArrayOfInt, b paramb1, b paramb2, b paramb3, b paramb4)
  {
    this.c = paramInt;
    this.d = paramArrayOfInt;
    this.e = new b[] { paramb1, paramb2, paramb3, paramb4 };
    int k = paramb1.a();
    paramArrayOfInt = paramb1.b();
    int i = 0;
    paramInt = j;
    while (paramInt < paramArrayOfInt.length)
    {
      paramb1 = paramArrayOfInt[paramInt];
      j = paramb1.a();
      i += (paramb1.b() + k) * j;
      paramInt += 1;
    }
    this.f = i;
  }
  
  public static do a(int paramInt)
    throws v
  {
    if (paramInt % 4 != 1) {
      throw v.a();
    }
    try
    {
      do localdo = b(paramInt - 17 >> 2);
      return localdo;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw v.a();
    }
  }
  
  public static do b(int paramInt)
  {
    if ((paramInt <= 0) || (paramInt > 40)) {
      throw new IllegalArgumentException();
    }
    return b[(paramInt - 1)];
  }
  
  static do c(int paramInt)
  {
    int i = 0;
    int j = Integer.MAX_VALUE;
    int m = 0;
    while (i < a.length)
    {
      int k = a[i];
      if (k == paramInt) {
        return b(i + 7);
      }
      int n = dm.a(paramInt, k);
      k = j;
      if (n < j)
      {
        m = i + 7;
        k = n;
      }
      i += 1;
      j = k;
    }
    if (j <= 3) {
      return b(m);
    }
    return null;
  }
  
  public final int a()
  {
    return this.c;
  }
  
  public final b a(dl paramdl)
  {
    return this.e[paramdl.a()];
  }
  
  public final int[] b()
  {
    return this.d;
  }
  
  public final int c()
  {
    return this.f;
  }
  
  public final int d()
  {
    return this.c * 4 + 17;
  }
  
  final ak e()
  {
    int k = d();
    ak localak = new ak(k);
    localak.a(0, 0, 9, 9);
    localak.a(k - 8, 0, 8, 9);
    localak.a(0, k - 8, 9, 8);
    int m = this.d.length;
    int i = 0;
    while (i < m)
    {
      int n = this.d[i];
      int j = 0;
      while (j < m)
      {
        if (((i != 0) || ((j != 0) && (j != m - 1))) && ((i != m - 1) || (j != 0))) {
          localak.a(this.d[j] - 2, n - 2, 5, 5);
        }
        j += 1;
      }
      i += 1;
    }
    localak.a(6, 9, 1, k - 17);
    localak.a(9, 6, k - 17, 1);
    if (this.c > 6)
    {
      localak.a(k - 11, 0, 3, 6);
      localak.a(0, k - 11, 6, 3);
    }
    return localak;
  }
  
  public final String toString()
  {
    return String.valueOf(this.c);
  }
  
  public static final class a
  {
    private final int a;
    private final int b;
    
    a(int paramInt1, int paramInt2)
    {
      this.a = paramInt1;
      this.b = paramInt2;
    }
    
    public final int a()
    {
      return this.a;
    }
    
    public final int b()
    {
      return this.b;
    }
  }
  
  public static final class b
  {
    private final int a;
    private final do.a[] b;
    
    b(int paramInt, do.a parama)
    {
      this.a = paramInt;
      this.b = new do.a[] { parama };
    }
    
    b(int paramInt, do.a parama1, do.a parama2)
    {
      this.a = paramInt;
      this.b = new do.a[] { parama1, parama2 };
    }
    
    public final int a()
    {
      return this.a;
    }
    
    public final do.a[] b()
    {
      return this.b;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */