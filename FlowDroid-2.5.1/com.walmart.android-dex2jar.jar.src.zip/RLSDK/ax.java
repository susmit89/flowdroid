package RLSDK;

import java.util.Hashtable;

public final class ax
{
  private static final String a = System.getProperty("file.encoding");
  private static final boolean b;
  
  static
  {
    if (("SJIS".equalsIgnoreCase(a)) || ("EUC_JP".equalsIgnoreCase(a))) {}
    for (boolean bool = true;; bool = false)
    {
      b = bool;
      return;
    }
  }
  
  public static String a(byte[] paramArrayOfByte, Hashtable paramHashtable)
  {
    if (paramHashtable != null)
    {
      paramHashtable = (String)paramHashtable.get(u.e);
      if (paramHashtable != null) {
        return paramHashtable;
      }
    }
    if ((paramArrayOfByte.length > 3) && (paramArrayOfByte[0] == -17) && (paramArrayOfByte[1] == -69) && (paramArrayOfByte[2] == -65)) {
      return "UTF8";
    }
    int i10 = paramArrayOfByte.length;
    int m = 0;
    int i4 = 0;
    int i6 = 0;
    int i8 = 0;
    int i1 = 0;
    int i3 = 0;
    int i2 = 0;
    int i = 1;
    int j = 1;
    int i5 = 1;
    int i9;
    int k;
    int i7;
    if ((i1 < i10) && ((i5 != 0) || (j != 0) || (i != 0)))
    {
      i9 = paramArrayOfByte[i1] & 0xFF;
      if ((i9 >= 128) && (i9 <= 191))
      {
        if (m <= 0) {
          break label656;
        }
        k = m - 1;
        i7 = i8;
      }
    }
    for (;;)
    {
      if (i9 != 194)
      {
        i8 = i6;
        if (i9 != 195) {}
      }
      else
      {
        i8 = i6;
        if (i1 < i10 - 1)
        {
          m = paramArrayOfByte[(i1 + 1)] & 0xFF;
          i8 = i6;
          if (m <= 191) {
            if ((i9 != 194) || (m < 160))
            {
              i8 = i6;
              if (i9 == 195)
              {
                i8 = i6;
                if (m < 128) {}
              }
            }
            else
            {
              i8 = 1;
            }
          }
        }
      }
      i6 = i5;
      if (i9 >= 127)
      {
        i6 = i5;
        if (i9 <= 159) {
          i6 = 0;
        }
      }
      i5 = i4;
      if (i9 >= 161)
      {
        i5 = i4;
        if (i9 <= 223)
        {
          i5 = i4;
          if (i3 == 0) {
            i5 = i4 + 1;
          }
        }
      }
      m = j;
      if (i3 == 0) {
        if (((i9 < 240) || (i9 > 255)) && (i9 != 128))
        {
          m = j;
          if (i9 != 160) {}
        }
        else
        {
          m = 0;
        }
      }
      if (((i9 >= 129) && (i9 <= 159)) || ((i9 >= 224) && (i9 <= 239) && (i3 == 0)))
      {
        n = 1;
        if (i1 >= paramArrayOfByte.length - 1)
        {
          j = 0;
          i1 += 1;
          i4 = i5;
          i5 = i6;
          i6 = i8;
          i8 = i7;
          m = k;
          i3 = n;
          break;
          if (m <= 0) {
            break label650;
          }
        }
      }
      label650:
      for (int n = 0;; n = i)
      {
        i7 = i8;
        k = m;
        i = n;
        if (i9 < 192) {
          break;
        }
        i7 = i8;
        k = m;
        i = n;
        if (i9 > 253) {
          break;
        }
        i = m;
        k = i9;
        for (;;)
        {
          if ((k & 0x40) != 0)
          {
            k <<= 1;
            i += 1;
            continue;
            j = paramArrayOfByte[(i1 + 1)] & 0xFF;
            if ((j < 64) || (j > 252))
            {
              j = 0;
              break;
            }
            i2 += 1;
            j = m;
            break;
            n = 0;
            j = m;
            break;
            if (m > 0) {
              i = 0;
            }
            if ((j != 0) && (b)) {
              return "SJIS";
            }
            if ((i != 0) && (i8 != 0)) {
              return "UTF8";
            }
            if ((j != 0) && ((i2 >= 3) || (i4 * 20 > i10))) {
              return "SJIS";
            }
            if ((i6 == 0) && (i5 != 0)) {
              return "ISO8859_1";
            }
            return a;
          }
        }
        i7 = 1;
        k = i;
        i = n;
        break;
      }
      label656:
      i7 = i8;
      k = m;
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */