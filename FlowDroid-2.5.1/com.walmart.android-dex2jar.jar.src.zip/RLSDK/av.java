package RLSDK;

import java.lang.reflect.Array;

public final class av
  extends at
{
  private ak a = null;
  
  public av(w paramw)
  {
    super(paramw);
  }
  
  public final ak b()
    throws y
  {
    Object localObject1;
    byte[] arrayOfByte;
    int i9;
    int i10;
    int m;
    if (this.a == null)
    {
      localObject1 = a();
      if ((((w)localObject1).b() >= 40) && (((w)localObject1).c() >= 40))
      {
        arrayOfByte = ((w)localObject1).a();
        i9 = ((w)localObject1).b();
        i10 = ((w)localObject1).c();
        m = i9 >> 3;
        if ((i9 & 0x7) == 0) {
          break label688;
        }
        m += 1;
      }
    }
    label196:
    label211:
    label406:
    label408:
    label454:
    label461:
    label547:
    label556:
    label561:
    label676:
    label679:
    label682:
    label688:
    for (;;)
    {
      int n = i10 >> 3;
      if ((i10 & 0x7) != 0) {
        n += 1;
      }
      for (;;)
      {
        localObject1 = (int[][])Array.newInstance(Integer.TYPE, new int[] { n, m });
        int k = 0;
        int i;
        int i1;
        int i2;
        int i3;
        int i6;
        int i7;
        int i4;
        int i5;
        int j;
        int i8;
        if (k < n)
        {
          i = k << 3;
          i1 = i;
          if (i + 8 >= i10) {
            i1 = i10 - 8;
          }
          i2 = 0;
          if (i2 < m)
          {
            i = i2 << 3;
            i3 = i;
            if (i + 8 >= i9) {
              i3 = i9 - 8;
            }
            i = 0;
            i6 = 255;
            i7 = 0;
            i4 = 0;
            if (i4 < 8)
            {
              i5 = 0;
              j = i;
              i = i7;
              if (i5 < 8)
              {
                i7 = arrayOfByte[((i1 + i4) * i9 + i3 + i5)] & 0xFF;
                i8 = j + i7;
                j = i6;
                if (i7 < i6) {
                  j = i7;
                }
                if (i7 <= i) {
                  break label682;
                }
                i = i7;
              }
            }
          }
        }
        for (;;)
        {
          i5 += 1;
          i6 = j;
          j = i8;
          break label211;
          i4 += 1;
          i7 = i;
          i = j;
          break label196;
          if (i7 - i6 > 24) {
            i >>= 6;
          }
          for (;;)
          {
            localObject1[k][i2] = i;
            i2 += 1;
            break;
            if (i7 == 0) {
              i = 1;
            } else {
              i = i6 >> 1;
            }
          }
          k += 1;
          break;
          this.a = new ak(i9, i10);
          ak localak = this.a;
          i = 0;
          if (i < n)
          {
            i1 = i << 3;
            if (i1 + 8 < i10) {
              break label676;
            }
            i1 = i10 - 8;
            j = 0;
            if (j < m)
            {
              i2 = j << 3;
              if (i2 + 8 < i9) {
                break label679;
              }
              i2 = i9 - 8;
            }
          }
          for (;;)
          {
            if (j > 1)
            {
              k = j;
              if (k >= m - 2) {
                break label547;
              }
              i3 = k;
              if (i <= 1) {
                break label556;
              }
              k = i;
              if (k >= n - 2) {
                break label561;
              }
            }
            for (;;)
            {
              i5 = 0;
              i4 = -2;
              while (i4 <= 2)
              {
                Object localObject2 = localObject1[(k + i4)];
                i5 = i5 + localObject2[(i3 - 2)] + localObject2[(i3 - 1)] + localObject2[i3] + localObject2[(i3 + 1)] + localObject2[(i3 + 2)];
                i4 += 1;
              }
              k = 2;
              break;
              i3 = m - 3;
              break label454;
              k = 2;
              break label461;
              k = n - 3;
            }
            i4 = i5 / 25;
            k = 0;
            while (k < 8)
            {
              i3 = 0;
              while (i3 < 8)
              {
                if ((arrayOfByte[((i1 + k) * i9 + i2 + i3)] & 0xFF) < i4) {
                  localak.b(i2 + i3, i1 + k);
                }
                i3 += 1;
              }
              k += 1;
            }
            j += 1;
            break label408;
            i += 1;
            break;
            this.a = super.b();
            return this.a;
            break label406;
          }
        }
      }
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/av.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */