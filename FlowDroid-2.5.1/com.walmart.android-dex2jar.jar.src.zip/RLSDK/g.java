package RLSDK;

import android.app.Application;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.RectF;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.ErrorCallback;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.PreviewCallback;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.ebay.redlasersdk.BarcodeScanActivity;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.List;

public class g
  extends Handler
  implements Camera.AutoFocusCallback, Camera.ErrorCallback, Camera.PictureCallback, Camera.PreviewCallback, SurfaceHolder.Callback
{
  public static final int FOCUS_STYLE_CONTINUOUS = 3;
  public static final int FOCUS_STYLE_INITIAL = 5;
  public static final int FOCUS_STYLE_OFF = 1;
  public static final int FOCUS_STYLE_POINT = 4;
  public static final int FOCUS_STYLE_REPEATED = 2;
  protected static final String TAG = g.class.getSimpleName();
  protected static g cameraManager;
  protected Camera camera;
  protected Matrix cameraToPreviewMatrix;
  protected final f configManager;
  protected Display display;
  protected int focusStyle;
  protected d frameEngine;
  protected boolean isAutoFocusing;
  protected boolean isOnTimerForRepeatedAutoFocus;
  protected boolean isTakingPicture = false;
  protected Context mContext;
  protected FrameLayout mPreviewParentView;
  protected k mPreviewSurface;
  protected boolean mPreviewSurfaceIsAttached;
  protected boolean previewing;
  int relativeCameraOrientation;
  protected BarcodeScanActivity scanActivity;
  
  protected g(Application paramApplication)
  {
    this.mContext = paramApplication;
    paramApplication = this.mContext;
    this.configManager = new f();
    this.display = ((WindowManager)this.mContext.getSystemService("window")).getDefaultDisplay();
  }
  
  public static g get()
  {
    return cameraManager;
  }
  
  public static void init(Application paramApplication)
  {
    if (cameraManager == null) {
      try
      {
        int i = Build.VERSION.SDK_INT;
        Object localObject;
        if (i >= 14) {
          localObject = Class.forName("RLSDK.j");
        }
        for (;;)
        {
          cameraManager = (g)localObject.getDeclaredConstructors()[0].newInstance(new Object[] { paramApplication });
          return;
          if (i >= 9) {
            localObject = Class.forName("RLSDK.i");
          } else if (i >= 8) {
            localObject = Class.forName("RLSDK.h");
          } else {
            localObject = Class.forName("RLSDK.g");
          }
        }
        return;
      }
      catch (ClassNotFoundException paramApplication)
      {
        paramApplication = TAG;
        return;
      }
      catch (Exception paramApplication)
      {
        localObject = TAG;
        new StringBuilder("Unknown Exception: ").append(paramApplication.toString()).toString();
      }
    }
  }
  
  public void addCallbackBuffer(byte[] paramArrayOfByte) {}
  
  protected Point calculatePreviewSurfaceSize()
  {
    Object localObject = Build.MODEL;
    float f2 = this.mPreviewParentView.getWidth();
    float f3 = this.mPreviewParentView.getHeight();
    Point localPoint = this.configManager.a();
    int i = this.relativeCameraOrientation;
    float f1;
    if ((i == 90) || (i == 270)) {
      f1 = f2;
    }
    for (float f4 = f3;; f4 = f2)
    {
      f4 /= localPoint.x;
      float f5 = f1 / localPoint.y;
      if (f4 > f5) {}
      for (f1 = f4;; f1 = f5)
      {
        if ((((String)localObject).equals("HTC VLE_U")) || (((String)localObject).equals("HTC One X")) || (((String)localObject).equals("R800x"))) {
          if (f4 >= f5) {
            break label310;
          }
        }
        label310:
        for (f1 = f4;; f1 = f5)
        {
          this.cameraToPreviewMatrix = new Matrix();
          this.cameraToPreviewMatrix.postTranslate(-localPoint.x / 2, -localPoint.y / 2);
          if (isCameraFrontFacing()) {
            this.cameraToPreviewMatrix.postScale(-1.0F, 1.0F);
          }
          this.cameraToPreviewMatrix.postRotate(i);
          this.cameraToPreviewMatrix.postScale(f1, f1);
          this.cameraToPreviewMatrix.postTranslate(f2 / 2.0F, f3 / 2.0F);
          if ((((String)localObject).equalsIgnoreCase("Nexus 7")) && ((i == 90) || (i == 270))) {
            this.cameraToPreviewMatrix.postTranslate(0.0F, 75.0F);
          }
          localObject = new RectF(0.0F, 0.0F, localPoint.x, localPoint.y);
          this.cameraToPreviewMatrix.mapRect((RectF)localObject);
          return new Point((int)((RectF)localObject).width(), (int)((RectF)localObject).height());
        }
      }
      f1 = f3;
    }
  }
  
  public Matrix cameraToPreviewMatrix()
  {
    return this.cameraToPreviewMatrix;
  }
  
  public void closeDriver(BarcodeScanActivity paramBarcodeScanActivity)
  {
    if (paramBarcodeScanActivity != this.scanActivity)
    {
      paramBarcodeScanActivity = TAG;
      return;
    }
    if (this.camera != null)
    {
      this.camera.release();
      this.camera = null;
      paramBarcodeScanActivity = TAG;
    }
    this.scanActivity = null;
  }
  
  protected void determineFocusMode(boolean paramBoolean)
  {
    Camera.Parameters localParameters;
    List localList;
    if (this.camera != null)
    {
      localParameters = this.camera.getParameters();
      localList = localParameters.getSupportedFocusModes();
      localObject = new String();
      if (!localList.contains("continuous-picture")) {
        break label154;
      }
      String str = "continuous-picture";
      this.focusStyle = 3;
      localObject = str;
      if (localList.contains("macro"))
      {
        localObject = str;
        if (paramBoolean)
        {
          localObject = "macro";
          this.focusStyle = 5;
        }
      }
      if (this.frameEngine != null)
      {
        if (this.focusStyle != 1) {
          break label212;
        }
        this.frameEngine.a(true);
      }
    }
    for (;;)
    {
      if (((String)localObject).length() <= 0) {
        break label223;
      }
      label154:
      try
      {
        this.camera.cancelAutoFocus();
        localParameters.setFocusMode((String)localObject);
        this.camera.setParameters(localParameters);
        new StringBuilder("Setting focus mode to ").append((String)localObject).toString();
        return;
      }
      catch (RuntimeException localRuntimeException) {}
      if (localList.contains("macro"))
      {
        localObject = "macro";
        this.focusStyle = 2;
        break;
      }
      if (localList.contains("auto"))
      {
        localObject = "auto";
        this.focusStyle = 2;
        break;
      }
      this.focusStyle = 1;
      break;
      label212:
      this.frameEngine.a(false);
    }
    label223:
    Object localObject = TAG;
    return;
  }
  
  protected void determineOrientation()
  {
    this.relativeCameraOrientation = 0;
  }
  
  public Point getCameraResolution()
  {
    Point localPoint = this.configManager.a();
    if (this.display.getOrientation() == 0) {
      return new Point(localPoint.y, localPoint.x);
    }
    return localPoint;
  }
  
  protected int getOpenedCameraIndex()
  {
    return 0;
  }
  
  public int getSelectedCameraIndex()
  {
    return 0;
  }
  
  public boolean getTorch()
  {
    if (this.camera == null) {}
    String str;
    do
    {
      return false;
      str = this.camera.getParameters().getFlashMode();
    } while ((str == null) || (!str.equals("torch")));
    return true;
  }
  
  public void handleMessage(Message paramMessage)
  {
    this.isOnTimerForRepeatedAutoFocus = false;
    if ((paramMessage.what == 2) && (this.camera != null) && (this.previewing) && ((this.focusStyle == 2) || (this.focusStyle == 5))) {
      performAutoFocus();
    }
  }
  
  protected boolean isCameraFrontFacing()
  {
    return false;
  }
  
  public boolean isTorchAvailable()
  {
    if (this.camera == null) {}
    List localList;
    do
    {
      return false;
      localList = this.camera.getParameters().getSupportedFlashModes();
    } while ((localList == null) || (!localList.contains("torch")));
    return true;
  }
  
  public void onAutoFocus(boolean paramBoolean, Camera paramCamera)
  {
    this.isAutoFocusing = false;
    if (this.focusStyle == 2) {
      if (!this.isOnTimerForRepeatedAutoFocus)
      {
        this.isOnTimerForRepeatedAutoFocus = true;
        sendEmptyMessageDelayed(2, 1500L);
      }
    }
    while (this.focusStyle != 5) {
      return;
    }
    determineFocusMode(false);
  }
  
  public void onError(int paramInt, Camera paramCamera)
  {
    if (paramInt == 100)
    {
      Log.e(TAG, "camera error - server died; instantiating new camera object");
      paramCamera.release();
      Camera.open();
    }
    for (;;)
    {
      if (this.scanActivity != null) {
        this.scanActivity.onCameraError(paramInt);
      }
      return;
      if (paramInt == 1) {
        Log.e(TAG, "camera error - unknown");
      }
    }
  }
  
  public void onPictureTaken(byte[] paramArrayOfByte, Camera paramCamera)
  {
    paramCamera = TAG;
    if (this.isTakingPicture)
    {
      this.frameEngine.a(paramArrayOfByte);
      startPreview();
      this.previewing = true;
      this.isTakingPicture = false;
    }
  }
  
  public void onPreviewFrame(byte[] paramArrayOfByte, Camera paramCamera)
  {
    if ((this.frameEngine != null) && (this.previewing))
    {
      paramCamera = this.configManager.a();
      this.frameEngine.a(paramArrayOfByte, paramCamera.x, paramCamera.y, this.relativeCameraOrientation);
    }
  }
  
  public void onTapEvent(int paramInt1, int paramInt2)
  {
    if (this.mPreviewSurfaceIsAttached) {
      performAutoFocus();
    }
  }
  
  protected void openCamera()
    throws IOException
  {
    this.camera = Camera.open();
    if (this.camera == null) {
      throw new IOException();
    }
  }
  
  public void openDriver(BarcodeScanActivity paramBarcodeScanActivity, FrameLayout paramFrameLayout)
    throws IOException
  {
    if (this.scanActivity == paramBarcodeScanActivity) {
      paramBarcodeScanActivity = TAG;
    }
    do
    {
      return;
      if (this.scanActivity != null)
      {
        paramBarcodeScanActivity = TAG;
        throw new e("Another BarcodeScanActivity has the camera open.");
      }
      this.scanActivity = paramBarcodeScanActivity;
      paramBarcodeScanActivity = TAG;
    } while (this.camera != null);
    try
    {
      openCamera();
      this.camera.setErrorCallback(this);
      this.configManager.a(this.camera);
      determineOrientation();
      this.mPreviewParentView = paramFrameLayout;
      paramBarcodeScanActivity = new FrameLayout.LayoutParams(-1, -1, 17);
      if (this.mPreviewSurface != null)
      {
        this.mPreviewSurface.getHolder().removeCallback(this);
        this.mPreviewParentView.removeView(this.mPreviewSurface);
        this.mPreviewSurface = null;
        this.mPreviewSurfaceIsAttached = false;
      }
      this.mPreviewSurface = new k(this.mContext);
      paramFrameLayout = this.mPreviewSurface.getHolder();
      paramFrameLayout.setType(3);
      this.mPreviewParentView.addView(this.mPreviewSurface, paramBarcodeScanActivity);
      paramFrameLayout.addCallback(this);
      if (this.mPreviewSurface.getHolder().getSurface().isValid())
      {
        paramBarcodeScanActivity = calculatePreviewSurfaceSize();
        paramBarcodeScanActivity = new FrameLayout.LayoutParams(paramBarcodeScanActivity.x, paramBarcodeScanActivity.y, 17);
        this.mPreviewParentView.updateViewLayout(this.mPreviewSurface, paramBarcodeScanActivity);
        this.camera.setPreviewDisplay(this.mPreviewSurface.getHolder());
        this.mPreviewSurfaceIsAttached = true;
        this.scanActivity.onCameraPreviewStarted();
        if ((this.focusStyle == 2) || (this.focusStyle == 5)) {
          performAutoFocus();
        }
      }
      startPreview();
      return;
    }
    catch (Exception paramBarcodeScanActivity)
    {
      this.scanActivity.onCameraError(1);
    }
  }
  
  protected void performAutoFocus()
  {
    if (this.camera == null) {}
    do
    {
      Object localObject;
      do
      {
        do
        {
          return;
          localObject = this.camera.getParameters();
        } while (localObject == null);
        localObject = ((Camera.Parameters)localObject).getFocusMode();
      } while ((localObject == null) || ((!((String)localObject).equals("macro")) && (!((String)localObject).equals("auto"))) || (this.isAutoFocusing));
      try
      {
        this.isAutoFocusing = true;
        this.camera.autoFocus(this);
        return;
      }
      catch (Exception localException)
      {
        this.isAutoFocusing = false;
      }
    } while (this.isOnTimerForRepeatedAutoFocus);
    this.isOnTimerForRepeatedAutoFocus = true;
    sendEmptyMessageDelayed(2, 100L);
  }
  
  public Matrix previewToCameraMatix()
  {
    if (this.cameraToPreviewMatrix == null) {
      return null;
    }
    Matrix localMatrix = new Matrix();
    this.cameraToPreviewMatrix.invert(localMatrix);
    return localMatrix;
  }
  
  public void setPreviewFrameHandler(d paramd)
  {
    this.frameEngine = paramd;
  }
  
  public void setSelectedCameraIndex(int paramInt) {}
  
  public void setTorch(boolean paramBoolean)
  {
    try
    {
      Camera.Parameters localParameters = this.camera.getParameters();
      List localList = localParameters.getSupportedFlashModes();
      if (localList != null)
      {
        if (!localList.contains("torch")) {
          return;
        }
        if (paramBoolean) {
          localParameters.setFlashMode("torch");
        }
        for (;;)
        {
          this.camera.setParameters(localParameters);
          return;
          localParameters.setFlashMode("off");
        }
      }
      return;
    }
    catch (RuntimeException localRuntimeException) {}
  }
  
  protected void startPreview()
  {
    if ((this.camera != null) && (!this.previewing))
    {
      this.previewing = true;
      this.camera.setPreviewCallback(this);
      this.camera.startPreview();
      this.isAutoFocusing = false;
      this.isOnTimerForRepeatedAutoFocus = false;
      determineFocusMode(true);
    }
  }
  
  public void stopPreview(BarcodeScanActivity paramBarcodeScanActivity)
  {
    if (paramBarcodeScanActivity != this.scanActivity) {
      paramBarcodeScanActivity = TAG;
    }
    while ((this.camera == null) || (!this.previewing)) {
      return;
    }
    this.previewing = false;
    this.camera.setPreviewCallback(null);
    this.camera.stopPreview();
  }
  
  public final void surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3)
  {
    paramSurfaceHolder = TAG;
  }
  
  public final void surfaceCreated(SurfaceHolder paramSurfaceHolder)
  {
    paramSurfaceHolder = TAG;
    if (this.camera == null) {}
    while (this.mPreviewSurfaceIsAttached) {
      return;
    }
    this.mPreviewSurfaceIsAttached = true;
    try
    {
      paramSurfaceHolder = calculatePreviewSurfaceSize();
      paramSurfaceHolder = new FrameLayout.LayoutParams(paramSurfaceHolder.x, paramSurfaceHolder.y, 17);
      this.mPreviewParentView.updateViewLayout(this.mPreviewSurface, paramSurfaceHolder);
      if (this.camera != null) {
        this.camera.setPreviewDisplay(this.mPreviewSurface.getHolder());
      }
      if ((this.focusStyle == 2) || (this.focusStyle == 5)) {
        performAutoFocus();
      }
      this.scanActivity.onCameraPreviewStarted();
      return;
    }
    catch (IOException paramSurfaceHolder)
    {
      for (;;)
      {
        paramSurfaceHolder.printStackTrace();
      }
    }
  }
  
  public final void surfaceDestroyed(SurfaceHolder paramSurfaceHolder)
  {
    this.mPreviewSurfaceIsAttached = false;
  }
  
  public void takePicture()
  {
    Object localObject = TAG;
    if ((this.camera != null) && (!this.isTakingPicture))
    {
      localObject = this.camera.getParameters();
      if (!((Camera.Parameters)localObject).getSupportedPictureFormats().contains(Integer.valueOf(256))) {}
    }
    try
    {
      ((Camera.Parameters)localObject).setPictureFormat(256);
      ((Camera.Parameters)localObject).setJpegQuality(80);
      this.camera.setParameters((Camera.Parameters)localObject);
      this.previewing = false;
      this.isTakingPicture = true;
      this.camera.takePicture(null, null, this);
      this.camera.setPreviewCallback(null);
      return;
    }
    catch (RuntimeException localRuntimeException)
    {
      Log.e(TAG, "Not taking picture because camera.setParameters failed.");
    }
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */