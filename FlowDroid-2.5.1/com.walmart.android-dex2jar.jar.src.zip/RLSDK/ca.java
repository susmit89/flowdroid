package RLSDK;

public class ca
{
  private final int a;
  private final int b;
  
  public ca(int paramInt1, int paramInt2)
  {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public final int a()
  {
    return this.a;
  }
  
  public final int b()
  {
    return this.b;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/ca.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */