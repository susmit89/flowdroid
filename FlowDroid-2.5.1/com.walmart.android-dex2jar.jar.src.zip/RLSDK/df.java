package RLSDK;

import java.util.Hashtable;

public final class df
  implements z
{
  private static final ad[] a = new ad[0];
  private final dk b = new dk();
  
  public final ab a(s params, Hashtable paramHashtable)
    throws y, t, v
  {
    Object localObject;
    if ((paramHashtable != null) && (paramHashtable.containsKey(u.b)))
    {
      params = params.c();
      localObject = params.a();
      int[] arrayOfInt = params.b();
      if ((localObject == null) || (arrayOfInt == null)) {
        throw y.a();
      }
      int k = params.b;
      int m = params.a;
      int j = localObject[0];
      int i = localObject[1];
      while ((j < m) && (i < k) && (params.a(j, i)))
      {
        j += 1;
        i += 1;
      }
      if ((j == m) || (i == k)) {
        throw y.a();
      }
      k = j - localObject[0];
      if (k == 0) {
        throw y.a();
      }
      m = localObject[1];
      i = arrayOfInt[1];
      int n = localObject[0];
      int i1 = (arrayOfInt[0] - n + 1) / k;
      int i2 = (i - m + 1) / k;
      if ((i1 == 0) || (i2 == 0)) {
        throw y.a();
      }
      if (i2 != i1) {
        throw y.a();
      }
      int i3 = k >> 1;
      localObject = new ak(i1, i2);
      i = 0;
      while (i < i2)
      {
        j = 0;
        while (j < i1)
        {
          if (params.a(j * k + (n + i3), m + i3 + i * k)) {
            ((ak)localObject).b(j, i);
          }
          j += 1;
        }
        i += 1;
      }
      params = this.b.a((ak)localObject, paramHashtable);
    }
    for (paramHashtable = a;; paramHashtable = ((ar)localObject).e())
    {
      paramHashtable = new ab(params.b(), params.a(), paramHashtable, q.k);
      if (params.c() != null) {
        paramHashtable.a(ac.c, params.c());
      }
      if (params.d() != null) {
        paramHashtable.a(ac.d, params.d().toString());
      }
      return paramHashtable;
      localObject = new dr(params.c()).a(paramHashtable);
      params = this.b.a(((ar)localObject).d(), paramHashtable);
    }
  }
  
  public final void a() {}
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/df.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */