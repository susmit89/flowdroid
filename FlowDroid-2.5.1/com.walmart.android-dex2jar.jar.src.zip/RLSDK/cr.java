package RLSDK;

final class cr
  extends cq
{
  cr(aj paramaj)
  {
    super(paramaj);
  }
  
  public final String a()
    throws y
  {
    StringBuffer localStringBuffer = new StringBuffer();
    return this.b.a(localStringBuffer, 5);
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */