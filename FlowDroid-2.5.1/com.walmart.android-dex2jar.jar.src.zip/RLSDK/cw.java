package RLSDK;

final class cw
  extends cx
{
  private final int b;
  private final int c;
  
  cw(int paramInt1, int paramInt2, int paramInt3)
  {
    super(paramInt1);
    this.b = paramInt2;
    this.c = paramInt3;
    if ((this.b < 0) || (this.b > 10)) {
      throw new IllegalArgumentException("Invalid firstDigit: " + paramInt2);
    }
    if ((this.c < 0) || (this.c > 10)) {
      throw new IllegalArgumentException("Invalid secondDigit: " + paramInt3);
    }
  }
  
  final int a()
  {
    return this.b;
  }
  
  final int b()
  {
    return this.c;
  }
  
  final boolean c()
  {
    return this.b == 10;
  }
  
  final boolean d()
  {
    return this.c == 10;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/cw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */