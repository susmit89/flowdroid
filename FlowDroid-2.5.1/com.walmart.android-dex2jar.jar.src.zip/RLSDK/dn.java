package RLSDK;

public final class dn
{
  public static final dn a = new dn(new int[] { 0, 0, 0 }, 0, "TERMINATOR");
  public static final dn b = new dn(new int[] { 10, 12, 14 }, 1, "NUMERIC");
  public static final dn c = new dn(new int[] { 9, 11, 13 }, 2, "ALPHANUMERIC");
  public static final dn d = new dn(new int[] { 0, 0, 0 }, 3, "STRUCTURED_APPEND");
  public static final dn e = new dn(new int[] { 8, 16, 16 }, 4, "BYTE");
  public static final dn f = new dn(null, 7, "ECI");
  public static final dn g = new dn(new int[] { 8, 10, 12 }, 8, "KANJI");
  public static final dn h = new dn(null, 5, "FNC1_FIRST_POSITION");
  public static final dn i = new dn(null, 9, "FNC1_SECOND_POSITION");
  public static final dn j = new dn(new int[] { 8, 10, 12 }, 13, "HANZI");
  private final int[] k;
  private final int l;
  private final String m;
  
  private dn(int[] paramArrayOfInt, int paramInt, String paramString)
  {
    this.k = paramArrayOfInt;
    this.l = paramInt;
    this.m = paramString;
  }
  
  public static dn a(int paramInt)
  {
    switch (paramInt)
    {
    case 6: 
    case 10: 
    case 11: 
    case 12: 
    default: 
      throw new IllegalArgumentException();
    case 0: 
      return a;
    case 1: 
      return b;
    case 2: 
      return c;
    case 3: 
      return d;
    case 4: 
      return e;
    case 5: 
      return h;
    case 7: 
      return f;
    case 8: 
      return g;
    case 9: 
      return i;
    }
    return j;
  }
  
  public final int a(do paramdo)
  {
    if (this.k == null) {
      throw new IllegalArgumentException("Character count doesn't apply to this mode");
    }
    int n = paramdo.a();
    if (n <= 9) {
      n = 0;
    }
    for (;;)
    {
      return this.k[n];
      if (n <= 26) {
        n = 1;
      } else {
        n = 2;
      }
    }
  }
  
  public final String toString()
  {
    return this.m;
  }
}


/* Location:              /home/susmit/soft/dex2jar-2.0/com.walmart.android-dex2jar.jar!/RLSDK/dn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */