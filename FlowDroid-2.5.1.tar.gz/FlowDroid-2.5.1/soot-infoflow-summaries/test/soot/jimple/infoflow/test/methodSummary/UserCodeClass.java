package soot.jimple.infoflow.test.methodSummary;

public class UserCodeClass implements IUserCodeClass {

	@Override
	public String callTheGap(String in) {
		return in;
	}


}
