package soot.jimple.infoflow.test.methodSummary;

public interface IUserCodeClass {
	
	public String callTheGap(String in);

}
