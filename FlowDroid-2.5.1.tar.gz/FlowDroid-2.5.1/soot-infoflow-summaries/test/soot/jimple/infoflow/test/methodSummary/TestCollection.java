package soot.jimple.infoflow.test.methodSummary;

public class TestCollection {

	public void add(Object o) {
		//
	}

	public void clear() {

	}

	public Object get() {
		return null;
	}

}
