package soot.jimple.infoflow.test.methodSummary;

public class Data2 {
	
	public Object c;

}
